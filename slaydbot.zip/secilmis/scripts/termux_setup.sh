#!/usr/bin/env bash
# One-shot setup of the Telegram PPT bot on Termux (Android).
# Usage:  bash scripts/termux_setup.sh
set -e

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"
BACKEND="$PROJECT_DIR/backend"
ENV_FILE="$BACKEND/.env"

echo "== [1/4] Termux paketləri =="
pkg update -y
pkg install -y python python-lxml python-pillow || {
    echo "python-lxml/python-pillow paketi tapılmadı — build alətləri ilə cəhd edilir..."
    pkg install -y python clang make pkg-config libxml2 libxslt libjpeg-turbo libpng zlib
}

echo "== [2/4] Python asılılıqları =="
python -m pip install -r "$BACKEND/requirements-termux.txt"

echo "== [3/4] .env konfiqurasiyası =="
if [ -f "$ENV_FILE" ]; then
    echo ".env artıq var — toxunulmur ($ENV_FILE)."
else
    echo "LLM provayderi seçin:"
    echo "  1) Google Gemini (PULSUZ, tövsiyə olunur)"
    echo "  2) OpenAI / GPT"
    echo "  3) Anthropic Claude"
    read -r -p "Seçim [1]: " choice
    choice="${choice:-1}"
    {
        case "$choice" in
            2) read -r -s -p "OPENAI_API_KEY: " k; echo
               echo "LLM_PROVIDER=openai"; echo "OPENAI_API_KEY=$k"; echo "OPENAI_MODEL=gpt-4o" ;;
            3) read -r -s -p "ANTHROPIC_API_KEY: " k; echo
               echo "LLM_PROVIDER=anthropic"; echo "ANTHROPIC_API_KEY=$k"; echo "MODEL_ID=claude-sonnet-4-6" ;;
            *) echo "Pulsuz açar: https://aistudio.google.com/apikey"
               read -r -s -p "GEMINI_API_KEY: " k; echo
               echo "LLM_PROVIDER=gemini"; echo "GEMINI_API_KEY=$k"; echo "GEMINI_MODEL=gemini-2.5-flash" ;;
        esac
        read -r -s -p "TELEGRAM_BOT_TOKEN (@BotFather): " t; echo
        echo "TELEGRAM_BOT_TOKEN=$t"
        read -r -p "TELEGRAM_ALLOWED_IDS (sizin Telegram ID; bilmirsinizsə boş buraxın, botda /id yazın): " ids
        echo "TELEGRAM_ALLOWED_IDS=$ids"
        read -r -s -p "PEXELS_API_KEY (şəkillər üçün, pulsuz: https://www.pexels.com/api/ ; boş = şəkilsiz): " pk; echo
        [ -n "$pk" ] && echo "PEXELS_API_KEY=$pk"
        echo "BOT_DEFAULT_LANGUAGE=az"
    } > "$ENV_FILE"
    chmod 600 "$ENV_FILE"
    echo ".env yaradıldı: $ENV_FILE"
fi

echo "== [4/4] Yoxlama =="
cd "$BACKEND"
python -m unittest tests.test_aspect_ratio tests.test_pptx_builder tests.test_llm_providers tests.test_deck_service tests.test_rich_layouts tests.test_images tests.test_telegram_bot 2>&1 | tail -4
echo
python telegram_bot.py --check || echo "(--check xəta verdi: .env-dəki açarları yoxlayın)"
echo
echo "Hazırdır. Botu işə salmaq üçün:  bash $SCRIPT_DIR/run_bot.sh"
