# CHANGELOG_PROGRESS

## Checkpoint 1 (Phase 1 audit + pre-approval implementation)
Created: backend/utils/aspect_ratio.py, utils/languages.py, utils/pptx_builder.py, agent/deck_service.py, telegram_bot.py, requirements-termux.txt, scripts/termux_setup.sh, scripts/run_bot.sh, tests/test_aspect_ratio.py, test_pptx_builder.py, test_llm_providers.py, test_telegram_bot.py, PROJECT_PROGRESS.md, RESUME_PROMPT.md, CHANGELOG_PROGRESS.md
Modified: backend/agent/llm_client.py (Gemini + REST clients, token caps), agent/__init__.py (optional anthropic), agent/analyzer.py + expander.py + generator.py (any language), main.py (Gemini settings, /api/generate-pptx, aspect_ratio), utils/pptx_export.py (fixes), requirements.txt (+python-pptx), .env.example, tests/test_validator.py (stale tests aligned)
Tests: new unittest suites and existing suites run in sandbox (see PROJECT_PROGRESS.md). No live credentials, no real device.
Remaining: see PROJECT_PROGRESS.md

## Checkpoint 2 (Phase 2)
Created: README.termux.md
Modified: scripts/setup.sh (Gemini option), Makefile (bot, test-light)
Tests: bash -n setup.sh OK; make -n targets OK; PPTAgent() with Gemini OK; main.py import not testable (fastapi absent in sandbox)
Remaining: frontend Gemini option, PDF export of native decks, live tests

## Checkpoint 3 (Phase 3)
Modified: frontend/src/app/settings/page.tsx, frontend/src/lib/api.ts (Gemini tab/fields; originals diffed)
Tests: tsc with temp tsconfig on original vs new files: no syntax errors, no errors specific to the change (only missing react/next type noise, same as the original). npm install / next build NOT run (no node_modules, no network).
Remaining: PDF decision, live tests, backend FastAPI endpoints untested

## Final package (Phase 4)
Created: backend/tests/test_deck_service.py
Modified: backend/agent/deck_service.py, backend/tests/test_telegram_bot.py (+3 tests), scripts/termux_setup.sh, Makefile, README.termux.md
Tests: all new suites pass (see report); existing 56 pass
Remaining: live-credential test, real-device test, FastAPI endpoint tests, npm build, optional PDF

## Design upgrade (post-deployment, user request: "more professional")
Created: backend/utils/pptx_icons.py (native-shape icon set), backend/agent/deck_planner.py (layout-aware LLM plan + parser), backend/tests/test_rich_layouts.py (10 tests)
Modified: backend/utils/pptx_builder.py (new layouts: agenda, cards with icon+heading+text, stats, steps/timeline, compare, quote, section; richer cover; per-slide layout resolution with graceful fallback; long words never split mid-word), backend/agent/deck_service.py (rich plan first, classic outline as fallback)
Tests: unittest 49 pass (incl. 10 new + all 12 builder tests, deck_service, telegram e2e); all layouts x 4 ratios reopen, nothing placed off-slide; validator PASSED; visually inspected 16:9, 4:3, 1:1.
Not tested: real Gemini output quality with the new prompt (needs live key); pytest-based files (analyzer/generator/validator/api) untouched this round.
Remaining: PDF export (deferred), optional real photos via Pexels (deferred)

## Photos on slides (user request: topic-matching images)
Created: backend/utils/image_search.py (Pexels, stdlib, fail-soft, https-host allowlist, parallel), backend/tests/test_images.py (9 tests vs fake Pexels server)
Modified: utils/pptx_builder.py (photo cover, photo section background with translucent veil, new "image" layout, credit caption, centre-crop), agent/deck_planner.py (image layout + image_query rules, only when a key exists), agent/deck_service.py (images stage, DeckResult.images), telegram_bot.py (status message), scripts/termux_setup.sh (Pexels prompt), backend/.env.example, README.termux.md (rewritten: the old file had double-encoded/garbled characters and wrong folder name)
Tests: unittest suites pass (62 run; the 4 pytest-based files cannot import pytest in the sandbox and were not touched); photo decks validated and rendered in 16:9 and 1:1 with synthetic photos.
Not tested: real Pexels API (no network/key in sandbox) - request/response follow Pexels' documented /v1/search format.

## Gemini team + charts/tables + QA (user request: fix the weak points)
Created: backend/company/ (gemini.py, roles.py, employee.py, ceo.py: director that hires employees by itself), backend/agent/deck_team.py (researcher -> designer -> reviewer), backend/utils/pptx_qa.py (plan + geometry checks), backend/utils/pptx_icons.py (33 native-shape icons, rewritten: the original file was missing on the device), backend/tests/test_team_charts.py, backend/tests/test_icons.py
Modified: utils/pptx_builder.py (native "chart" bar/hbar/line/pie and "table" layouts), agent/deck_planner.py (chart/table in prompt, no invented numbers), agent/deck_service.py (uses the team when LLM_PROVIDER=gemini; DECK_TEAM=0 disables), telegram_bot.py (research/review status), .env.example (Gemini 3.x models, tiers, DECK_TEAM)
Tests: 19 unittest pass (9 image + 10 new) in a sandbox with stand-ins for files not shipped in the zip; charts/tables/icons rendered with LibreOffice and inspected.
Not tested: real Gemini calls (no key in sandbox), Telegram on a real device, /company command (not built yet).

## Skill integration + 15-slide limit (secilmis.zip)

- NEW `backend/agent/skill_system.py`: automatic discovery/loading/caching of every `SKILL.md` (nested), stage routing via `backend/skills/skill_map.json`, budgeted guidance, conflict policy. Bundled skills in `backend/skills/` (presentation-skill = primary, older presentation-skill copy = fallback, frontend-design = active, 8 GSAP skills = registered only, not applicable to PPTX). Details: `docs/SKILL_INTEGRATION.md`.
- NEW `backend/utils/slide_limits.py`: hard maximum of 15 slides (minimum 1); enforced in Telegram `/slides`, service input, planner prompts, JSON parsing, review/repair loop, `build_pptx`, and a final check of the built file (`deck_service.finalize_pptx`).
- Planner: `build_system_prompt(images, max_slides, skills)`, `parse_plan(..., max_slides)`, optional `brief` (audience/purpose/tone), `illustrative` charts are labelled.
- QA: `check_plan(max_slides)`, `check_pptx(max_slides)` (limit, blank slides, readability minimums 28/16/9 pt from the skill).
- Telegram: `/slides N` (1-15), buttons 1 3 5 6 8 10 12 15, new `/skills` command.
- Tests: `backend/tests/test_slide_limits.py`, `backend/tests/test_skill_integration.py` (62 tests incl. the older ones passed in a sandbox with stand-ins for files that were not supplied; NOT run on a phone, NOT run with real API keys).
- Unfinished / next: run the tests on the device; align `main.py` (`/api/generate-pptx`) slide validation with `utils.slide_limits` if it validates by itself; optional PDF export; real-key quality check of the new prompts.

