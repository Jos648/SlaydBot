# Skill integration & 15-slide limit

## What was integrated (all supplied skills are registered)

| Skill (folder under `backend/skills/`) | Status | Where it is used |
|---|---|---|
| `presentation-skill/` (newer archive, *presentation-skill-main*) | **active, primary** | planner prompt (request/audience analysis, planning, visual direction, composition, data/figures), reviewer prompt (QA & repair, typography/build rules), readability thresholds in `utils/pptx_qa.py` |
| `presentation-skill-ppt-legacy/` (older *PPTskill-main* archive, same skill name) | **fallback** | used per stage only if the primary has nothing for that stage; registered as `presentation-skill@presentation-skill-ppt-legacy` |
| `frontend-design/` (`SKILL__1_.md`) | **active** (web-only parts filtered out) | typography discipline, "avoid generic AI-looking defaults", restraint, copywriting rules → planner and reviewer prompts |
| `gsap-skills/` (8 skills: core, frameworks, performance, plugins, react, scrolltrigger, timeline, utils) | **registered only** | Browser-JavaScript animation libraries. A python-pptx deck has no GSAP runtime and Web+PPTX is out of scope, so **no instruction is injected**. Visible with `/skills`; the reason is stored in `skill_map.json`. |

Originals are kept byte-identical (`backend/skills/MANIFEST.json` lists SHA-256 of every file; a test verifies it).
**Not shipped** (on purpose): the skills' `scripts/`, `decks/`, `extensions/`, `plugins/`, images and 5 MB JSON corpora (Node/pptxgenjs/LibreOffice toolchain, ~60 MB; 68 of the 150 scripts call `subprocess`/`eval`). Nothing from a skill archive is ever executed.

## How skill loading works (`backend/agent/skill_system.py`)

1. **Discovery** - every `SKILL.md` under `backend/skills/` (any depth) plus folders in `PPT_SKILLS_EXTRA` (`:`-separated). Empty, malformed, non-UTF-8 and duplicate-name files are handled (duplicates get the id `name@folder`).
2. **Loading** - YAML front-matter (lenient fallback), markdown split into sections, cached by file mtime/size, re-scanned automatically (at most every 5 s) when a file changes. Relative references resolve only inside the skill's own folder.
3. **Routing** - `backend/skills/skill_map.json` maps skills → pipeline stages → headings:
   `request_analysis, audience_analysis, planning, visual_direction, composition, content, data_viz, build, qa_repair`.
   A skill that is not in the map is still registered; if it looks presentation-related it is routed automatically by heading keywords (status `auto`), otherwise it stays `unmapped` and nothing is injected.
4. **Budgeting** - guidance is assembled per request (planner ≈ 8000 chars, reviewer ≈ 3200), never whole documents. Code blocks and tool-chain lines (npm, scripts, workspaces...) are removed because they cannot run on Termux. Truncation is recorded (`Guidance.truncated`), not silent.
5. **Reaching the model** - `deck_planner.build_system_prompt()` (designer / classic pipeline) and the reviewer prompt in `deck_team.py`. Every deck result carries `skills_used` and the planner's `brief` (audience, purpose, tone, assumptions).
6. **QA** - skill thresholds (titles ≥ 28 pt, body ≥ 16 pt, captions ≥ 9 pt) become warnings in `utils.pptx_qa.check_pptx`, together with blank-slide, overflow and off-slide checks.

Add your own skill: drop a folder with a `SKILL.md` into `backend/skills/` (or set `PPT_SKILLS_EXTRA`). Re-route a skill by editing `skill_map.json`.

## Conflict policy (also in `skill_map.json` → `conflicts`)

Precedence: **user settings → app safety/technical correctness → more specific rule → primary skill → first listed.**
Recorded conflicts: duplicate presentation-skill archives (C1), CLI/rendering workflow vs Termux (C2), "avoid generic blue" vs the user's `/style` (C3, the style always wins), bullets/tables vs "no templated cards" (C4), clarifying questions vs a bot that cannot wait (C5), web-page guidance (C6), GSAP vs PPTX (C7), font minimums vs dense content (C8).

## The 15-slide limit - where it is enforced

`utils/slide_limits.py` is the single source (`ABSOLUTE_MAX_SLIDES = 15`, minimum 1). The requested number is the **total** including cover and closing.

| Stage | Enforcement |
|---|---|
| Telegram input | `/slides 7` or buttons `1 3 5 6 8 10 12 15`; `/slides 20` → capped to 15 with a message; `0`/text → rejected; old saved settings and `BOT_DEFAULT_SLIDES` are clamped |
| Service input | `deck_service.normalize_slide_request()` (>15 capped, <1 / non-numeric → `DeckError`), also used by the Gemini team |
| Planner | system prompt states the exact count (1 slide = one summary slide, 2 = cover + closing, otherwise cover + N-2 + closing); user prompt says "EXACTLY N"; JSON `parse_plan(..., max_slides=N)` trims over-long answers (keeps cover & closing, drops section/agenda/quote/bullets first) |
| Classic outline fallback | `enforce_slide_cap` after `outline_to_deck` |
| Reviewer / repair loop | review prompt forbids adding slides; every repaired plan goes through `parse_plan(max_slides=N)`; `check_plan` reports "too many slides" as an error |
| Builder | `build_pptx()` itself trims to ≤ 15 (or `max_slides`) - protects every other caller, e.g. API endpoints |
| Final validation | `deck_service.finalize_pptx()` re-opens the **built file**, counts slides, rebuilds if over the limit, raises `DeckError` if it still is; `check_pptx(max_slides=N)` flags limit violations and blank slides |
| Telegram reply | `slide_count` in the caption is the real count of the file |

## Termux

```bash
bash ~/ppt-agent/scripts/run_bot.sh                         # start the bot
cd ~/ppt-agent/backend && python -m unittest discover -s tests -p "test_*.py"   # all tests
cd ~/ppt-agent/backend && python -m unittest tests.test_slide_limits tests.test_skill_integration   # new tests only
```
Only pure-Python dependencies were added (none): `pyyaml` and `python-pptx` were already required.

## Known limitations

* The supplied `ppt-agent-fixes.zip` was a partial set of files, not the full project. Files that were not in it (`agent/llm_client.py`, `agent/analyzer.py`, `main.py`, `utils/aspect_ratio.py`, `utils/languages.py`, `styles/presets.yaml`, the frontend, ...) were **not modified**. If `main.py` validates `slides` itself, the builder cap (15) still protects the output, but its own validation should be aligned with `utils.slide_limits`.
* Tests were run in a sandbox with small stand-ins for those missing files; the tests have **not** been run on the phone, with a real Gemini/OpenAI/Anthropic key, or against real Telegram.
* No rendered (image) review is possible on Termux; QA is geometric/structural only.
* Skill guidance improves prompts; it cannot guarantee the model's design taste or factual accuracy. Charts/stats may be marked `illustrative` and are then labelled as such; real figures still need checking by you.
* GSAP skills are registered but intentionally unused (see table).
