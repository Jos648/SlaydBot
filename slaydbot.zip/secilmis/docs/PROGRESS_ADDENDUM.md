
## Skill integration + 15-slide limit (secilmis.zip)

- NEW `backend/agent/skill_system.py`: automatic discovery/loading/caching of every `SKILL.md` (nested), stage routing via `backend/skills/skill_map.json`, budgeted guidance, conflict policy. Bundled skills in `backend/skills/` (presentation-skill = primary, older presentation-skill copy = fallback, frontend-design = active, 8 GSAP skills = registered only, not applicable to PPTX). Details: `docs/SKILL_INTEGRATION.md`.
- NEW `backend/utils/slide_limits.py`: hard maximum of 15 slides (minimum 1); enforced in Telegram `/slides`, service input, planner prompts, JSON parsing, review/repair loop, `build_pptx`, and a final check of the built file (`deck_service.finalize_pptx`).
- Planner: `build_system_prompt(images, max_slides, skills)`, `parse_plan(..., max_slides)`, optional `brief` (audience/purpose/tone), `illustrative` charts are labelled.
- QA: `check_plan(max_slides)`, `check_pptx(max_slides)` (limit, blank slides, readability minimums 28/16/9 pt from the skill).
- Telegram: `/slides N` (1-15), buttons 1 3 5 6 8 10 12 15, new `/skills` command.
- Tests: `backend/tests/test_slide_limits.py`, `backend/tests/test_skill_integration.py` (62 tests incl. the older ones passed in a sandbox with stand-ins for files that were not supplied; NOT run on a phone, NOT run with real API keys).
- Unfinished / next: run the tests on the device; align `main.py` (`/api/generate-pptx`) slide validation with `utils.slide_limits` if it validates by itself; optional PDF export; real-key quality check of the new prompts.
