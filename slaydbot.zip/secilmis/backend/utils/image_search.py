"""Topic photos from Pexels (free API key, stdlib only - works on Termux).

Everything here is *fail-soft*: no key, no network, a 401/429, an odd JSON
answer or a broken image all simply return ``None`` so the deck is built
without that picture instead of failing.

Get a free key at https://www.pexels.com/api/ and put it in ``.env``::

    PEXELS_API_KEY=...
"""

from __future__ import annotations

import io
import json
import logging
import os
import urllib.parse
import urllib.request
from concurrent.futures import ThreadPoolExecutor
from typing import Any

logger = logging.getLogger("ppt-agent")

DEFAULT_BASE = "https://api.pexels.com/v1"
MAX_IMAGE_BYTES = 8 * 1024 * 1024
MAX_PIXELS_WIDE = 1600          # downscale so the .pptx stays small
MAX_IMAGES_PER_DECK = 6
TIMEOUT = 12.0


def api_key() -> str:
    return (os.environ.get("PEXELS_API_KEY") or "").strip()


def images_enabled() -> bool:
    return bool(api_key())


def _base() -> str:
    return (os.environ.get("PEXELS_BASE_URL") or DEFAULT_BASE).rstrip("/")


def _host_ok(url: str) -> bool:
    """Only download from Pexels' own CDN (or the configured test server)."""
    try:
        host = urllib.parse.urlparse(url).hostname or ""
        scheme = urllib.parse.urlparse(url).scheme
    except ValueError:
        return False
    if host.endswith("pexels.com") and scheme == "https":
        return True
    return host == (urllib.parse.urlparse(_base()).hostname or "\0") and bool(os.environ.get("PEXELS_BASE_URL"))


def _get(url: str, headers: dict, limit: int) -> bytes:
    req = urllib.request.Request(url, headers={"User-Agent": "ppt-agent/1.0", **headers})
    with urllib.request.urlopen(req, timeout=TIMEOUT) as resp:
        data = resp.read(limit + 1)
    if len(data) > limit:
        raise ValueError("response too large")
    return data


def _search(query: str) -> dict | None:
    q = urllib.parse.urlencode({"query": query, "per_page": 8, "orientation": "landscape", "size": "large"})
    raw = _get(f"{_base()}/search?{q}", {"Authorization": api_key()}, 2_000_000)
    data = json.loads(raw.decode("utf-8", "replace"))
    photos = data.get("photos") if isinstance(data, dict) else None
    if not isinstance(photos, list):
        return None
    # best = widest landscape photo (looks sharpest when cropped)
    best, best_score = None, -1.0
    for p in photos:
        if not isinstance(p, dict) or not isinstance(p.get("src"), dict):
            continue
        w, h = p.get("width") or 0, p.get("height") or 0
        score = float(w) if (isinstance(w, (int, float)) and isinstance(h, (int, float)) and w >= h) else 0.0
        if best is None or score > best_score:
            best, best_score = p, score
    return best


def _prepare(data: bytes) -> bytes | None:
    """Validate it is a real image, downscale and re-encode as JPEG."""
    try:
        from PIL import Image
        im = Image.open(io.BytesIO(data))
        im.load()
    except Exception:
        return None
    if im.width < 200 or im.height < 150:
        return None
    if im.width > MAX_PIXELS_WIDE:
        im = im.resize((MAX_PIXELS_WIDE, max(1, round(im.height * MAX_PIXELS_WIDE / im.width))))
    if im.mode != "RGB":
        im = im.convert("RGB")
    out = io.BytesIO()
    im.save(out, format="JPEG", quality=82, optimize=True)
    return out.getvalue()


def fetch_photo(query: str) -> dict[str, Any] | None:
    """Best photo for ``query`` -> {"bytes", "credit", "query"} or None. Never raises."""
    query = " ".join((query or "").split())[:80]
    if not query or not images_enabled():
        return None
    words = query.split()
    attempts = [query] + ([" ".join(words[:2])] if len(words) > 2 else [])
    for q in attempts:
        try:
            photo = _search(q)
            if not photo:
                continue
            src = photo["src"]
            url = src.get("large2x") or src.get("large") or src.get("original")
            if not isinstance(url, str) or not _host_ok(url):
                continue
            img = _prepare(_get(url, {}, MAX_IMAGE_BYTES))
            if img:
                who = str(photo.get("photographer") or "").strip()[:60]
                return {"bytes": img, "credit": f"{who} / Pexels" if who else "Pexels", "query": q}
        except Exception as e:  # network, HTTP, JSON, anything
            logger.warning("Image search failed for %r: %s", q, e)
            if "401" in str(e) or "403" in str(e):
                return None     # bad key - no point retrying
    return None


def attach_images(deck: dict, max_images: int = MAX_IMAGES_PER_DECK) -> int:
    """Fetch a photo for every slide that has ``image_query``; sets ``slide['image']``.

    Returns the number of pictures attached. Does nothing without a key.
    """
    if not images_enabled():
        return 0
    jobs = []
    for s in deck.get("slides") or []:
        if isinstance(s, dict) and isinstance(s.get("image_query"), str) and s["image_query"].strip():
            jobs.append(s)
    jobs = jobs[:max_images]
    if not jobs:
        return 0
    with ThreadPoolExecutor(max_workers=4) as pool:
        results = list(pool.map(lambda s: fetch_photo(s["image_query"]), jobs))
    n = 0
    for s, r in zip(jobs, results):
        if r:
            s["image"] = r
            n += 1
    return n
