"""Deck quality checks that need no rendering (works on a phone / Termux).

check_plan(deck)  -> issues in the model's JSON plan (before building)
check_pptx(bytes) -> geometry issues in the built file (text overflow, shapes off-slide)
"""
from __future__ import annotations

import io
from dataclasses import dataclass

from pptx import Presentation

from .pptx_builder import LAYOUTS, _LAYOUT_ALIASES, _lines_needed
from .slide_limits import ABSOLUTE_MAX_SLIDES

EMU = 914400.0


@dataclass
class Issue:
    slide: int            # 1-based, 0 = whole deck
    severity: str         # "error" (must fix) | "warn"
    message: str

    def __str__(self) -> str:
        where = f"slide {self.slide}" if self.slide else "deck"
        return f"[{self.severity}] {where}: {self.message}"


def _words(text) -> int:
    return len(str(text or "").split())


def _layout(s: dict) -> str:
    lay = str(s.get("layout") or "").strip().lower()
    return _LAYOUT_ALIASES.get(lay, lay)


def _thresholds() -> dict:
    """Readability minimums (pt). Source: presentation-skill DESIGN.md / skill_map.json qa_thresholds."""
    try:
        from agent.skill_system import get_registry
        return get_registry().thresholds()
    except Exception:   # noqa: BLE001 - QA must work even if the skill system is unavailable
        return {"title_pt": 28, "body_pt": 16, "caption_pt": 9}


def count_slides(data: bytes) -> int:
    return len(Presentation(io.BytesIO(data)).slides)


def check_plan(deck: dict, max_slides: int | None = None) -> list[Issue]:
    out: list[Issue] = []
    slides = [s for s in (deck.get("slides") or []) if isinstance(s, dict)]
    n = len(slides)
    if n == 0:
        return [Issue(0, "error", "deck has no slides")]
    limit = min(max_slides or ABSOLUTE_MAX_SLIDES, ABSOLUTE_MAX_SLIDES)
    if n > limit:
        out.append(Issue(0, "error", f"deck has {n} slides but at most {limit} are allowed (cover and closing included)"))
    layouts = [_layout(s) for s in slides]
    if layouts[0] != "cover" and n > 1:
        out.append(Issue(1, "error", 'first slide must use layout "cover"'))
    if n > 2 and layouts[-1] != "closing":
        out.append(Issue(n, "error", 'last slide must use layout "closing"'))
    if n >= 8 and len({l for l in layouts if l}) < 4:
        out.append(Issue(0, "warn", "use at least 4 different layouts in a deck of 8+ slides"))
    if layouts.count("bullets") > 2:
        out.append(Issue(0, "warn", 'too many "bullets" slides; prefer cards/steps/compare/chart/table'))
    seen: set[str] = set()
    for i, s in enumerate(slides, 1):
        lay = layouts[i - 1]
        if lay and lay not in LAYOUTS:
            out.append(Issue(i, "error", f'unknown layout "{lay}"'))
        if i > 1 and lay and lay == layouts[i - 2]:
            out.append(Issue(i, "error", f'layout "{lay}" repeats on consecutive slides'))
        title = str(s.get("title") or "").strip()
        if lay not in ("quote",) and not title:
            out.append(Issue(i, "error", "slide has no title"))
        if _words(title) > 8:
            out.append(Issue(i, "warn", f"title is {_words(title)} words (max 8)"))
        if title and title.lower() in seen:
            out.append(Issue(i, "warn", "duplicate slide title"))
        seen.add(title.lower())

        if lay == "cards":
            items = s.get("items") or []
            if not 3 <= len(items) <= 6:
                out.append(Issue(i, "error", "cards needs 3-6 items"))
            for it in items:
                if isinstance(it, dict):
                    if not (it.get("heading") and it.get("text")):
                        out.append(Issue(i, "error", "every card needs a heading AND a text"))
                    if _words(it.get("text")) > 18:
                        out.append(Issue(i, "warn", "card text longer than 18 words"))
        elif lay == "bullets":
            b = s.get("bullets") or []
            if not 2 <= len(b) <= 5 or any(_words(x) > 14 for x in b):
                out.append(Issue(i, "warn", "bullets: use 3-5 bullets of max 14 words"))
        elif lay == "stats":
            st = s.get("stats") or []
            if not 2 <= len(st) <= 4:
                out.append(Issue(i, "error", "stats needs 2-4 numbers"))
        elif lay == "chart":
            ch = s.get("chart") or {}
            cats = ch.get("categories") or ch.get("labels") or []
            sers = ch.get("series") or []
            if len(cats) < 2 or not sers:
                out.append(Issue(i, "error", "chart needs categories (2+) and at least one series"))
            for sr in sers:
                vals = (sr or {}).get("values") or []
                if len(vals) != len(cats):
                    out.append(Issue(i, "error", "chart series length must equal categories length"))
                elif any(isinstance(v, (str, type(None))) and not str(v).replace(".", "", 1).replace(",", "", 1).strip("-% ").isdigit() for v in vals):
                    out.append(Issue(i, "error", "chart values must be plain numbers"))
        elif lay == "table":
            tb = s.get("table") or {}
            cols, rows = tb.get("columns") or [], tb.get("rows") or []
            if len(cols) < 2 or not rows:
                out.append(Issue(i, "error", "table needs 2+ columns and at least one row"))
            elif any(len(r) != len(cols) for r in rows if isinstance(r, list)):
                out.append(Issue(i, "error", "every table row must have as many cells as columns"))
        elif lay == "compare":
            if not (s.get("left") and s.get("right")):
                out.append(Issue(i, "error", "compare needs both left and right"))
        elif lay == "quote" and not s.get("quote"):
            out.append(Issue(i, "error", "quote slide has no quote"))
    return out


def check_pptx(data: bytes, max_slides: int | None = None) -> list[Issue]:
    """Final-file checks: slide limit, blank slides, text overflow, off-slide shapes, readability sizes."""
    prs = Presentation(io.BytesIO(data))
    sw, sh = prs.slide_width / EMU, prs.slide_height / EMU
    out: list[Issue] = []
    limit = min(max_slides or ABSOLUTE_MAX_SLIDES, ABSOLUTE_MAX_SLIDES)
    if len(prs.slides) > limit:
        out.append(Issue(0, "error", f"file has {len(prs.slides)} slides but the limit is {limit}"))
    th = _thresholds()
    for i, slide in enumerate(prs.slides, 1):
        has_content = any(
            (shp.has_text_frame and shp.text_frame.text.strip()) or shp.shape_type in (13, 3) or
            getattr(shp, "has_chart", False) or getattr(shp, "has_table", False)
            for shp in slide.shapes)
        if not has_content:
            out.append(Issue(i, "error", "slide is blank (no text, picture, chart or table)"))
        small: list[str] = []
        for shp in slide.shapes:
            if not shp.has_text_frame or len(shp.text_frame.text.strip()) <= 2:
                continue
            sizes = [r.font.size.pt for p in shp.text_frame.paragraphs for r in p.runs if r.font.size]
            if not sizes:
                continue
            nm = shp.name.lower()
            floor = (th["title_pt"] if nm.startswith("title") else
                     th["caption_pt"] if nm.startswith(("footer", "slide-number", "credit", "photo-credit")) else
                     th["body_pt"])
            if min(sizes) < floor - 0.01 and not nm.startswith(("subtitle", "badge", "card-")):
                small.append(f'{shp.name} {min(sizes):.0f}pt<{floor:.0f}pt')
        if small:
            out.append(Issue(i, "warn", "text below the readable minimum: " + ", ".join(small[:3])
                             + " (shorten the text instead of shrinking it)"))
        for shp in slide.shapes:
            x, y, w, h = shp.left / EMU, shp.top / EMU, shp.width / EMU, shp.height / EMU
            if x < -0.02 or y < -0.02 or x + w > sw + 0.02 or y + h > sh + 0.02:
                out.append(Issue(i, "warn", f'shape "{shp.name}" goes outside the slide'))
            txt = shp.text_frame.text.strip() if shp.has_text_frame else ""
            if len(txt) <= 2 or shp.name.startswith("footer"):   # empty, decorative glyphs, footer
                continue
            need = 0.06
            for p in shp.text_frame.paragraphs:
                text = "".join(r.text for r in p.runs)
                if not text:
                    continue
                size = next((r.font.size.pt for r in p.runs if r.font.size), 18.0)
                need += _lines_needed(text, size, max(0.3, w - 0.1)) * size * 1.2 / 72.0
            if need > h * 1.12 + 0.05:
                out.append(Issue(i, "warn", f'text in "{shp.name}" may overflow its box ({need:.1f}in > {h:.1f}in)'))
    return out
