"""Native-shape icon set for the slide builder.

Every icon is a *group of real PowerPoint shapes* (editable, recolourable, no images):
a tinted disc with the glyph drawn in the accent colour.

    draw_icon(slide, "chart", x, y, d, accent_rgb, tint_rgb, name="card-1-badge") -> bool

x, y, d are inches; colours are (r, g, b) tuples. Returns False for an unknown icon
so the caller can fall back to a numbered circle.
"""
from __future__ import annotations

from typing import Callable

from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_CONNECTOR, MSO_SHAPE as S
from pptx.enum.text import MSO_ANCHOR, PP_ALIGN
from pptx.util import Inches, Pt

Color = tuple[int, int, int]


def _rgb(c) -> RGBColor:
    """Accepts int or float channels (the builder mixes colours as floats)."""
    return RGBColor(*(max(0, min(255, int(round(v)))) for v in c))


class _Pen:
    """Draws inside a unit square (0..1) centred in the disc."""

    def __init__(self, slide, x: float, y: float, d: float, color: Color, tint: Color, name: str):
        self.name, self.d, self.color, self.tint = name, d, color, tint
        self.grp = slide.shapes.add_group_shape()
        self.grp.name = name
        self.sh = self.grp.shapes
        self.s = d * 0.54
        self.ox, self.oy = x + (d - self.s) / 2, y + (d - self.s) / 2
        self.lw = max(1.5, d * 3.4)
        self._n = 0
        disc = self.sh.add_shape(S.OVAL, Inches(x), Inches(y), Inches(d), Inches(d))
        disc.name = f"{name}-disc"
        disc.fill.solid()
        disc.fill.fore_color.rgb = _rgb(tint)
        disc.line.fill.background()
        disc.shadow.inherit = False

    def _col(self, c) -> RGBColor:
        return _rgb(self.color if c == "c" else self.tint)

    def _nm(self) -> str:
        self._n += 1
        return f"{self.name}-{self._n}"

    def shape(self, kind, u, v, w, h, fill="c", line=None, rot: float = 0, adj: float | None = None):
        shp = self.sh.add_shape(kind, Inches(self.ox + u * self.s), Inches(self.oy + v * self.s),
                                Inches(w * self.s), Inches(h * self.s))
        shp.name = self._nm()
        shp.shadow.inherit = False
        if fill:
            shp.fill.solid()
            shp.fill.fore_color.rgb = self._col(fill)
        else:
            shp.fill.background()
        if line:
            shp.line.color.rgb = self._col(line)
            shp.line.width = Pt(self.lw)
        else:
            shp.line.fill.background()
        if rot:
            shp.rotation = rot
        if adj is not None:
            shp.adjustments[0] = adj
        return shp

    def line(self, u1, v1, u2, v2, c="c", width: float | None = None):
        ln = self.sh.add_connector(MSO_CONNECTOR.STRAIGHT,
                                   Inches(self.ox + u1 * self.s), Inches(self.oy + v1 * self.s),
                                   Inches(self.ox + u2 * self.s), Inches(self.oy + v2 * self.s))
        ln.name = self._nm()
        ln.line.color.rgb = self._col(c)
        ln.line.width = Pt(width or self.lw)

    def text(self, txt: str, c="t", scale: float = 0.55):
        tb = self.sh.add_textbox(Inches(self.ox), Inches(self.oy), Inches(self.s), Inches(self.s))
        tb.name = self._nm()
        tf = tb.text_frame
        tf.margin_left = tf.margin_right = tf.margin_top = tf.margin_bottom = 0
        tf.word_wrap = False
        tf.vertical_anchor = MSO_ANCHOR.MIDDLE
        p = tf.paragraphs[0]
        p.alignment = PP_ALIGN.CENTER
        r = p.add_run()
        r.text = txt
        r.font.size = Pt(max(10, self.d * 72 * scale))
        r.font.bold = True
        r.font.name = "Calibri"
        r.font.color.rgb = self._col(c)


# ---------------------------------------------------------------------------
# Glyphs (unit-square coordinates)
# ---------------------------------------------------------------------------

def _star(p): p.shape(S.STAR_5_POINT, 0, 0.02, 1, 0.96)
def _heart(p): p.shape(S.HEART, 0, 0.08, 1, 0.86)
def _bolt(p): p.shape(S.LIGHTNING_BOLT, 0.06, 0, 0.88, 1)
def _sun(p): p.shape(S.SUN, 0, 0, 1, 1)
def _moon(p): p.shape(S.MOON, 0.2, 0, 0.6, 1)
def _cloud(p): p.shape(S.CLOUD, 0, 0.15, 1, 0.7)
def _arrow_up(p): p.shape(S.UP_ARROW, 0.15, 0, 0.7, 1)
def _health(p): p.shape(S.CROSS, 0.05, 0.05, 0.9, 0.9, adj=0.33)


def _gear(p):
    p.shape(S.GEAR_6, 0, 0, 1, 1)
    p.shape(S.OVAL, 0.35, 0.35, 0.30, 0.30, fill="t")


def _target(p):
    p.shape(S.OVAL, 0.02, 0.02, 0.96, 0.96, fill=None, line="c")
    p.shape(S.OVAL, 0.24, 0.24, 0.52, 0.52, fill=None, line="c")
    p.shape(S.OVAL, 0.42, 0.42, 0.16, 0.16)


def _check(p):
    p.line(0.06, 0.54, 0.38, 0.86, width=p.lw * 1.5)
    p.line(0.38, 0.86, 0.95, 0.16, width=p.lw * 1.5)


def _chart(p):
    p.shape(S.RECTANGLE, 0.02, 0.55, 0.26, 0.45)
    p.shape(S.RECTANGLE, 0.37, 0.28, 0.26, 0.72)
    p.shape(S.RECTANGLE, 0.72, 0.0, 0.26, 1.0)


def _user(p):
    p.shape(S.OVAL, 0.28, 0.0, 0.44, 0.44)
    p.shape(S.ROUND_2_SAME_RECTANGLE, 0.1, 0.52, 0.8, 0.48, adj=0.5)


def _users(p):
    p.shape(S.OVAL, 0.56, 0.04, 0.32, 0.32)
    p.shape(S.ROUND_2_SAME_RECTANGLE, 0.46, 0.42, 0.54, 0.58, adj=0.5)
    p.shape(S.OVAL, 0.14, 0.12, 0.38, 0.38, line="t")
    p.shape(S.ROUND_2_SAME_RECTANGLE, 0.0, 0.58, 0.66, 0.42, adj=0.5, line="t")


def _clock(p):
    p.shape(S.OVAL, 0.02, 0.02, 0.96, 0.96, fill=None, line="c")
    p.line(0.5, 0.5, 0.5, 0.2)
    p.line(0.5, 0.5, 0.74, 0.64)


def _document(p):
    p.shape(S.FOLDED_CORNER, 0.14, 0.0, 0.72, 1.0)
    for v, end in ((0.28, 0.7), (0.48, 0.7), (0.68, 0.55)):
        p.line(0.3, v, end, v, c="t", width=p.lw * 0.8)


def _book(p):
    p.shape(S.RECTANGLE, 0.0, 0.14, 0.47, 0.74)
    p.shape(S.RECTANGLE, 0.53, 0.14, 0.47, 0.74)
    p.shape(S.RECTANGLE, 0.1, 0.86, 0.8, 0.1)


def _shield(p):
    p.shape(S.FLOWCHART_OFFPAGE_CONNECTOR, 0.1, 0.0, 0.8, 1.0)
    p.line(0.3, 0.42, 0.45, 0.58, c="t")
    p.line(0.45, 0.58, 0.72, 0.28, c="t")


def _lock(p):
    p.shape(S.ROUNDED_RECTANGLE, 0.26, 0.0, 0.48, 0.62, fill=None, line="c", adj=0.5)
    p.shape(S.ROUNDED_RECTANGLE, 0.08, 0.38, 0.84, 0.62, adj=0.15)
    p.shape(S.OVAL, 0.43, 0.58, 0.14, 0.14, fill="t")


def _globe(p):
    p.shape(S.OVAL, 0.02, 0.02, 0.96, 0.96, fill=None, line="c")
    p.shape(S.OVAL, 0.3, 0.02, 0.4, 0.96, fill=None, line="c")
    p.line(0.02, 0.5, 0.98, 0.5, width=p.lw * 0.8)


def _lightbulb(p):
    p.shape(S.OVAL, 0.12, 0.0, 0.76, 0.76)
    p.shape(S.ROUNDED_RECTANGLE, 0.32, 0.78, 0.36, 0.12, adj=0.4)
    p.shape(S.ROUNDED_RECTANGLE, 0.38, 0.92, 0.24, 0.08, adj=0.5)


def _money(p):
    p.shape(S.OVAL, 0.0, 0.0, 1.0, 1.0)
    p.text("$")


def _home(p):
    p.shape(S.ISOSCELES_TRIANGLE, 0.0, 0.0, 1.0, 0.5)
    p.shape(S.RECTANGLE, 0.14, 0.48, 0.72, 0.52)
    p.shape(S.RECTANGLE, 0.42, 0.66, 0.16, 0.34, fill="t")


def _flag(p):
    p.shape(S.RECTANGLE, 0.08, 0.0, 0.08, 1.0)
    p.shape(S.WAVE, 0.16, 0.06, 0.8, 0.5)


def _mail(p):
    p.shape(S.RECTANGLE, 0.0, 0.15, 1.0, 0.7)
    p.line(0.02, 0.2, 0.5, 0.56, c="t", width=p.lw * 0.8)
    p.line(0.5, 0.56, 0.98, 0.2, c="t", width=p.lw * 0.8)


def _location(p):
    p.shape(S.TEAR, 0.14, 0.0, 0.72, 0.72, rot=135)
    p.shape(S.OVAL, 0.37, 0.24, 0.26, 0.26, fill="t")


def _phone(p):
    p.shape(S.ROUNDED_RECTANGLE, 0.22, 0.0, 0.56, 1.0, adj=0.15)
    p.shape(S.RECTANGLE, 0.3, 0.12, 0.4, 0.62, fill="t")
    p.shape(S.OVAL, 0.45, 0.82, 0.1, 0.1, fill="t")


def _code(p): p.text("</>", c="c", scale=0.5)
def _question(p): p.shape(S.OVAL, 0, 0, 1, 1); p.text("?")


def _camera(p):
    p.shape(S.RECTANGLE, 0.3, 0.06, 0.4, 0.18)
    p.shape(S.ROUNDED_RECTANGLE, 0.0, 0.2, 1.0, 0.72, adj=0.15)
    p.shape(S.OVAL, 0.3, 0.3, 0.4, 0.4, fill="t")
    p.shape(S.OVAL, 0.41, 0.41, 0.18, 0.18)


def _search(p):
    p.shape(S.OVAL, 0.02, 0.02, 0.66, 0.66, fill=None, line="c")
    p.line(0.6, 0.6, 0.97, 0.97, width=p.lw * 1.4)


def _network(p):
    for (u, v) in ((0.12, 0.12), (0.88, 0.12), (0.5, 0.9)):
        p.line(0.5, 0.45, u, v, width=p.lw * 0.8)
    p.shape(S.OVAL, 0.34, 0.29, 0.32, 0.32)
    for (u, v) in ((0.0, 0.0), (0.76, 0.0), (0.38, 0.76)):
        p.shape(S.OVAL, u, v, 0.24, 0.24)


def _leaf(p):
    p.shape(S.TEAR, 0.05, 0.05, 0.9, 0.9)
    p.line(0.2, 0.8, 0.7, 0.3, c="t", width=p.lw * 0.8)


_ICONS: dict[str, Callable] = {
    "star": _star, "heart": _heart, "bolt": _bolt, "sun": _sun, "moon": _moon, "cloud": _cloud,
    "gear": _gear, "target": _target, "check": _check, "chart": _chart, "user": _user,
    "users": _users, "clock": _clock, "document": _document, "book": _book, "shield": _shield,
    "lock": _lock, "globe": _globe, "lightbulb": _lightbulb, "money": _money, "home": _home,
    "flag": _flag, "arrow_up": _arrow_up, "mail": _mail, "location": _location, "phone": _phone,
    "code": _code, "question": _question, "health": _health, "camera": _camera,
    "search": _search, "network": _network, "leaf": _leaf,
}

ICON_NAMES = list(_ICONS)

_ALIASES = {
    "growth": "chart", "graph": "chart", "analytics": "chart", "statistics": "chart",
    "people": "users", "team": "users", "community": "users", "person": "user",
    "time": "clock", "schedule": "clock", "file": "document", "report": "document",
    "education": "book", "learning": "book", "school": "book", "security": "shield",
    "protection": "shield", "safe": "shield", "idea": "lightbulb", "bulb": "lightbulb",
    "innovation": "lightbulb", "coin": "money", "dollar": "money", "finance": "money",
    "budget": "money", "house": "home", "energy": "bolt", "lightning": "bolt", "power": "bolt",
    "settings": "gear", "process": "gear", "tools": "gear", "goal": "target", "aim": "target",
    "success": "check", "done": "check", "world": "globe", "global": "globe", "earth": "globe",
    "email": "mail", "message": "mail", "pin": "location", "map": "location", "place": "location",
    "mobile": "phone", "programming": "code", "dev": "code", "help": "question",
    "medical": "health", "hospital": "health", "photo": "camera", "find": "search",
    "magnifier": "search", "link": "network", "connection": "network", "eco": "leaf",
    "nature": "leaf", "plant": "leaf", "up": "arrow_up", "rocket": "arrow_up", "trend": "arrow_up",
}


def draw_icon(slide, kind: str, x: float, y: float, d: float, color: Color, tint: Color,
              name: str = "icon") -> bool:
    key = str(kind or "").strip().lower().replace("-", "_").replace(" ", "_")
    fn = _ICONS.get(_ALIASES.get(key, key))
    if fn is None:
        return False
    pen = None
    try:
        pen = _Pen(slide, x, y, d, color, tint, name)
        fn(pen)
    except Exception:                      # never leave a half-drawn icon behind
        if pen is not None:
            el = pen.grp._element
            el.getparent().remove(el)
        return False
    return True
