"""Single source of truth for the slide-count rules.

* ``ABSOLUTE_MAX_SLIDES`` (15) can never be exceeded: not by the user's setting, not by the model's
  answer, not by a title/closing slide, not by a repair round (``build_pptx`` enforces it too).
* The requested number is the TOTAL, cover and closing slide included.
* Values above 15 are capped to 15 (the bot's existing UX); zero, negative or non-numeric values are
  rejected with ``SlideCountError``.
* One-slide decks are supported (a single summary slide); a two-slide deck is cover + closing.
"""
from __future__ import annotations

import re
from typing import Any

ABSOLUTE_MAX_SLIDES = 15
MIN_SLIDES = 1
DEFAULT_SLIDES = 8


class SlideCountError(ValueError):
    """The slide count is not a usable positive integer."""


def parse_slide_count(value: Any) -> int:
    """Return a valid slide count in ``1..15``. Counts above 15 are capped; garbage is rejected."""
    if isinstance(value, bool):
        raise SlideCountError("Slide count must be a number.")
    if isinstance(value, (int, float)):
        n = int(value) if float(value).is_integer() else None
    else:
        m = re.fullmatch(r"\s*(-?\d{1,4})\s*(?:[^\d\s-]\w*)?\s*", str(value or ""))
        n = int(m.group(1)) if m else None
    if n is None:
        raise SlideCountError("Slide count must be a whole number.")
    if n < MIN_SLIDES:
        raise SlideCountError(f"Slide count must be between {MIN_SLIDES} and {ABSOLUTE_MAX_SLIDES}.")
    return min(n, ABSOLUTE_MAX_SLIDES)


def was_capped(value: Any) -> bool:
    try:
        raw = int(re.search(r"-?\d+", str(value)).group())     # type: ignore[union-attr]
    except (AttributeError, ValueError):
        return False
    return raw > ABSOLUTE_MAX_SLIDES


def _layout(spec: dict) -> str:
    return str(spec.get("layout") or spec.get("content_type") or "").strip().lower()


# Lower = more valuable. Dropped from the highest rank (and latest position) first.
_DROP_RANK = {"section": 6, "agenda": 5, "quote": 4, "bullets": 4, "content": 4, "image": 3}


def enforce_slide_cap(deck: dict, limit: int) -> dict:
    """Return a copy of ``deck`` with at most ``limit`` slides (never mutates the input).

    Keeps the cover and the closing slide, drops the least valuable middle slides first.
    """
    limit = max(MIN_SLIDES, min(int(limit), ABSOLUTE_MAX_SLIDES))
    slides = [s for s in (deck.get("slides") or []) if isinstance(s, dict)]
    out = dict(deck)
    if len(slides) <= limit:
        out["slides"] = slides
        return out
    if limit == 1:
        body = next((s for s in slides if _layout(s) not in ("cover", "closing", "section", "agenda")), slides[0])
        out["slides"] = [body]
        return out
    first = slides[0]
    last = slides[-1] if _layout(slides[-1]) == "closing" and len(slides) > 1 else None
    middle = list(enumerate(slides[1:-1] if last else slides[1:], start=1))
    keep_n = limit - 1 - (1 if last else 0)
    while len(middle) > keep_n:
        victim = max(range(len(middle)), key=lambda k: (_DROP_RANK.get(_layout(middle[k][1]), 2), middle[k][0]))
        middle.pop(victim)
    out["slides"] = [first] + [s for _i, s in middle] + ([last] if last else [])
    return out
