"""Native PowerPoint builder — turns a structured deck into a designed .pptx.

Why this exists
---------------
``utils.pptx_export.html_to_pptx`` scrapes text out of the generated HTML,
which needs the whole (heavy) HTML pipeline. This builder works directly from
the outline the analyzer produces (title, subtitle, slides with bullets) and
draws real, editable PowerPoint shapes using the colours of the project's own
style presets (``styles/presets.yaml``). It needs only ``python-pptx`` (+
``pyyaml``), so it runs fine on Termux / Android — no browser involved.

Deck format (plain dict, JSON friendly)::

    {"title": "...", "subtitle": "...",
     "slides": [{"title": "...", "content_type": "cover|content|closing",
                 "bullets": ["...", ...], "notes": "optional speaker notes"}]}
"""

from __future__ import annotations

import io
import logging
import math
import os
import re
from pathlib import Path
from typing import Any

import yaml
from pptx import Presentation
from pptx.chart.data import CategoryChartData
from pptx.enum.chart import XL_CHART_TYPE, XL_LABEL_POSITION, XL_LEGEND_POSITION
from pptx.dml.color import RGBColor
from pptx.enum.shapes import MSO_SHAPE
from pptx.enum.text import MSO_ANCHOR, PP_ALIGN
from pptx.util import Inches, Pt

from .aspect_ratio import DEFAULT as DEFAULT_RATIO, slide_size_inches
from .pptx_icons import draw_icon
from .slide_limits import ABSOLUTE_MAX_SLIDES, enforce_slide_cap

logger = logging.getLogger("ppt-agent")

PRESETS_PATH = Path(__file__).parent.parent / "styles" / "presets.yaml"
DEFAULT_STYLE = "corporate-navy"
MAX_BULLETS = 6

_NS_A = "http://schemas.openxmlformats.org/drawingml/2006/main"


# ---------------------------------------------------------------------------
# Colours
# ---------------------------------------------------------------------------

def _parse_color(value: Any) -> tuple[int, int, int, float] | None:
    """'#rgb' | '#rrggbb' | 'rgb(...)' | 'rgba(...)' -> (r, g, b, alpha)."""
    if not isinstance(value, str):
        return None
    v = value.strip()
    m = re.fullmatch(r"#([0-9a-fA-F]{3}|[0-9a-fA-F]{6})", v)
    if m:
        h = m.group(1)
        if len(h) == 3:
            h = "".join(c * 2 for c in h)
        return int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16), 1.0
    m = re.fullmatch(r"rgba?\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*(?:,\s*([\d.]+)\s*)?\)", v)
    if m:
        a = float(m.group(4)) if m.group(4) is not None else 1.0
        return int(m.group(1)), int(m.group(2)), int(m.group(3)), a
    return None


def _hex(rgb: tuple[int, int, int]) -> str:
    return "%02X%02X%02X" % tuple(max(0, min(255, int(round(c)))) for c in rgb)


def _rgb(rgb: tuple[int, int, int]) -> RGBColor:
    return RGBColor.from_string(_hex(rgb))


def _mix(a: tuple[int, int, int], b: tuple[int, int, int], t: float) -> tuple[int, int, int]:
    """Blend a -> b by factor t (0..1)."""
    return tuple(a[i] + (b[i] - a[i]) * t for i in range(3))  # type: ignore[return-value]


def _lum(rgb: tuple[int, int, int]) -> float:
    return (0.299 * rgb[0] + 0.587 * rgb[1] + 0.114 * rgb[2]) / 255


def _first_color(colors: dict, *keys: str) -> tuple[int, int, int] | None:
    for k in keys:
        c = _parse_color(colors.get(k))
        if c:
            return c[:3]
    return None


class Palette:
    """Resolved slide colours derived from a style preset."""

    def __init__(self, bg, text, accent, muted, card, accent_text):
        self.bg = bg
        self.text = text
        self.accent = accent
        self.muted = muted
        self.card = card
        self.accent_text = accent_text  # readable text colour ON the accent colour


def load_presets() -> dict:
    try:
        with open(PRESETS_PATH, encoding="utf-8") as f:
            return yaml.safe_load(f) or {}
    except Exception as e:  # pragma: no cover - missing/invalid file
        logger.warning("Could not read presets: %s", e)
        return {}


def resolve_palette(style: str | None, presets: dict | None = None) -> Palette:
    presets = presets if presets is not None else load_presets()
    colors = (presets.get(style or DEFAULT_STYLE) or presets.get(DEFAULT_STYLE) or {}).get("colors", {}) or {}

    text = _first_color(colors, "text_primary", "text", "fg")
    bg = _first_color(colors, "bg_primary", "bg", "background", "bg_secondary")
    if bg is None:
        # No usable background: pick one that contrasts with the text colour.
        bg = (255, 255, 255) if (text is None or _lum(text) < 0.5) else (17, 17, 17)
    if text is None:
        text = (17, 24, 39) if _lum(bg) > 0.5 else (245, 245, 245)

    accent = _first_color(colors, "accent", "accent_warm", "accent_primary", "primary")
    if accent is None:
        card = _first_color(colors, "card_bg")
        accent = card if card and abs(_lum(card) - _lum(bg)) > 0.2 else (37, 99, 235)
    # Make sure the accent is visible against the background.
    if abs(_lum(accent) - _lum(bg)) < 0.15:
        accent = (37, 99, 235) if _lum(bg) > 0.5 else (96, 165, 250)

    dim = _parse_color(colors.get("text_dim"))
    muted = _mix(bg, text, dim[3] if dim else 0.65) if dim else _mix(bg, text, 0.65)
    card = _mix(bg, text, 0.07)
    accent_text = (255, 255, 255) if _lum(accent) < 0.6 else (17, 17, 17)
    return Palette(bg, text, accent, muted, card, accent_text)


# ---------------------------------------------------------------------------
# Text helpers
# ---------------------------------------------------------------------------

_MD_STRIP = [
    (re.compile(r"\*\*(.+?)\*\*"), r"\1"),
    (re.compile(r"__(.+?)__"), r"\1"),
    (re.compile(r"`([^`]+)`"), r"\1"),
    (re.compile(r"^\s*(?:[-*•▪●◦]\s+|\d+[.)]\s+)"), ""),
]


def clean_text(s: Any) -> str:
    """Strip markdown / list markers so text is safe to drop into a shape."""
    text = "" if s is None else str(s)
    for pat, rep in _MD_STRIP:
        text = pat.sub(rep, text)
    # Control characters are illegal in OOXML text.
    text = re.sub(r"[\x00-\x08\x0b\x0c\x0e-\x1f]", "", text)
    return re.sub(r"[ \t]+", " ", text).strip()


def _char_width(ch: str) -> float:
    """Average glyph width as a fraction of the font size."""
    o = ord(ch)
    if 0x2E80 <= o <= 0x9FFF or 0xAC00 <= o <= 0xD7AF or 0xFF00 <= o <= 0xFFEF:
        return 1.0
    if ch == " ":
        return 0.3
    return 0.54


def _text_width_em(text: str) -> float:
    return sum(_char_width(c) for c in text)


def _lines_needed(text: str, size_pt: float, width_in: float) -> int:
    per_line = max(1.0, width_in * 72.0 / size_pt)
    return max(1, math.ceil(_text_width_em(text) / per_line))


def fit_font_size(texts: list[str], width_in: float, height_in: float,
                  max_pt: float, min_pt: float = 10.0, line_spacing: float = 1.22,
                  para_gap_pt: float = 8.0) -> float:
    """Largest font size (step 1pt) at which all paragraphs fit the box."""
    size = max_pt
    longest_word = max((_text_width_em(w) for t in texts for w in t.split()), default=0.0)
    while size > min_pt:
        if longest_word * size / 72.0 > width_in * 0.97:   # never break a word in the middle
            size -= 1
            continue
        total = 0.0
        for t in texts:
            total += _lines_needed(t, size, width_in) * size * line_spacing + para_gap_pt
        if total / 72.0 <= height_in:
            return size
        size -= 1
    return min_pt


def _font_name() -> str:
    return os.environ.get("PPT_FONT", "Calibri")


# ---------------------------------------------------------------------------
# Low-level shape helpers
# ---------------------------------------------------------------------------

def _set_background(slide, color) -> None:
    fill = slide.background.fill
    fill.solid()
    fill.fore_color.rgb = _rgb(color)


def _rect(slide, x, y, w, h, color, shape=MSO_SHAPE.RECTANGLE, name=None):
    shp = slide.shapes.add_shape(shape, Inches(x), Inches(y), Inches(w), Inches(h))
    shp.fill.solid()
    shp.fill.fore_color.rgb = _rgb(color)
    shp.line.fill.background()
    shp.shadow.inherit = False
    if name:
        shp.name = name
    return shp


def _textbox(slide, x, y, w, h, name=None, anchor=MSO_ANCHOR.TOP):
    tb = slide.shapes.add_textbox(Inches(x), Inches(y), Inches(w), Inches(h))
    tf = tb.text_frame
    tf.word_wrap = True
    tf.margin_left = tf.margin_right = Inches(0.05)
    tf.margin_top = tf.margin_bottom = Inches(0.03)
    tf.vertical_anchor = anchor
    if name:
        tb.name = name
    return tb, tf


def _style_run(run, size, color, bold=False, italic=False):
    run.font.size = Pt(size)
    run.font.bold = bold
    run.font.italic = italic
    run.font.name = _font_name()
    run.font.color.rgb = _rgb(color)


def _write_text(tf, text, size, color, bold=False, align=PP_ALIGN.LEFT, line_spacing=1.0):
    p = tf.paragraphs[0]
    p.alignment = align
    p.line_spacing = line_spacing
    r = p.add_run()
    r.text = text
    _style_run(r, size, color, bold)
    return p


def _add_bullet_paragraph(tf, first, text, size, text_color, bullet_color, gap_pt):
    """Paragraph with a *native* PowerPoint bullet (editable, hanging indent)."""
    p = tf.paragraphs[0] if first else tf.add_paragraph()
    p.space_after = Pt(gap_pt)
    p.line_spacing = 1.08
    r = p.add_run()
    r.text = text
    _style_run(r, size, text_color)

    pPr = p._p.get_or_add_pPr()
    indent = int(Pt(size * 1.1))
    pPr.set("marL", str(indent))
    pPr.set("indent", str(-indent))
    from lxml import etree
    for tag in ("buClr", "buSzPct", "buFont", "buChar"):
        for old in pPr.findall(f"{{{_NS_A}}}{tag}"):
            pPr.remove(old)
    buClr = etree.SubElement(pPr, f"{{{_NS_A}}}buClr")
    clr = etree.SubElement(buClr, f"{{{_NS_A}}}srgbClr")
    clr.set("val", _hex(bullet_color))
    buSz = etree.SubElement(pPr, f"{{{_NS_A}}}buSzPct")
    buSz.set("val", "100000")
    buFont = etree.SubElement(pPr, f"{{{_NS_A}}}buFont")
    buFont.set("typeface", "Arial")
    buChar = etree.SubElement(pPr, f"{{{_NS_A}}}buChar")
    buChar.set("char", "■")
    return p


def _set_notes(slide, notes: str) -> None:
    if notes:
        slide.notes_slide.notes_text_frame.text = clean_text(notes) if "\n" not in notes else notes.strip()


# ---------------------------------------------------------------------------
# Photos
# ---------------------------------------------------------------------------

def _set_alpha(shape, alpha: float) -> None:
    """Make a solid-filled shape translucent (alpha 0..1 = opacity)."""
    from lxml import etree
    clr = shape._element.spPr.find(f".//{{{_NS_A}}}solidFill/{{{_NS_A}}}srgbClr")
    if clr is not None:
        for old in clr.findall(f"{{{_NS_A}}}alpha"):
            clr.remove(old)
        a = etree.SubElement(clr, f"{{{_NS_A}}}alpha")
        a.set("val", str(int(max(0.0, min(1.0, alpha)) * 100000)))


def _add_photo(slide, data: bytes, x, y, w, h, name="photo"):
    """Place a photo so that it fills the box (centre-cropped, never stretched)."""
    from PIL import Image
    im = Image.open(io.BytesIO(data))
    iw, ih = im.size
    pic = slide.shapes.add_picture(io.BytesIO(data), Inches(x), Inches(y), Inches(w), Inches(h))
    tr, ir = w / h, iw / ih
    if ir > tr:       # image wider than box -> crop left/right
        c = (1 - tr / ir) / 2
        pic.crop_left = pic.crop_right = c
    else:             # image taller than box -> crop top/bottom
        c = (1 - ir / tr) / 2
        pic.crop_top = pic.crop_bottom = c
    pic.left, pic.top, pic.width, pic.height = Inches(x), Inches(y), Inches(w), Inches(h)
    pic.name = name
    return pic


def _credit_strip(slide, x, y_bottom, w, credit: str) -> None:
    """Small 'Foto: name / Pexels' caption on a translucent dark strip."""
    if not credit:
        return
    h = 0.3
    strip = _rect(slide, x, y_bottom - h, w, h, (0, 0, 0), name="photo-credit-strip")
    _set_alpha(strip, 0.55)
    tb, tf = _textbox(slide, x + 0.1, y_bottom - h, w - 0.2, h, name="photo-credit", anchor=MSO_ANCHOR.MIDDLE)
    _write_text(tf, f"Foto: {credit}", 9, (255, 255, 255))


def _get_photo(spec: dict) -> bytes | None:
    img = spec.get("image")
    if isinstance(img, dict) and isinstance(img.get("bytes"), (bytes, bytearray)) and img["bytes"]:
        return bytes(img["bytes"])
    return None


# ---------------------------------------------------------------------------
# Slide renderers
# ---------------------------------------------------------------------------

class _Frame:
    """Geometry of the slide in inches + convenience margins."""

    def __init__(self, w: float, h: float):
        self.w, self.h = w, h
        self.mx = max(0.6, w * 0.065)         # horizontal margin
        self.my = max(0.5, h * 0.08)          # vertical margin
        self.cw = w - 2 * self.mx             # content width
        self.small = w < 9                    # 1:1 / narrow canvases


def _footer(slide, fr: _Frame, pal: Palette, index: int, total: int, deck_title: str,
            x0: float | None = None, x1: float | None = None):
    y = fr.h - 0.5
    x0 = fr.mx if x0 is None else x0
    x1 = fr.w - fr.mx if x1 is None else x1
    _rect(slide, x0, y - 0.06, x1 - x0, 0.012, _mix(pal.bg, pal.text, 0.18), name="footer-rule")
    tb, tf = _textbox(slide, x0, y, (x1 - x0) * 0.7, 0.3, name="footer-title")
    _write_text(tf, deck_title[:80], 10, pal.muted)
    tb, tf = _textbox(slide, x1 - 1.2, y, 1.2, 0.3, name="slide-number")
    _write_text(tf, f"{index} / {total}", 10, pal.muted, align=PP_ALIGN.RIGHT)


def _title_block(slide, fr: _Frame, pal: Palette, title: str, number: str | None = None):
    """Section title + accent bar. Returns the y where the body can start."""
    top = fr.my * 0.75
    x = fr.mx
    width = fr.w - fr.mx - x
    size = fit_font_size([title], width, 1.0, max_pt=36 if not fr.small else 28, min_pt=20, para_gap_pt=0)
    tb, tf = _textbox(slide, x, top, width, 1.0, name="title", anchor=MSO_ANCHOR.MIDDLE)
    _write_text(tf, title, size, pal.text, bold=True, line_spacing=0.95)
    _rect(slide, fr.mx, top + 1.08, 0.9, 0.07, pal.accent, name="accent-bar")
    return top + 1.5


def _render_cover(slide, fr, pal, deck_title, subtitle, photo=None, credit=""):
    _set_background(slide, pal.bg)
    _rect(slide, 0, 0, fr.w * 0.025, fr.h, pal.accent, name="side-accent")
    px = fr.w * (0.56 if photo else 0.72)       # where the right-hand visual starts
    pw = fr.w - px
    if photo:
        _add_photo(slide, photo, px, 0, pw, fr.h, name="cover-photo")
        _rect(slide, px, 0, 0.09, fr.h, pal.accent, name="photo-edge")
        _credit_strip(slide, px, fr.h, pw, credit)
    else:
        # big soft block on the right for visual weight
        _rect(slide, px, 0, pw, fr.h, _mix(pal.bg, pal.accent, 0.12), name="right-panel")
        _rect(slide, px, fr.h * 0.62, pw, fr.h * 0.38, _mix(pal.bg, pal.accent, 0.22), name="right-panel-2")
        d = min(pw * 0.8, fr.h * 0.4)
        _rect(slide, px + pw * 0.1, fr.h * 0.1, d, d, _mix(pal.bg, pal.accent, 0.35),
              shape=MSO_SHAPE.OVAL, name="deco-circle-1")
        d2 = d * 0.55
        _rect(slide, px + pw * 0.45, fr.h * 0.1 + d * 0.72, d2, d2, pal.accent,
              shape=MSO_SHAPE.OVAL, name="deco-circle-2")
        d3 = d * 0.22
        _rect(slide, px + pw * 0.12, fr.h * 0.1 + d * 1.05, d3, d3, _mix(pal.bg, pal.accent, 0.6),
              shape=MSO_SHAPE.OVAL, name="deco-circle-3")

    x = fr.mx + 0.2
    width = px - x - 0.3   # keep clear of the right-hand visual
    size = fit_font_size([deck_title], width, fr.h * 0.38, max_pt=54 if not fr.small else 38,
                         min_pt=24, para_gap_pt=0, line_spacing=1.05)
    tb, tf = _textbox(slide, x, fr.h * 0.24, width, fr.h * 0.38, name="title", anchor=MSO_ANCHOR.BOTTOM)
    _write_text(tf, deck_title, size, pal.text, bold=True, line_spacing=0.95)
    _rect(slide, x + 0.05, fr.h * 0.24 + fr.h * 0.38 + 0.18, 1.1, 0.08, pal.accent, name="accent-bar")
    if subtitle:
        ssize = fit_font_size([subtitle], width, fr.h * 0.2, max_pt=22, min_pt=13, para_gap_pt=0)
        tb, tf = _textbox(slide, x, fr.h * 0.24 + fr.h * 0.38 + 0.4, width, fr.h * 0.2, name="subtitle")
        _write_text(tf, subtitle, ssize, pal.muted)


def _render_closing(slide, fr, pal, title, bullets, deck_title):
    _set_background(slide, pal.bg)
    _rect(slide, 0, 0, fr.w, fr.h * 0.5, _mix(pal.bg, pal.accent, 0.10), name="top-band")
    _rect(slide, fr.w / 2 - 0.5, fr.h * 0.5 - 0.04, 1.0, 0.08, pal.accent, name="accent-bar")
    width = fr.w - 2 * fr.mx
    size = fit_font_size([title], width, fr.h * 0.3, max_pt=48 if not fr.small else 34, min_pt=24,
                         para_gap_pt=0, line_spacing=1.05)
    tb, tf = _textbox(slide, fr.mx, fr.h * 0.18, width, fr.h * 0.3, name="title", anchor=MSO_ANCHOR.BOTTOM)
    _write_text(tf, title, size, pal.text, bold=True, align=PP_ALIGN.CENTER, line_spacing=0.95)
    lines = [b for b in bullets if b][:3]
    if lines:
        bsize = fit_font_size(lines, width * 0.8, fr.h * 0.3, max_pt=20, min_pt=12)
        tb, tf = _textbox(slide, fr.mx + width * 0.1, fr.h * 0.58, width * 0.8, fr.h * 0.3, name="closing-lines")
        for i, line in enumerate(lines):
            p = tf.paragraphs[0] if i == 0 else tf.add_paragraph()
            p.alignment = PP_ALIGN.CENTER
            p.space_after = Pt(8)
            r = p.add_run()
            r.text = line
            _style_run(r, bsize, pal.muted)
    tb, tf = _textbox(slide, fr.mx, fr.h - 0.6, fr.w - 2 * fr.mx, 0.3, name="footer-title")
    _write_text(tf, deck_title[:80], 10, pal.muted, align=PP_ALIGN.CENTER)


def _render_list(slide, fr, pal, title, bullets, number=None):
    _set_background(slide, pal.bg)
    y0 = _title_block(slide, fr, pal, title, number)
    body_h = fr.h - y0 - 0.8
    size = fit_font_size(bullets, fr.cw - 0.4, body_h, max_pt=28 if not fr.small else 22, min_pt=12)
    tb, tf = _textbox(slide, fr.mx, y0, fr.cw, body_h, name="bullets",
                      anchor=MSO_ANCHOR.MIDDLE if len(bullets) <= 5 else MSO_ANCHOR.TOP)
    for i, b in enumerate(bullets):
        _add_bullet_paragraph(tf, i == 0, b, size, pal.text, pal.accent, gap_pt=size * 0.55)


def _render_cards(slide, fr, pal, title, bullets, number=None):
    """2-4 bullets as numbered cards (grid adapts to count / canvas)."""
    _set_background(slide, pal.bg)
    y0 = _title_block(slide, fr, pal, title, number)
    n = len(bullets)
    cols = n if (n <= 3 and not fr.small) else 2
    rows = math.ceil(n / cols)
    gap = 0.3
    area_h = fr.h - y0 - 0.85
    cw = (fr.cw - gap * (cols - 1)) / cols
    ch = min((area_h - gap * (rows - 1)) / rows, 3.3)
    # centre the grid vertically in the free area when cards are capped
    y0 += max(0.0, (area_h - (ch * rows + gap * (rows - 1))) / 2) * 0.6
    for i, b in enumerate(bullets):
        r, c = divmod(i, cols)
        x = fr.mx + c * (cw + gap)
        y = y0 + r * (ch + gap)
        _rect(slide, x, y, cw, ch, pal.card, name=f"card-{i + 1}")
        _rect(slide, x, y, cw, 0.07, pal.accent, name=f"card-{i + 1}-bar")
        tb, tf = _textbox(slide, x + 0.2, y + 0.2, cw - 0.4, 0.6, name=f"card-{i + 1}-num")
        _write_text(tf, f"{i + 1:02d}", 26, pal.accent, bold=True)
        body_h = ch - 1.0
        size = fit_font_size([b], cw - 0.4, body_h, max_pt=24 if not fr.small else 18, min_pt=11, para_gap_pt=0)
        tb, tf = _textbox(slide, x + 0.2, y + 0.85, cw - 0.4, body_h, name=f"card-{i + 1}-text")
        _write_text(tf, b, size, pal.text, line_spacing=1.05)


def _render_split(slide, fr, pal, title, bullets, number=None):
    """Coloured title panel on the left, bullets on the right."""
    _set_background(slide, pal.bg)
    if fr.small:
        return _render_list(slide, fr, pal, title, bullets, number)
    panel_w = fr.w * 0.36
    _rect(slide, 0, 0, panel_w, fr.h, pal.accent, name="title-panel")
    if number:
        tb, tf = _textbox(slide, fr.mx * 0.7, fr.my, panel_w - fr.mx, 1.0, name="section-number")
        _write_text(tf, number, 44, _mix(pal.accent, pal.accent_text, 0.45), bold=True)
    width = panel_w - fr.mx * 1.3
    size = fit_font_size([title], width, fr.h * 0.45, max_pt=34, min_pt=18, para_gap_pt=0, line_spacing=1.05)
    tb, tf = _textbox(slide, fr.mx * 0.7, fr.h * 0.3, width, fr.h * 0.45, name="title", anchor=MSO_ANCHOR.MIDDLE)
    _write_text(tf, title, size, pal.accent_text, bold=True, line_spacing=0.95)
    x = panel_w + fr.mx * 0.7
    w = fr.w - x - fr.mx
    body_h = fr.h - 2 * fr.my - 0.3
    bsize = fit_font_size(bullets, w - 0.3, body_h, max_pt=24, min_pt=12)
    tb, tf = _textbox(slide, x, fr.my, w, body_h, name="bullets", anchor=MSO_ANCHOR.MIDDLE)
    for i, b in enumerate(bullets):
        _add_bullet_paragraph(tf, i == 0, b, bsize, pal.text, pal.accent, gap_pt=bsize * 0.6)


# ---------------------------------------------------------------------------
# Rich layouts (cards with icons, stats, steps, compare, quote, agenda, section)
# ---------------------------------------------------------------------------

def _split_heading(text: str) -> tuple[str, str]:
    """'Heading — detail' / 'Heading: detail' -> (heading, detail); else ('', text)."""
    for sep in (" — ", " – ", ": ", " - "):
        if sep in text:
            head, rest = text.split(sep, 1)
            if 2 <= len(head) <= 42 and rest.strip():
                return head.strip(' "“”'), rest.strip()
    return "", text


def _badge(slide, fr, pal, kind, number, x, y, d, name):
    """Icon in a tinted circle, or a numbered circle when there is no icon."""
    tint = _mix(pal.bg, pal.accent, 0.16)
    if kind and draw_icon(slide, kind, x, y, d, pal.accent, tint, name=name):
        return
    disc = _rect(slide, x, y, d, d, pal.accent, shape=MSO_SHAPE.OVAL, name=f"{name}-disc")
    tb, tf = _textbox(slide, x, y, d, d, name=f"{name}-num", anchor=MSO_ANCHOR.MIDDLE)
    tf.margin_left = tf.margin_right = 0
    _write_text(tf, str(number), max(12, d * 30), pal.accent_text, bold=True, align=PP_ALIGN.CENTER)


def _render_cards_rich(slide, fr, pal, title, items):
    _set_background(slide, pal.bg)
    y0 = _title_block(slide, fr, pal, title)
    n = len(items)
    if fr.small:
        cols = 1 if n <= 3 else 2
    else:
        cols = 3 if n in (3, 5, 6) else 2 if n in (2, 4) else 3
    rows = math.ceil(n / cols)
    gap = 0.3
    area_h = fr.h - y0 - 0.85
    cw = (fr.cw - gap * (cols - 1)) / cols
    ch = min((area_h - gap * (rows - 1)) / rows, 3.1)
    y0 += max(0.0, (area_h - (ch * rows + gap * (rows - 1))) / 2) * 0.85
    pad = 0.28
    compact = ch < 2.3            # short cards (e.g. 1:1): icon on the left, text on the right
    d = 0.62 if ch < 2.6 else 0.72
    inner_w = (cw - 2 * pad - (d + 0.25)) if compact else (cw - 2 * pad)
    heads = [it.get("heading", "") for it in items if it.get("heading")]
    hmax = 22 if compact else 24
    hsize = min((fit_font_size([h], inner_w, 0.62, max_pt=hmax, min_pt=13, para_gap_pt=0) for h in heads),
                default=hmax)
    for i, it in enumerate(items):
        r, c = divmod(i, cols)
        x = fr.mx + c * (cw + gap)
        y = y0 + r * (ch + gap)
        _rect(slide, x, y, cw, ch, pal.card, shape=MSO_SHAPE.RECTANGLE, name=f"card-{i + 1}")
        _rect(slide, x, y, 0.08, ch, pal.accent, name=f"card-{i + 1}-bar")
        head, text = it.get("heading", ""), it.get("text", "")
        if compact:
            _badge(slide, fr, pal, it.get("icon"), i + 1, x + pad + 0.05, y + (ch - d) / 2, d, f"card-{i + 1}-badge")
            tx = x + pad + 0.05 + d + 0.25
            tw = cw - (tx - x) - pad
            th = ch - 0.2
            lines = [t for t in (head, text) if t]
            tsize = fit_font_size([text or head], tw, th - (0.5 if head and text else 0), max_pt=18, min_pt=11,
                                  para_gap_pt=0)
            tb, tf = _textbox(slide, tx, y + 0.1, tw, th, name=f"card-{i + 1}-text", anchor=MSO_ANCHOR.MIDDLE)
            first = True
            for t, bold in ((head, True), (text, False)):
                if not t:
                    continue
                p = tf.paragraphs[0] if first else tf.add_paragraph()
                first = False
                p.space_after = Pt(2)
                rr = p.add_run()
                rr.text = t
                _style_run(rr, min(hsize, 20) if bold else tsize, pal.text if bold else pal.muted, bold)
            continue
        _badge(slide, fr, pal, it.get("icon"), i + 1, x + pad + 0.05, y + pad, d, f"card-{i + 1}-badge")
        ty = y + pad + d + 0.12
        if head:
            tb, tf = _textbox(slide, x + pad, ty, cw - 2 * pad, 0.62, name=f"card-{i + 1}-heading")
            _write_text(tf, head, hsize, pal.text, bold=True, line_spacing=0.95)
            ty += 0.66
        if text:
            bh = max(0.4, y + ch - ty - 0.12)
            size = fit_font_size([text], cw - 2 * pad, bh, max_pt=20 if head else 24, min_pt=11, para_gap_pt=0)
            tb, tf = _textbox(slide, x + pad, ty, cw - 2 * pad, bh, name=f"card-{i + 1}-text")
            _write_text(tf, text, size, pal.muted if head else pal.text, line_spacing=1.05)


def _render_stats(slide, fr, pal, title, stats):
    _set_background(slide, pal.bg)
    y0 = _title_block(slide, fr, pal, title)
    n = len(stats)
    cols = n if (not fr.small or n <= 3) else 2
    rows = math.ceil(n / cols)
    gap = 0.3
    area_h = fr.h - y0 - 0.85
    cw = (fr.cw - gap * (cols - 1)) / cols
    ch = min((area_h - gap * (rows - 1)) / rows, 3.2)
    y0 += max(0.0, (area_h - (ch * rows + gap * (rows - 1))) / 2) * 0.85
    for i, st in enumerate(stats):
        r, c = divmod(i, cols)
        x = fr.mx + c * (cw + gap)
        y = y0 + r * (ch + gap)
        _rect(slide, x, y, cw, ch, pal.card, name=f"stat-{i + 1}")
        _rect(slide, x, y, cw, 0.08, pal.accent, name=f"stat-{i + 1}-bar")
        vsize = fit_font_size([st["value"]], cw - 0.4, ch * 0.42, max_pt=60 if not fr.small else 44,
                              min_pt=24, para_gap_pt=0, line_spacing=1.0)
        tb, tf = _textbox(slide, x + 0.2, y + 0.3, cw - 0.4, ch * 0.42, name=f"stat-{i + 1}-value",
                          anchor=MSO_ANCHOR.MIDDLE)
        _write_text(tf, st["value"], vsize, pal.accent, bold=True, align=PP_ALIGN.CENTER)
        _rect(slide, x + cw / 2 - 0.4, y + 0.3 + ch * 0.42 + 0.1, 0.8, 0.04, _mix(pal.bg, pal.text, 0.25),
              name=f"stat-{i + 1}-rule")
        lab = st["label"] + (f"\n{st['text']}" if st.get("text") else "")
        ly = y + 0.3 + ch * 0.42 + 0.25
        lh = max(0.5, y + ch - ly - 0.15)
        lsize = fit_font_size([st["label"]], cw - 0.4, lh, max_pt=20, min_pt=12, para_gap_pt=0)
        tb, tf = _textbox(slide, x + 0.2, ly, cw - 0.4, lh, name=f"stat-{i + 1}-label")
        _write_text(tf, st["label"], lsize, pal.text, align=PP_ALIGN.CENTER, line_spacing=1.05)
        if st.get("text"):
            p = tf.add_paragraph()
            p.alignment = PP_ALIGN.CENTER
            r_ = p.add_run()
            r_.text = st["text"]
            _style_run(r_, max(11, lsize - 4), pal.muted)


def _render_steps(slide, fr, pal, title, items):
    _set_background(slide, pal.bg)
    y0 = _title_block(slide, fr, pal, title)
    n = len(items)
    area_h = fr.h - y0 - 0.85
    horizontal = (not fr.small) and n <= 5
    d = 0.85
    if horizontal:
        cw = fr.cw / n
        y0 += max(0.0, (area_h - 3.2) / 2) * 0.85
        cy = y0 + 0.2 + d / 2
        _rect(slide, fr.mx + cw / 2, cy - 0.02, cw * (n - 1), 0.04, _mix(pal.bg, pal.accent, 0.35), name="timeline")
        for i, it in enumerate(items):
            cx = fr.mx + cw * i + cw / 2
            _badge(slide, fr, pal, None, i + 1, cx - d / 2, cy - d / 2, d, f"step-{i + 1}")
            ty = cy + d / 2 + 0.25
            head, text = it.get("heading", ""), it.get("text", "")
            bw = cw - 0.3
            if head:
                hsize = fit_font_size([head], bw, 0.9, max_pt=24, min_pt=13, para_gap_pt=0)
                tb, tf = _textbox(slide, cx - bw / 2, ty, bw, 0.9, name=f"step-{i + 1}-heading")
                _write_text(tf, head, hsize, pal.text, bold=True, align=PP_ALIGN.CENTER, line_spacing=0.95)
                ty += 0.95
            if text:
                bh = max(0.5, fr.h - 0.9 - ty)
                size = fit_font_size([text], bw, bh, max_pt=20, min_pt=11, para_gap_pt=0)
                tb, tf = _textbox(slide, cx - bw / 2, ty, bw, bh, name=f"step-{i + 1}-text")
                _write_text(tf, text, size, pal.muted, align=PP_ALIGN.CENTER, line_spacing=1.05)
    else:
        rh = min(area_h / n, 1.5)
        for i, it in enumerate(items):
            y = y0 + i * rh
            if i < n - 1:
                _rect(slide, fr.mx + d / 2 - 0.02, y + d, 0.04, rh - d, _mix(pal.bg, pal.accent, 0.35),
                      name=f"step-{i + 1}-link")
            _badge(slide, fr, pal, None, i + 1, fr.mx, y, d, f"step-{i + 1}")
            head, text = it.get("heading", ""), it.get("text", "")
            tx = fr.mx + d + 0.3
            tw = fr.w - fr.mx - tx
            line = [t for t in (head, text) if t]
            size = fit_font_size(line, tw, rh - 0.1, max_pt=20, min_pt=11, para_gap_pt=2)
            tb, tf = _textbox(slide, tx, y - 0.02, tw, rh - 0.05, name=f"step-{i + 1}-text")
            first = True
            for t, bold in ((head, True), (text, False)):
                if not t:
                    continue
                p = tf.paragraphs[0] if first else tf.add_paragraph()
                first = False
                rr = p.add_run()
                rr.text = t
                _style_run(rr, size if bold else max(11, size - 2), pal.text if bold else pal.muted, bold)


def _render_compare(slide, fr, pal, title, left, right):
    _set_background(slide, pal.bg)
    y0 = _title_block(slide, fr, pal, title)
    stacked = fr.small
    gap = 0.35
    area_h = fr.h - y0 - 0.85
    cols = 1 if stacked else 2
    cw = (fr.cw - gap * (cols - 1)) / cols
    ch = (area_h - gap * (2 - cols)) / (2 if stacked else 1)
    if not stacked:
        ch = min(ch, 3.7)
        y0 += max(0.0, (area_h - ch) / 2) * 0.7
    for i, (side, col) in enumerate(((left, pal.accent), (right, _mix(pal.accent, pal.text, 0.35)))):
        x = fr.mx + (0 if stacked else i * (cw + gap))
        y = y0 + (i * (ch + gap) if stacked else 0)
        _rect(slide, x, y, cw, ch, pal.card, name=f"compare-{i + 1}")
        _rect(slide, x, y, cw, 0.7, col, name=f"compare-{i + 1}-header")
        hs = fit_font_size([side["heading"]], cw - 0.4, 0.6, max_pt=24, min_pt=13, para_gap_pt=0)
        tb, tf = _textbox(slide, x + 0.2, y + 0.05, cw - 0.4, 0.6, name=f"compare-{i + 1}-title",
                          anchor=MSO_ANCHOR.MIDDLE)
        _write_text(tf, side["heading"], hs, _accent_text_for(col), bold=True)
        pts = side["points"]
        bh = ch - 0.7 - 0.4
        bs = fit_font_size(pts, cw - 0.7, bh, max_pt=24, min_pt=11)
        tb, tf = _textbox(slide, x + 0.25, y + 0.9, cw - 0.5, bh, name=f"compare-{i + 1}-points")
        for k, ptxt in enumerate(pts):
            _add_bullet_paragraph(tf, k == 0, ptxt, bs, pal.text, col, gap_pt=bs * 0.5)


def _accent_text_for(col) -> tuple[int, int, int]:
    return (255, 255, 255) if _lum(col) < 0.6 else (17, 17, 17)


def _render_quote(slide, fr, pal, text, author):
    _set_background(slide, _mix(pal.bg, pal.accent, 0.08))
    _rect(slide, fr.mx, fr.h * 0.12, 0.09, fr.h * 0.62, pal.accent, name="quote-bar")
    tb, tf = _textbox(slide, fr.mx + 0.3, fr.h * 0.02, 2.2, 1.9, name="quote-mark")
    _write_text(tf, "“", 130, _mix(pal.bg, pal.accent, 0.55), bold=True)
    width = fr.w - 2 * fr.mx - 0.6
    size = fit_font_size([text], width, fr.h * 0.42, max_pt=38 if not fr.small else 28, min_pt=16,
                         para_gap_pt=0, line_spacing=1.2)
    tb, tf = _textbox(slide, fr.mx + 0.4, fr.h * 0.24, width, fr.h * 0.42, name="quote-text",
                      anchor=MSO_ANCHOR.MIDDLE)
    p = tf.paragraphs[0]
    p.line_spacing = 1.1
    r = p.add_run()
    r.text = text
    _style_run(r, size, pal.text, italic=True)
    if author:
        tb, tf = _textbox(slide, fr.mx + 0.4, fr.h * 0.66, width, 0.5, name="quote-author")
        _write_text(tf, "— " + author, 18, pal.accent, bold=True)


def _render_section(slide, fr, pal, title, number, subtitle, photo=None, credit=""):
    _set_background(slide, pal.accent)
    if photo:
        _add_photo(slide, photo, 0, 0, fr.w, fr.h, name="section-photo")
        veil = _rect(slide, 0, 0, fr.w, fr.h, pal.accent, name="section-veil")
        _set_alpha(veil, 0.82)
        _credit_strip(slide, 0, fr.h, fr.w, credit)
    soft = _mix(pal.accent, pal.accent_text, 0.18)
    tb, tf = _textbox(slide, fr.mx, fr.h * 0.12, 3.0, 1.6, name="section-number")
    _write_text(tf, f"{number:02d}", 90 if not fr.small else 64, soft, bold=True)
    width = fr.w - 2 * fr.mx
    size = fit_font_size([title], width, fr.h * 0.3, max_pt=48 if not fr.small else 34, min_pt=22,
                         para_gap_pt=0, line_spacing=1.0)
    tb, tf = _textbox(slide, fr.mx, fr.h * 0.38, width, fr.h * 0.3, name="title", anchor=MSO_ANCHOR.MIDDLE)
    _write_text(tf, title, size, pal.accent_text, bold=True, line_spacing=0.95)
    _rect(slide, fr.mx + 0.05, fr.h * 0.38 + fr.h * 0.3 + 0.1, 1.0, 0.07, pal.accent_text, name="accent-bar")
    if subtitle:
        ss = fit_font_size([subtitle], width, fr.h * 0.15, max_pt=22, min_pt=13, para_gap_pt=0)
        tb, tf = _textbox(slide, fr.mx, fr.h * 0.38 + fr.h * 0.3 + 0.35, width, fr.h * 0.15, name="subtitle")
        _write_text(tf, subtitle, ss, _mix(pal.accent, pal.accent_text, 0.85))


def _render_image_slide(slide, fr, pal, title, bullets, photo, credit="", flip=False):
    """Photo on one side, title + bullets on the other (top photo on 1:1)."""
    _set_background(slide, pal.bg)
    if fr.small:
        ph = fr.h * 0.38
        _add_photo(slide, photo, 0, 0, fr.w, ph, name="slide-photo")
        _rect(slide, 0, ph, fr.w, 0.08, pal.accent, name="photo-edge")
        _credit_strip(slide, 0, ph, fr.w, credit)
        x, w, top = fr.mx, fr.cw, ph + 0.3
        tsize = fit_font_size([title], w, 0.8, max_pt=26, min_pt=18, para_gap_pt=0)
        tb, tf = _textbox(slide, x, top, w, 0.8, name="title", anchor=MSO_ANCHOR.MIDDLE)
        _write_text(tf, title, tsize, pal.text, bold=True, line_spacing=0.95)
        body_top, body_h = top + 0.9, fr.h - top - 0.9 - 0.7
    else:
        pw = fr.w * 0.42
        px = fr.w - pw if flip else 0.0
        _add_photo(slide, photo, px, 0, pw, fr.h, name="slide-photo")
        _rect(slide, px + (0 if flip else pw - 0.08), 0, 0.08, fr.h, pal.accent, name="photo-edge")
        _credit_strip(slide, px, fr.h, pw, credit)
        x = fr.mx if flip else pw + fr.mx * 0.7
        w = (fr.w - pw - fr.mx * 1.7)
        top = fr.my * 0.75
        tsize = fit_font_size([title], w, 1.3, max_pt=34, min_pt=20, para_gap_pt=0)
        tb, tf = _textbox(slide, x, top, w, 1.3, name="title", anchor=MSO_ANCHOR.MIDDLE)
        _write_text(tf, title, tsize, pal.text, bold=True, line_spacing=0.95)
        _rect(slide, x + 0.05, top + 1.4, 0.9, 0.07, pal.accent, name="accent-bar")
        body_top, body_h = top + 1.75, fr.h - top - 1.75 - 0.85
    if bullets:
        bsize = fit_font_size(bullets, w - 0.4, body_h, max_pt=28 if not fr.small else 20, min_pt=12)
        tb, tf = _textbox(slide, x, body_top, w, body_h, name="bullets")
        for i, b in enumerate(bullets):
            _add_bullet_paragraph(tf, i == 0, b, bsize, pal.text, pal.accent, gap_pt=bsize * 0.5)
    return x, x + w


def _render_agenda(slide, fr, pal, title, items):
    _set_background(slide, pal.bg)
    if fr.small:
        panel_w = 0.0
        y0 = _title_block(slide, fr, pal, title)
        x, w, top, avail = fr.mx, fr.cw, y0, fr.h - y0 - 0.85
    else:
        panel_w = fr.w * 0.34
        _rect(slide, 0, 0, panel_w, fr.h, pal.accent, name="title-panel")
        width = panel_w - fr.mx * 1.3
        size = fit_font_size([title], width, fr.h * 0.45, max_pt=36, min_pt=20, para_gap_pt=0, line_spacing=1.05)
        tb, tf = _textbox(slide, fr.mx * 0.7, fr.h * 0.3, width, fr.h * 0.45, name="title", anchor=MSO_ANCHOR.MIDDLE)
        _write_text(tf, title, size, pal.accent_text, bold=True, line_spacing=0.95)
        x = panel_w + fr.mx * 0.8
        w = fr.w - x - fr.mx
        top, avail = fr.my, fr.h - 2 * fr.my - 0.3
    n = len(items)
    rh = min(avail / n, 1.05)
    top += max(0.0, (avail - rh * n) / 2)
    d = min(0.62, rh * 0.7)
    texts = [it["heading"] or it["text"] for it in items]
    longest = max(texts, key=len)
    size = fit_font_size([longest], w - d - 0.4, rh - 0.1, max_pt=28, min_pt=13, para_gap_pt=0)
    for i, it in enumerate(items):
        y = top + i * rh
        _badge(slide, fr, pal, None, i + 1, x, y + (rh - d) / 2, d, f"agenda-{i + 1}")
        tb, tf = _textbox(slide, x + d + 0.25, y, w - d - 0.25, rh, name=f"agenda-{i + 1}-text",
                          anchor=MSO_ANCHOR.MIDDLE)
        _write_text(tf, texts[i], size, pal.text)


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

# ---------------------------------------------------------------------------
# Native charts and tables
# ---------------------------------------------------------------------------

def _series_colors(pal: Palette, n: int) -> list[tuple[int, int, int]]:
    base = [pal.accent, _mix(pal.accent, pal.text, 0.45), _mix(pal.accent, pal.bg, 0.45),
            _mix(pal.accent, pal.text, 0.75), _mix(pal.accent, pal.bg, 0.7), pal.muted]
    return [base[i % len(base)] for i in range(n)]


def _render_chart(slide, fr, pal, title, ch):
    """Editable PowerPoint chart (bar / hbar / line / pie) + optional takeaway card."""
    _set_background(slide, pal.bg)
    y0 = _title_block(slide, fr, pal, title)
    take = ch.get("takeaway", "")
    area_h = fr.h - y0 - 0.85
    side = bool(take) and not fr.small
    chart_w = fr.cw * (0.64 if side else 1.0)
    chart_h = area_h if (side or not take) else area_h - 0.95
    pie = ch["type"] == "pie"

    data = CategoryChartData()
    data.categories = ch["categories"]
    for s_ in ch["series"]:
        data.add_series(s_["name"], s_["values"])
    kind = {"bar": XL_CHART_TYPE.COLUMN_CLUSTERED, "hbar": XL_CHART_TYPE.BAR_CLUSTERED,
            "line": XL_CHART_TYPE.LINE_MARKERS, "pie": XL_CHART_TYPE.PIE}[ch["type"]]
    gf = slide.shapes.add_chart(kind, Inches(fr.mx), Inches(y0), Inches(chart_w), Inches(chart_h), data)
    gf.name = "chart"
    chart = gf.chart
    chart.font.size = Pt(12)
    chart.font.name = _font_name()
    chart.font.color.rgb = _rgb(pal.text)
    chart.has_title = False
    chart.has_legend = pie or len(ch["series"]) > 1
    if chart.has_legend:
        chart.legend.position = XL_LEGEND_POSITION.BOTTOM
        chart.legend.include_in_layout = False
        chart.legend.font.size = Pt(12)
        chart.legend.font.color.rgb = _rgb(pal.text)

    plot = chart.plots[0]
    plot.has_data_labels = True
    dl = plot.data_labels
    dl.font.size = Pt(12)
    dl.font.bold = True
    dl.font.color.rgb = _rgb(pal.text)
    unit = ch.get("unit", "").replace('"', "")
    dl.number_format = "#,##0.##" + (f'"{unit}"' if unit else "")
    dl.number_format_is_linked = False
    if pie:
        dl.position = XL_LABEL_POSITION.OUTSIDE_END
        plot.vary_by_categories = True
        for i, col in enumerate(_series_colors(pal, len(ch["categories"]))):
            pt = plot.series[0].points[i]
            pt.format.fill.solid()
            pt.format.fill.fore_color.rgb = _rgb(col)
    else:
        grid = _mix(pal.bg, pal.text, 0.15)
        va, ca = chart.value_axis, chart.category_axis
        va.has_major_gridlines = True
        va.major_gridlines.format.line.color.rgb = _rgb(grid)
        va.format.line.fill.background()
        ca.format.line.color.rgb = _rgb(grid)
        for ax in (va, ca):
            ax.tick_labels.font.size = Pt(12)
            ax.tick_labels.font.color.rgb = _rgb(pal.muted)
        if ch["type"] != "line":
            plot.gap_width = 60
        for ser, col in zip(plot.series, _series_colors(pal, len(ch["series"]))):
            if ch["type"] == "line":
                ser.smooth = False
                ser.format.line.color.rgb = _rgb(col)
                ser.format.line.width = Pt(3)
                ser.marker.format.fill.solid()
                ser.marker.format.fill.fore_color.rgb = _rgb(col)
                ser.marker.format.line.color.rgb = _rgb(col)
            else:
                ser.format.fill.solid()
                ser.format.fill.fore_color.rgb = _rgb(col)

    if take:
        if side:
            x = fr.mx + chart_w + 0.35
            w = fr.cw - chart_w - 0.35
            h = min(area_h, 3.2)
            y = y0 + (area_h - h) / 2
            _rect(slide, x, y, w, h, pal.card, name="takeaway-card")
            _rect(slide, x, y, 0.08, h, pal.accent, name="takeaway-bar")
            size = fit_font_size([take], w - 0.5, h - 0.4, max_pt=22, min_pt=13, para_gap_pt=0)
            tb, tf = _textbox(slide, x + 0.25, y + 0.2, w - 0.45, h - 0.4, name="takeaway",
                              anchor=MSO_ANCHOR.MIDDLE)
            _write_text(tf, take, size, pal.text, bold=True, line_spacing=1.05)
        else:
            size = fit_font_size([take], fr.cw, 0.8, max_pt=18, min_pt=12, para_gap_pt=0)
            tb, tf = _textbox(slide, fr.mx, y0 + chart_h + 0.1, fr.cw, 0.8, name="takeaway",
                              anchor=MSO_ANCHOR.MIDDLE)
            _write_text(tf, take, size, pal.text, bold=True)


def _render_table(slide, fr, pal, title, tb):
    """Editable PowerPoint table; font size and column widths are fitted to the free area."""
    _set_background(slide, pal.bg)
    y0 = _title_block(slide, fr, pal, title)
    cols, rows = tb["columns"], tb["rows"]
    nr, nc = len(rows) + 1, len(cols)
    area_h = fr.h - y0 - 0.85
    weights = [max(8, min(36, max(len(cols[j]), *(len(r[j]) for r in rows)))) for j in range(nc)]
    widths = [fr.cw * w_ / sum(weights) for w_ in weights]

    def row_heights(size: float) -> list[float]:
        out = []
        for i in range(nr):
            cells = cols if i == 0 else rows[i - 1]
            lines = max(_lines_needed(cells[j], size, widths[j] - 0.2) for j in range(nc))
            out.append(lines * size * 1.2 / 72.0 + 0.16)
        return out

    size = 22.0
    while size > 10 and sum(row_heights(size)) > area_h:
        size -= 1
    min_h = min(0.7, area_h / nr)          # airy rows when the table is short
    heights = [max(h_, min_h) for h_ in row_heights(size)]

    gf = slide.shapes.add_table(nr, nc, Inches(fr.mx), Inches(y0), Inches(fr.cw), Inches(sum(heights)))
    gf.name = "table"
    table = gf.table
    table.first_row = True
    table.horz_banding = False
    for j, w_ in enumerate(widths):
        table.columns[j].width = Inches(w_)
    for i, h_ in enumerate(heights):
        table.rows[i].height = Inches(h_)
    for i in range(nr):
        for j in range(nc):
            cell = table.cell(i, j)
            cell.fill.solid()
            cell.fill.fore_color.rgb = _rgb(pal.accent if i == 0 else
                                            (pal.card if i % 2 else _mix(pal.bg, pal.text, 0.03)))
            cell.margin_left = cell.margin_right = Inches(0.1)
            cell.margin_top = cell.margin_bottom = Inches(0.05)
            cell.vertical_anchor = MSO_ANCHOR.MIDDLE
            cell.text_frame.word_wrap = True
            run = cell.text_frame.paragraphs[0].add_run()
            run.text = cols[j] if i == 0 else rows[i - 1][j]
            _style_run(run, size, pal.accent_text if i == 0 else pal.text, bold=(i == 0 or j == 0))


def _get(obj: Any, key: str, default: Any = "") -> Any:
    if isinstance(obj, dict):
        return obj.get(key, default)
    return getattr(obj, key, default)


def outline_to_deck(outline: Any) -> dict:
    """Convert an ``analyzer.SlideOutline`` (or a dict) into the deck format."""
    slides = []
    for s in _get(outline, "slides", []) or []:
        slides.append({
            "title": _get(s, "title", ""),
            "content_type": _get(s, "content_type", "content"),
            "bullets": list(_get(s, "bullets", []) or []),
            "notes": _get(s, "notes", ""),
            "layout": _get(s, "layout", ""),
        })
    return {
        "title": _get(outline, "title", ""),
        "subtitle": _get(outline, "subtitle", ""),
        "slides": slides,
    }


LAYOUTS = ("cover", "agenda", "cards", "stats", "steps", "compare", "quote", "bullets", "section", "closing", "image", "chart", "table")
_LAYOUT_ALIASES = {
    "list": "bullets", "content": "bullets", "split": "bullets", "timeline": "steps", "process": "steps",
    "numbers": "stats", "statistics": "stats", "kpi": "stats", "comparison": "compare", "versus": "compare",
    "grid": "cards", "features": "cards", "divider": "section", "toc": "agenda", "outline": "agenda",
    "title": "cover", "end": "closing", "thanks": "closing",
    "graph": "chart", "data_table": "table", "photo": "image", "picture": "image", "image_text": "image", "image-text": "image",
}


def _norm_items(raw: Any, limit: int = 6) -> list[dict]:
    """Strings or {heading,text,icon} dicts -> clean dicts."""
    out: list[dict] = []
    for it in raw or []:
        if isinstance(it, dict):
            head = clean_text(it.get("heading") or it.get("title") or it.get("label"))
            text = clean_text(it.get("text") or it.get("description") or it.get("body"))
            icon = clean_text(it.get("icon"))
        else:
            head, text = _split_heading(clean_text(it))
            icon = ""
        if head or text:
            out.append({"heading": head, "text": text, "icon": icon})
    return out[:limit]


def _norm_stats(raw: Any) -> list[dict]:
    out = []
    for it in raw or []:
        if not isinstance(it, dict):
            continue
        value = clean_text(it.get("value") or it.get("number"))
        label = clean_text(it.get("label") or it.get("heading") or it.get("title"))
        if value and label:
            out.append({"value": value[:14], "label": label, "text": clean_text(it.get("text"))})
    return out[:4]


def _norm_side(raw: Any) -> dict | None:
    if not isinstance(raw, dict):
        return None
    pts = [clean_text(p) for p in (raw.get("points") or raw.get("bullets") or [])]
    pts = [p for p in pts if p][:5]
    head = clean_text(raw.get("heading") or raw.get("title"))
    return {"heading": head or "—", "points": pts} if pts else None


def _num(v: Any) -> float | None:
    try:
        return float(str(v).replace(",", ".").replace("%", "").strip())
    except (ValueError, TypeError):
        return None


def _norm_chart(raw: Any, takeaway: str = "") -> dict | None:
    if not isinstance(raw, dict):
        return None
    kind = str(raw.get("type") or "bar").lower()
    kind = {"column": "bar", "columns": "bar", "horizontal": "hbar", "barh": "hbar",
            "doughnut": "pie", "donut": "pie"}.get(kind, kind)
    if kind not in ("bar", "hbar", "line", "pie"):
        kind = "bar"
    cats = [clean_text(c) for c in (raw.get("categories") or raw.get("labels") or [])]
    cats = [c for c in cats if c]
    series = []
    for s_ in raw.get("series") or []:
        if not isinstance(s_, dict):
            continue
        vals = [_num(v) for v in (s_.get("values") or [])]
        if len(vals) != len(cats) or any(v is None for v in vals):
            continue
        series.append({"name": clean_text(s_.get("name")) or "—", "values": vals[:8]})
    if len(cats) < 2 or not series:
        return None
    if kind == "pie":
        series = series[:1]
        if any(v < 0 for v in series[0]["values"]):
            return None
    take = clean_text(raw.get("takeaway")) or takeaway
    illustrative = str(raw.get("illustrative")).strip().lower() in ("true", "1", "yes")
    if illustrative and not take:
        take = "Illustrative data"          # never present made-up numbers as real
    return {"type": kind, "categories": cats[:8], "series": series[:3],
            "unit": clean_text(raw.get("unit"))[:4], "illustrative": illustrative,
            "takeaway": take}


def _norm_table(raw: Any) -> dict | None:
    if not isinstance(raw, dict):
        return None
    cols = [clean_text(c) for c in (raw.get("columns") or [])][:6]
    rows = []
    for r in raw.get("rows") or []:
        if isinstance(r, (list, tuple)):
            cells = [clean_text(c)[:60] for c in r][:len(cols)]
            rows.append(cells + [""] * (len(cols) - len(cells)))
    rows = rows[:8]
    return {"columns": cols, "rows": rows} if len(cols) >= 2 and rows else None


def _normalize_deck(deck: dict) -> tuple[str, str, list[dict]]:
    title = clean_text(deck.get("title")) or "Presentation"
    subtitle = clean_text(deck.get("subtitle"))
    slides: list[dict] = []
    for s in deck.get("slides") or []:
        if not isinstance(s, dict):
            continue
        bullets = [clean_text(b) for b in (s.get("bullets") or [])]
        bullets = [b for b in bullets if b][:MAX_BULLETS]
        layout = str(s.get("layout") or "").strip().lower()
        layout = _LAYOUT_ALIASES.get(layout, layout)
        slides.append({
            "title": clean_text(s.get("title")),
            "content_type": str(s.get("content_type") or "content").lower(),
            "layout": layout if layout in LAYOUTS else "",
            "bullets": bullets,
            "items": _norm_items(s.get("items")),
            "stats": _norm_stats(s.get("stats")),
            "left": _norm_side(s.get("left")),
            "right": _norm_side(s.get("right")),
            "chart": _norm_chart(s.get("chart"), clean_text(s.get("takeaway"))),
            "table": _norm_table(s.get("table")),
            "quote": clean_text(s.get("quote")),
            "author": clean_text(s.get("author")),
            "image": s.get("image") if _get_photo(s) else None,
            "notes": s.get("notes") or "",
        })
    if not slides:
        slides = [{"title": title, "content_type": "cover", "layout": "cover", "bullets": [], "items": [],
                   "stats": [], "left": None, "right": None, "quote": "", "author": "", "image": None, "notes": ""}]
    return title, subtitle, slides


def _resolve_layout(spec: dict, i: int, total: int, content_idx: int) -> tuple[str, list[dict]]:
    """Pick the layout that the slide's data can actually fill. Returns (layout, items)."""
    layout = spec["layout"]
    ctype = spec["content_type"]
    bullets = spec["bullets"]
    items = spec["items"] or _norm_items(bullets)

    if layout == "" :
        if ctype == "cover" or (i == 0 and ctype != "closing"):
            return "cover", []
        if ctype == "closing" or (i == total - 1 and total > 2 and not bullets and not items):
            return "closing", []
        # legacy outline (bullets only): rotate so neighbours differ
        if 2 <= len(bullets) <= 4 and content_idx % 3 != 0 and all(len(b) <= 150 for b in bullets):
            return "cards", items
        return ("bullets", [])
    if layout == "cover" and i != 0 and i != total - 1:
        layout = "section"
    if layout in ("cover", "closing", "section"):
        return layout, items
    if layout == "image" and _get_photo(spec) and (bullets or items):
        return "image", items
    if layout == "stats" and len(spec["stats"]) >= 2:
        return "stats", []
    if layout == "chart" and spec.get("chart"):
        return "chart", []
    if layout == "table" and spec.get("table"):
        return "table", []
    if layout == "compare" and spec["left"] and spec["right"]:
        return "compare", []
    if layout == "quote" and spec["quote"]:
        return "quote", []
    if layout == "agenda" and len(items) >= 2:
        return "agenda", items
    if layout == "steps" and len(items) >= 2:
        return "steps", items
    if layout == "cards" and len(items) >= 2:
        return "cards", items
    # requested layout can't be filled -> degrade gracefully
    if len(items) >= 2 and not bullets:
        return "cards", items
    return "bullets", []


def _bullets_for(spec: dict, items: list[dict]) -> list[str]:
    if spec["bullets"]:
        return spec["bullets"]
    return [(f"{it['heading']} — {it['text']}" if it["heading"] and it["text"] else it["heading"] or it["text"])
            for it in (spec["items"] or items)]


def build_pptx(deck: dict, style: str = DEFAULT_STYLE, aspect_ratio: str = DEFAULT_RATIO,
               presets: dict | None = None, max_slides: int | None = None) -> bytes:
    """Render ``deck`` to PPTX bytes. Never more than ``max_slides`` (hard ceiling: 15) slides."""
    title, subtitle, slides = _normalize_deck(deck)
    limit = min(max_slides or ABSOLUTE_MAX_SLIDES, ABSOLUTE_MAX_SLIDES)
    if len(slides) > limit:
        logger.warning("Deck has %d slides; trimming to %d", len(slides), limit)
        slides = enforce_slide_cap({"slides": slides}, limit)["slides"]
    pal = resolve_palette(style, presets)
    w_in, h_in = slide_size_inches(aspect_ratio)
    fr = _Frame(w_in, h_in)

    prs = Presentation()
    prs.slide_width = Inches(w_in)
    prs.slide_height = Inches(h_in)
    prs.core_properties.title = title[:250]
    prs.core_properties.author = "PPT Agent"
    blank = prs.slide_layouts[6]
    total = len(slides)

    content_idx = 0
    section_idx = 0
    image_idx = 0
    for i, spec in enumerate(slides):
        slide = prs.slides.add_slide(blank)
        stitle = spec["title"] or title
        layout, items = _resolve_layout(spec, i, total, content_idx + 1)
        footer_x0 = footer_x1 = None

        photo = _get_photo(spec)
        credit = (spec.get("image") or {}).get("credit", "") if photo else ""
        if layout == "cover":
            _render_cover(slide, fr, pal, title if i == 0 else stitle,
                          subtitle or " ".join(spec["bullets"][:1]), photo, credit)
        elif layout == "closing":
            lines = spec["bullets"] or [t for it in items for t in (it["text"] or it["heading"],) if t]
            _render_closing(slide, fr, pal, stitle, lines, title)
        elif layout == "section":
            section_idx += 1
            sub = (spec["bullets"][:1] or [it["text"] or it["heading"] for it in items[:1]] or [""])[0]
            _render_section(slide, fr, pal, stitle, section_idx, sub, photo, credit)
        else:
            content_idx += 1
            if layout == "agenda":
                _render_agenda(slide, fr, pal, stitle, items)
                footer_x0 = None if fr.small else fr.w * 0.34 + fr.mx * 0.8
            elif layout == "cards":
                _render_cards_rich(slide, fr, pal, stitle, items)
            elif layout == "stats":
                _render_stats(slide, fr, pal, stitle, spec["stats"])
            elif layout == "steps":
                _render_steps(slide, fr, pal, stitle, items)
            elif layout == "compare":
                _render_compare(slide, fr, pal, stitle, spec["left"], spec["right"])
            elif layout == "quote":
                _render_quote(slide, fr, pal, spec["quote"], spec["author"])
            elif layout == "chart":
                _render_chart(slide, fr, pal, stitle, spec["chart"])
            elif layout == "table":
                _render_table(slide, fr, pal, stitle, spec["table"])
            elif layout == "image":
                image_idx += 1
                flip = image_idx % 2 == 0
                footer_x0, footer_x1 = _render_image_slide(
                    slide, fr, pal, stitle, _bullets_for(spec, items), photo, credit, flip=flip)
            else:
                bl = _bullets_for(spec, items)
                if bl and content_idx % 2 == 0 and not fr.small:
                    _render_split(slide, fr, pal, stitle, bl)
                    footer_x0 = fr.w * 0.36 + fr.mx * 0.7
                else:
                    _render_list(slide, fr, pal, stitle, bl)
            _footer(slide, fr, pal, i + 1, total, title, x0=footer_x0, x1=footer_x1)
        _set_notes(slide, spec["notes"])

    out = io.BytesIO()
    prs.save(out)
    return out.getvalue()


def build_pptx_from_outline(outline: Any, style: str = DEFAULT_STYLE, aspect_ratio: str = DEFAULT_RATIO) -> bytes:
    return build_pptx(outline_to_deck(outline), style, aspect_ratio)
