"""Roles and model tiers.

The director (CEO) invents roles on the fly; each employee only needs a *tier*:
  lite  = cheap/fast     smart = strongest     fast = balanced default
Override any tier:  COMPANY_MODEL_TIER_SMART=gemini-3.6-flash
Override one role:  COMPANY_MODEL_WRITER=gemini-3.5-flash-lite
"""
from __future__ import annotations

import os
import re
from dataclasses import dataclass

TIERS = {
    "lite": "gemini-3.5-flash-lite",
    "fast": "gemini-3.6-flash",
    "smart": "gemini-3.1-pro-preview",   # no free tier -> falls back automatically
}

COMMON = ("Cavabı tapşırığın dilində yaz. Konkret ol, boş söz yazma. "
          "Yalnız öz işini gör, nəticəni birbaşa ver.")


def tier_model(tier: str) -> str:
    tier = tier if tier in TIERS else "fast"
    return os.getenv(f"COMPANY_MODEL_TIER_{tier.upper()}", TIERS[tier])


def slug(text: str) -> str:
    return re.sub(r"\W+", "_", text.strip().lower(), flags=re.UNICODE).strip("_") or "role"


@dataclass(frozen=True)
class Role:
    key: str
    title: str
    tier: str
    prompt: str

    @property
    def model(self) -> str:
        return os.getenv(f"COMPANY_MODEL_{slug(self.key).upper()}", tier_model(self.tier))


# Ready-made presets (the director may also invent any other role).
ROLES: dict[str, Role] = {r.key: r for r in [
    Role("ceo", "Direktor", "fast",
         "Sən şirkətin direktorusan. Məqsədi tapşırıqlara bölür, işçiləri seçir "
         "və nəticələri birləşdirirsən. " + COMMON),
    Role("researcher", "Tədqiqatçı", "fast",
         "Sən tədqiqatçısan. Faktları topla, strukturlaşdır, əmin olmadığın rəqəmi uydurma. " + COMMON),
    Role("writer", "Mətn yazarı", "fast",
         "Sən peşəkar mətn yazarısan. Aydın, maraqlı və dəqiq yaz. " + COMMON),
    Role("designer", "Dizayner", "fast",
         "Sən UI/UX və vizual dizayn mütəxəssisisən. Konkret rəng, layout, komponent təklif et. " + COMMON),
    Role("coder", "Proqramçı", "fast",
         "Sən senior proqramçısan. İşlək, təmiz kod yaz, qısa izah ver. " + COMMON),
    Role("reviewer", "Yoxlayıcı", "lite",
         "Sən keyfiyyət yoxlayıcısan. Səhv və boşluqları tap, düzəliş təklif et. " + COMMON),
]}
