"""The director: reads the user's goal and decides BY ITSELF who to hire and what each does."""
from __future__ import annotations

import json
import re
from dataclasses import dataclass

from .employee import Employee
from .gemini import gemini_chat
from .roles import COMMON, ROLES, TIERS, Role, slug

MAX_TEAM = 6

CEO_PROMPT = f"""Sən Gemini şirkətinin direktorusan. İstifadəçi sənə məqsəd verir.
Sən özün qərar verirsən: hansı işçiləri tutmaq lazımdır və hər biri nə edəcək.
YALNIZ bir JSON obyekti qaytar (markdown yox, izah yox).

{{
  "summary": "istifadəçiyə 1-2 cümlə: planın mənası",
  "employees": [{{"name": "Leyla", "title": "vəzifə", "skills": "bacarıqları, 1 cümlə",
                 "tier": "lite|fast|smart"}}],
  "tasks": [{{"id": "t1", "assignee": "Leyla", "instruction": "dəqiq tapşırıq və gözlənilən nəticə",
             "depends_on": []}}]
}}

QAYDALAR
1. Yalnız həqiqətən lazım olan işçiləri tut (2-{MAX_TEAM}). Vəzifəni məqsədə görə özün icad et.
2. tier: sadə/ucuz iş = "lite", adi iş = "fast", ən çətin iş = "smart".
3. Hər tapşırığın bir sahibi və aydın nəticəsi olsun. Asılılıq varsa depends_on-a başqa tapşırığın id-sini yaz.
4. Müstəqil tapşırıqlar paralel işləsin deyə onları bir-birindən asılı etmə.
5. Son tapşırıq bütün işləri birləşdirən və ya yoxlayan olsun.
6. İşçi adlarını və yazıları istifadəçinin dilində yaz. JSON açarları ingilis dilində qalsın."""


@dataclass
class Task:
    id: str
    assignee: str
    instruction: str
    depends_on: list[str]


@dataclass
class Plan:
    summary: str
    team: dict[str, Employee]
    tasks: list[Task]          # already in a valid execution order


def _load_json(text: str) -> dict:
    text = (text or "").strip()
    m = re.search(r"```(?:json)?\s*(.*?)```", text, flags=re.S)
    if m:
        text = m.group(1).strip()
    a, b = text.find("{"), text.rfind("}")
    if a == -1 or b <= a:
        raise ValueError("Direktor JSON qaytarmadı")
    try:
        data = json.loads(text[a:b + 1])
    except json.JSONDecodeError as e:
        raise ValueError("Direktorun planı oxuna bilmədi") from e
    if not isinstance(data, dict):
        raise ValueError("Plan obyekt deyil")
    return data


def hire(name: str, title: str, skills: str, tier: str) -> Employee:
    tier = tier if tier in TIERS else "fast"
    role = Role(key=f"{slug(title)}_{slug(name)}", title=title, tier=tier,
                prompt=f"Sən {title} vəzifəsində işləyən {name}-sən. Bacarıqların: {skills}. " + COMMON)
    return Employee(name=name, role=role)


def _order(tasks: list[Task]) -> list[Task]:
    done: set[str] = set()
    out: list[Task] = []
    left = list(tasks)
    while left:
        ready = [t for t in left if all(d in done for d in t.depends_on)]
        if not ready:
            raise ValueError("Tapşırıqlar bir-birindən dövri asılıdır")
        for t in ready:
            out.append(t)
            done.add(t.id)
            left.remove(t)
    return out


def parse_plan(raw: str) -> Plan:
    data = _load_json(raw)
    team: dict[str, Employee] = {}
    for e in data.get("employees") or []:
        if not isinstance(e, dict) or not str(e.get("name") or "").strip():
            continue
        name = str(e["name"]).strip()
        if name in team or len(team) >= MAX_TEAM:
            continue
        team[name] = hire(name, str(e.get("title") or "İşçi").strip(),
                          str(e.get("skills") or "ümumi işlər").strip(),
                          str(e.get("tier") or "fast").strip().lower())
    if not team:
        raise ValueError("Direktor heç kimi işə götürmədi")

    tasks: list[Task] = []
    ids: set[str] = set()
    for t in data.get("tasks") or []:
        if not isinstance(t, dict):
            continue
        tid, who = str(t.get("id") or "").strip(), str(t.get("assignee") or "").strip()
        ins = str(t.get("instruction") or "").strip()
        if not tid or tid in ids or who not in team or not ins:
            continue
        ids.add(tid)
        tasks.append(Task(tid, who, ins, [str(d) for d in (t.get("depends_on") or [])]))
    for t in tasks:
        t.depends_on = [d for d in t.depends_on if d in ids and d != t.id]
    if not tasks:
        raise ValueError("Direktor heç bir tapşırıq vermədi")
    return Plan(str(data.get("summary") or "").strip(), team, _order(tasks))


def plan_team(goal: str, chat=gemini_chat) -> Plan:
    """Ask the director to design the team + tasks for `goal`. Retries once on bad JSON."""
    last: ValueError | None = None
    for _ in range(2):
        raw = chat(CEO_PROMPT, f"MƏQSƏD:\n{goal.strip()}", ROLES["ceo"].model,
                   temperature=0.3, max_tokens=4000)
        try:
            return parse_plan(raw)
        except ValueError as e:
            last = e
    raise last  # type: ignore[misc]
