"""One employee = a role + a name. It does a task using its role's Gemini model."""
from __future__ import annotations

from dataclasses import dataclass
from typing import Callable

from .gemini import gemini_chat
from .roles import ROLES, Role

ChatFn = Callable[..., str]


@dataclass
class Employee:
    name: str
    role: Role

    @property
    def model(self) -> str:
        return self.role.model

    def work(self, task: str, context: str = "", chat: ChatFn = gemini_chat) -> str:
        user = f"TAPŞIRIQ:\n{task.strip()}"
        if context.strip():
            user += f"\n\nKOMANDA YOLDAŞLARININ İŞİ (kontekst):\n{context.strip()}"
        return chat(self.role.prompt, user, self.model)


def make_employee(name: str, role_key: str) -> Employee:
    if role_key not in ROLES:
        raise KeyError(f"Naməlum vəzifə: {role_key}")
    return Employee(name=name, role=ROLES[role_key])
