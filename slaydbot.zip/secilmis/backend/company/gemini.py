"""Thin Gemini caller. Every employee can use a different model.

Falls back (404/429/5xx) to GEMINI_FALLBACK_MODELS, then to GEMINI_MODEL.
Uses only the standard library, like the rest of the bot.
"""
from __future__ import annotations

import json
import os
import urllib.error
import urllib.request

API = "https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent"


class GeminiError(RuntimeError):
    def __init__(self, msg: str, code: int | None = None):
        super().__init__(msg)
        self.code = code


def model_chain(model: str) -> list[str]:
    chain = [model]
    chain += [m.strip() for m in os.getenv("GEMINI_FALLBACK_MODELS", "").split(",") if m.strip()]
    chain.append(os.getenv("GEMINI_MODEL", "gemini-3.6-flash"))
    out: list[str] = []
    for m in chain:
        if m not in out:
            out.append(m)
    return out


def _call(model: str, system: str, user: str, temperature: float,
          max_tokens: int, timeout: float) -> str:
    key = os.getenv("GEMINI_API_KEY")
    if not key:
        raise GeminiError("GEMINI_API_KEY .env faylında yoxdur")
    body: dict = {
        "contents": [{"role": "user", "parts": [{"text": user}]}],
        "generationConfig": {"temperature": temperature, "maxOutputTokens": max_tokens},
    }
    if system:
        body["systemInstruction"] = {"parts": [{"text": system}]}
    req = urllib.request.Request(
        API.format(model=model), data=json.dumps(body).encode(), method="POST",
        headers={"Content-Type": "application/json", "x-goog-api-key": key},
    )
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            data = json.loads(r.read())
    except urllib.error.HTTPError as e:
        raise GeminiError(e.read().decode(errors="replace")[:300], e.code) from e
    except urllib.error.URLError as e:
        raise GeminiError(str(e)) from e
    parts = ((data.get("candidates") or [{}])[0].get("content") or {}).get("parts") or []
    text = "".join(p.get("text", "") for p in parts).strip()
    if not text:
        raise GeminiError("Model boş cavab qaytardı")
    return text


def gemini_chat(system: str, user: str, model: str, temperature: float = 0.5,
                max_tokens: int = 8000, timeout: float = 90.0) -> str:
    last: GeminiError | None = None
    for m in model_chain(model):
        try:
            return _call(m, system, user, temperature, max_tokens, timeout)
        except GeminiError as e:
            last = e
            if e.code is None or e.code in (404, 429, 500, 503):
                continue
            raise
    raise last or GeminiError("Heç bir model cavab vermədi")
