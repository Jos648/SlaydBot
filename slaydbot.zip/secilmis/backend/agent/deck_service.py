"""Text/topic -> editable .pptx, with no browser and no web server involved.

Pipeline (re-uses the project's own pieces):
    LLM client (Gemini / OpenAI / Claude)      agent.llm_client
      -> ContentAnalyzer.analyze()             agent.analyzer  (outline JSON)
      -> build_pptx()                          utils.pptx_builder (python-pptx)

Used by the Telegram bot (``telegram_bot.py``) and by the
``POST /api/generate-pptx`` endpoint.
"""

from __future__ import annotations

import logging
import os
import re
from dataclasses import dataclass, field
from typing import Callable

from .analyzer import ContentAnalyzer, SlideOutline, SlideSpec
from .deck_planner import build_system_prompt, build_user_prompt, parse_plan
from utils.image_search import attach_images, images_enabled
from .llm_client import LLMClient, create_llm_client
from utils.aspect_ratio import DEFAULT as DEFAULT_RATIO, normalize as normalize_ratio
from utils.languages import language_name
from utils.pptx_builder import DEFAULT_STYLE, build_pptx, load_presets, outline_to_deck
from utils.slide_limits import (ABSOLUTE_MAX_SLIDES, MIN_SLIDES, SlideCountError, enforce_slide_cap,
                                parse_slide_count)

logger = logging.getLogger("ppt-agent")

MAX_SLIDES = ABSOLUTE_MAX_SLIDES      # 15 is a hard ceiling (utils.slide_limits); MIN_SLIDES is imported above
MAX_INPUT_CHARS = 50_000

ProgressFn = Callable[[str], None]


@dataclass
class DeckResult:
    pptx: bytes
    filename: str
    title: str
    slide_count: int
    outline: SlideOutline
    images: int = 0
    brief: dict = field(default_factory=dict)          # audience / purpose / tone chosen by the planner
    skills_used: list = field(default_factory=list)    # skill ids whose guidance reached the planner


class DeckError(RuntimeError):
    """User-presentable generation failure."""


def available_styles() -> list[str]:
    return list(load_presets().keys())


def safe_filename(title: str, ext: str = "pptx") -> str:
    base = re.sub(r"[^\w\s-]", "", (title or "").strip(), flags=re.UNICODE)
    base = re.sub(r"\s+", "_", base)[:50].strip("_")
    return f"{base or 'presentation'}.{ext}"


def normalize_slide_request(slides) -> int:
    """User-facing validation: 1..15 accepted, >15 capped to 15, anything else rejected."""
    try:
        return parse_slide_count(slides)
    except SlideCountError as e:
        raise DeckError(f"Slayd sayı 1 ilə {ABSOLUTE_MAX_SLIDES} arasında olmalıdır.") from e


def finalize_pptx(deck: dict, slides: int, *, style: str, aspect_ratio: str) -> tuple[bytes, int]:
    """Final stage shared by every pipeline: cap, build, then count the slides of the REAL file.

    Guarantees ``count <= slides <= 15``; never adds slides.
    """
    from utils.pptx_qa import count_slides, check_pptx
    deck = enforce_slide_cap(deck, slides)
    data = build_pptx(deck, style=style, aspect_ratio=aspect_ratio)
    count = count_slides(data)
    if count > slides:      # defensive: a builder regression must not leak extra slides
        logger.error("Built deck has %d slides (limit %d); trimming and rebuilding", count, slides)
        data = build_pptx(enforce_slide_cap(deck, slides), style=style, aspect_ratio=aspect_ratio)
        count = count_slides(data)
        if count > slides:
            raise DeckError("Slayd sayı limiti pozuldu, yenidən cəhd edin.")
    for issue in check_pptx(data, max_slides=slides):
        logger.warning("QA %s", issue)
    return data, count


def _build_request_text(text: str, slides: int, language: str) -> str:
    text = text.strip()
    is_topic = len(text) < 300 and "\n" not in text
    parts = []
    if is_topic:
        parts.append(
            f"Create a complete, informative presentation about the following topic. "
            f"Invent concrete, accurate and useful content for every slide.\n\nTopic: {text}"
        )
    else:
        parts.append(text)
    parts.append(
        f"\n\n[Requirements: EXACTLY {slides} slides in total including the cover and the closing "
        f"slide (never more). At most 5 short bullets per slide. Write everything in {language_name(language)}.]"
    )
    return "".join(parts)


def _skills_used() -> list[str]:
    try:
        from .deck_planner import SKILL_BUDGET, SKILL_STAGES
        from .skill_system import skills_used_for
        return skills_used_for(SKILL_STAGES, SKILL_BUDGET)
    except Exception:   # noqa: BLE001 - informational only
        return []


def create_presentation(
    text: str,
    *,
    style: str = DEFAULT_STYLE,
    language: str = "az",
    slides: int = 8,
    aspect_ratio: str = DEFAULT_RATIO,
    client: LLMClient | None = None,
    progress: ProgressFn | None = None,
) -> DeckResult:
    """Generate a presentation from a topic or longer source text."""
    text = (text or "").strip()
    if not text:
        raise DeckError("Mövzu boşdur.")
    if len(text) > MAX_INPUT_CHARS:
        raise DeckError(f"Mətn çox uzundur (maksimum {MAX_INPUT_CHARS} simvol).")
    slides = normalize_slide_request(slides)
    ratio = normalize_ratio(aspect_ratio)
    if style not in available_styles():
        style = DEFAULT_STYLE

    if (client is None and os.getenv("DECK_TEAM", "1") != "0"
            and os.getenv("LLM_PROVIDER", "gemini").lower() == "gemini" and os.getenv("GEMINI_API_KEY")):
        try:   # Gemini team: researcher -> designer -> reviewer
            from .deck_team import create_presentation_team
            return create_presentation_team(text, style=style, language=language, slides=slides,
                                            aspect_ratio=ratio, progress=progress)
        except DeckError:
            raise
        except Exception as e:  # noqa: BLE001 - fall back to the classic single-call pipeline
            logger.warning("Team pipeline failed (%s); using the classic pipeline", e)

    if progress:
        progress("outline")
    client = client or create_llm_client()
    analyzer = ContentAnalyzer(client, client.model)
    deck = None
    try:
        # 1st choice: layout-aware plan (cards, icons, stats, steps, compare, quote ...)
        response = client.chat_completion(
            system=build_system_prompt(images=images_enabled(), max_slides=slides),
            messages=[{"role": "user", "content": build_user_prompt(text, slides, language)}],
            max_tokens=16000,
            temperature=0.4,
            timeout=90.0,
        )
        deck = parse_plan(response.text, analyzer._fix_json, max_slides=slides)
    except (ValueError, AttributeError, TypeError, KeyError) as e:
        logger.warning("Rich plan failed (%s); falling back to the classic outline", e)

    if deck is None:
        # 2nd choice: the project's classic bullet outline
        try:
            outline = analyzer.analyze(_build_request_text(text, slides, language), language=language)
        except (ValueError, AttributeError, TypeError, KeyError) as e:  # unparseable / wrongly shaped JSON
            raise DeckError("Model cavabı düzgün formatda gəlmədi, yenidən cəhd edin.") from e
        if not outline.slides:
            raise DeckError("Model heç bir slayd qaytarmadı, yenidən cəhd edin.")
        deck = enforce_slide_cap(outline_to_deck(outline), slides)

    deck = enforce_slide_cap(deck, slides)
    if not deck.get("slides"):
        raise DeckError("Model heç bir slayd qaytarmadı, yenidən cəhd edin.")
    outline = SlideOutline(
        title=deck["title"], subtitle=deck.get("subtitle", ""), slide_count=len(deck["slides"]),
        slides=[SlideSpec(title=str(sl.get("title") or ""), content_type=str(sl.get("content_type") or "content"),
                          bullets=list(sl.get("bullets") or [])) for sl in deck["slides"]],
    )

    n_images = 0
    if images_enabled() and any(isinstance(sl, dict) and sl.get("image_query") for sl in deck["slides"]):
        if progress:
            progress("images")
        try:
            n_images = attach_images(deck)
        except Exception as e:   # never let photos break the deck
            logger.warning("Attaching images failed: %s", e)

    if progress:
        progress("build")
    pptx_bytes, built = finalize_pptx(deck, slides, style=style, aspect_ratio=ratio)
    return DeckResult(
        pptx=pptx_bytes,
        filename=safe_filename(outline.title),
        title=outline.title,
        slide_count=built,
        outline=outline,
        images=n_images,
        brief=dict(deck.get("brief") or {}),
        skills_used=_skills_used(),
    )
