"""Slide pipeline run by a small Gemini team instead of one single LLM call.

    Researcher (collects facts)  ->  Designer (plans layouts, charts, tables)
      ->  Reviewer (fixes every issue found by utils.pptx_qa)  ->  build + geometry check

Each employee uses its own Gemini model (see company/roles.py).
"""
from __future__ import annotations

import logging
from typing import Callable

from company.employee import make_employee
from company.gemini import gemini_chat
from utils.image_search import attach_images, images_enabled
from utils.aspect_ratio import DEFAULT as DEFAULT_RATIO, normalize as normalize_ratio
from utils.languages import language_name
from utils.pptx_builder import DEFAULT_STYLE
from utils.pptx_qa import check_plan
from utils.slide_limits import enforce_slide_cap

from .analyzer import SlideOutline, SlideSpec
from .deck_planner import build_system_prompt, build_user_prompt, parse_plan
from .deck_service import (DeckError, DeckResult, MAX_INPUT_CHARS, _skills_used, available_styles,
                           finalize_pptx, normalize_slide_request, safe_filename)

logger = logging.getLogger("ppt-agent")
MAX_REVIEW_ROUNDS = 2

RESEARCH_TASK = """Prepare research notes for a presentation about: {topic}
- 8-12 concrete key points (facts, definitions, examples, process steps).
- Numbers: list ONLY figures you are certain about, each with what it measures and the year.
  Mark any doubtful figure as "unverified". Never invent statistics or sources.
- Say which points would work as a chart (several comparable numbers) or a table.
- Write in {language}. Plain text, no JSON."""

REVIEW_TASK = """Below is a presentation plan as JSON and a list of quality issues.
Return the FULL corrected plan as ONE JSON object (same schema, no markdown, no commentary).
Fix every [error] and as many [warn] as possible. Keep everything else unchanged.
Never invent statistics: if a chart/stat has doubtful numbers, replace it with cards or a table.

Do NOT add slides: the corrected plan must have at most {max_slides} slides (cover and closing included).
Merge or remove slides if needed. Stay within the application constraints.

{guidance}

ISSUES:
{issues}"""


def _chat_for(model_role: str, chat: Callable):
    """Adapter: deck_planner works with (system, user) -> text."""
    from company.roles import ROLES
    model = ROLES[model_role].model

    def call(system: str, user: str, **kw) -> str:
        return chat(system, user, model, **kw)
    return call


def create_presentation_team(
    text: str, *, style: str = DEFAULT_STYLE, language: str = "az", slides: int = 8,
    aspect_ratio: str = DEFAULT_RATIO, progress: Callable[[str], None] | None = None,
    chat: Callable = gemini_chat,
) -> DeckResult:
    text = (text or "").strip()
    if not text:
        raise DeckError("Mövzu boşdur.")
    if len(text) > MAX_INPUT_CHARS:
        raise DeckError(f"Mətn çox uzundur (maksimum {MAX_INPUT_CHARS} simvol).")
    slides = normalize_slide_request(slides)
    ratio = normalize_ratio(aspect_ratio)
    if style not in available_styles():
        style = DEFAULT_STYLE
    say = progress or (lambda _s: None)

    # 1) Researcher: only for short topics (long source text already contains the facts)
    notes = ""
    if len(text) < 300 and "\n" not in text:
        say("research")
        try:
            notes = make_employee("Tədqiqatçı", "researcher").work(
                RESEARCH_TASK.format(topic=text, language=language_name(language)), chat=chat)
        except Exception as e:  # research is a bonus, never fatal
            logger.warning("Researcher failed: %s", e)

    # 2) Designer: layout-aware plan
    say("outline")
    ask = _chat_for("designer", chat)
    user = build_user_prompt(text, slides, language)
    if notes:
        user += "\n\nRESEARCH NOTES (use them; trust only numbers that are not marked unverified):\n" + notes
    deck = None
    for attempt in range(2):
        try:
            deck = parse_plan(ask(build_system_prompt(images=images_enabled(), max_slides=slides), user,
                                  temperature=0.4, max_tokens=16000, timeout=120.0), max_slides=slides)
            break
        except ValueError as e:
            logger.warning("Designer plan unusable (%s), attempt %d", e, attempt + 1)
            user += "\n\nIMPORTANT: answer with ONE valid JSON object only."
    if deck is None:
        raise DeckError("Model cavabı düzgün formatda gəlmədi, yenidən cəhd edin.")

    # 3) Reviewer: fix issues found by the automatic checks
    reviewer = make_employee("Yoxlayıcı", "reviewer")
    for rnd in range(MAX_REVIEW_ROUNDS):
        issues = check_plan(deck, max_slides=slides)
        if not any(i.severity == "error" for i in issues):
            break
        say("review")
        logger.info("Review round %d: %d issues", rnd + 1, len(issues))
        try:
            import json
            from .skill_system import guidance_text
            fixed = reviewer.work(
                REVIEW_TASK.format(issues="\n".join(map(str, issues)), max_slides=slides,
                                   guidance=guidance_text(("qa_repair", "build"), 3200, max_slides=slides)),
                context=json.dumps(deck, ensure_ascii=False), chat=chat)
            deck = parse_plan(fixed, max_slides=slides)   # a repair round can never add slides
        except (ValueError, Exception) as e:  # keep the previous plan if the fix is unusable
            logger.warning("Reviewer fix failed: %s", e)
            break

    deck = enforce_slide_cap(deck, slides)
    outline = SlideOutline(
        title=deck["title"], subtitle=deck.get("subtitle", ""), slide_count=len(deck["slides"]),
        slides=[SlideSpec(title=str(sl.get("title") or ""), content_type=str(sl.get("content_type") or "content"),
                          bullets=list(sl.get("bullets") or [])) for sl in deck["slides"]],
    )

    # 4) Photos + build + geometry check
    n_images = 0
    if images_enabled() and any(isinstance(sl, dict) and sl.get("image_query") for sl in deck["slides"]):
        say("images")
        try:
            n_images = attach_images(deck)
        except Exception as e:
            logger.warning("Attaching images failed: %s", e)
    say("build")
    pptx_bytes, built = finalize_pptx(deck, slides, style=style, aspect_ratio=ratio)
    return DeckResult(pptx=pptx_bytes, filename=safe_filename(outline.title), title=outline.title,
                      slide_count=built, outline=outline, images=n_images,
                      brief=dict(deck.get("brief") or {}), skills_used=_skills_used())
