"""Layout-aware deck planner.

Asks the LLM for a *designed* deck (card headings, icons, statistics, steps,
comparisons, quotes ...) instead of plain bullets, then parses the answer into
the dict format understood by ``utils.pptx_builder``. The parser also accepts
the old bullets-only format, so any model answer that has ``slides`` works.
"""

from __future__ import annotations

import ast
import json
import re
from typing import Any, Callable

from utils.languages import language_name
from utils.pptx_icons import ICON_NAMES
from utils.slide_limits import ABSOLUTE_MAX_SLIDES, enforce_slide_cap

SYSTEM_PROMPT = """You are a presentation designer. Turn the user's topic or source text into a polished,
professional slide deck and return ONLY one JSON object (no markdown fences, no commentary).

SCHEMA
{
  "brief": {"audience": "...", "purpose": "...", "tone": "...", "assumptions": "one line, or empty"},
  "title": "deck title",
  "subtitle": "one short line under the title",
  "slides": [ { "layout": "<layout>", "title": "...", "notes": "1-2 sentence speaker note", ...fields } ]
}

LAYOUTS and their fields (use exactly these field names)
- "cover":   {"title","subtitle"}                        -> ALWAYS the first slide
- "agenda":  {"title","items":[{"heading":"..."}]}      -> 3-6 short topics, only one per deck (slide 2)
- "cards":   {"title","items":[{"icon","heading","text"}]}  -> 3-6 items; heading max 4 words; text max 18 words
- "stats":   {"title","stats":[{"value","label","text"}]}   -> 2-4 numbers, e.g. "85%", "2x", "1990"; label max 6 words
- "steps":   {"title","items":[{"heading","text"}]}     -> 3-5 ordered steps / timeline / process
- "compare": {"title","left":{"heading","points":[..]},"right":{"heading","points":[..]}} -> 2-5 points each
- "chart":   {"title","chart":{"type":"bar|hbar|line|pie","categories":[..],"series":[{"name","values":[numbers]}],"unit":"%","takeaway":"one-sentence insight"}}
            -> 3-8 categories, at most 3 series, numbers only (no text in values). Use for trends/shares/rankings.
            If the figures are NOT real, documented data, add "illustrative": true and say so in the takeaway.
- "table":   {"title","table":{"columns":[..],"rows":[[..]]}}  -> 2-6 columns, 2-8 rows, cells max 8 words; for specs/plans/comparisons of many attributes
- "quote":   {"quote","author"}                          -> one short, well-known, real quote (or a proverb) with its source
- "bullets": {"title","bullets":[..]}                    -> 3-5 bullets, each max 14 words
- "section": {"title","bullets":["optional one-line subtitle"]} -> divider, only for decks with 10+ slides
- "closing": {"title","bullets":["short closing line"]}  -> ALWAYS the last slide

"icon" must be one of: __ICONS__ (omit it if none fits).
__IMAGES__
DESIGN RULES
1. Never use the same layout on two consecutive slides. Use at least 4 different layouts in a deck of 8+ slides.
2. Prefer "cards", "steps", "compare" and "stats" over "bullets"; use "bullets" at most twice.
3. Every card needs BOTH a heading and a one-sentence text. No empty or filler items.
4. "stats" and "chart": include ONLY numbers you are confident are accurate and widely documented, or numbers that
   appear in the user's own text. If you are not sure of a real figure, do not invent one - use "cards" or "table"
   without numbers instead. Never fabricate sources. Use a "chart" when the data has 3+ comparable numbers.
5. Content must be concrete, specific and useful; no generic filler such as "important topic".
6. Titles: max 8 words, informative (say what the slide shows), not just a topic label.
7. Write ALL text in the requested language. Keep JSON keys, layout names and icon names in English.
8. SLIDE COUNT IS A HARD LIMIT: the "slides" array has EXACTLY the requested number of slides, cover and closing
   included, and never more than 15. Do not add extra title, agenda, divider or closing slides on top of it.
9. Fill "brief" first (who the audience is, what the deck must achieve, tone) and let it drive layout choice.
__SKILLS__"""


IMAGE_RULES = """
PHOTOS (enabled)
- "image":  {"title","bullets":[..],"image_query"} -> photo next to 3-4 short bullets. Use it 2-3 times per deck
            (in decks of 8+ slides), never two in a row, never as slide 2.
- ALSO add "image_query" to the "cover" slide, and to every "section" slide.
- "image_query" = a stock-photo search phrase in ENGLISH, 2-4 words, describing a concrete, photographable scene
  or object that fits the slide (e.g. "students in classroom", "handshake business meeting",
  "traditional tea table"). Not abstract ideas, no person names, no brands, no text/logos.
  If the topic is about a specific country or culture, include it (e.g. "Azerbaijan old city").
"""


SKILL_STAGES = ("request_analysis", "audience_analysis", "planning", "visual_direction", "composition", "content", "data_viz")
SKILL_BUDGET = 8000


def _slide_count_rules(slides: int | None) -> str:
    if not slides:
        return ""
    if slides == 1:
        return ("\nSLIDE COUNT: 1. Return ONE slide only (no cover, no closing): a \"cards\" or \"stats\" summary slide "
                "that carries the whole message.\n")
    if slides == 2:
        return "\nSLIDE COUNT: 2. Return exactly a \"cover\" and a \"closing\" slide with the key message.\n"
    extra = "" if slides >= 6 else ' Skip "agenda" and "section" slides.'
    return (f"\nSLIDE COUNT: {slides}. Return exactly {slides} slides: slide 1 = cover, slide {slides} = closing, "
            f"{slides - 2} content slides in between.{extra}\n")


def build_system_prompt(images: bool = False, max_slides: int | None = None, skills: bool = True) -> str:
    """System prompt. ``max_slides`` adds the exact slide-count rules; ``skills`` injects the budgeted guidance
    of the integrated skills (agent.skill_system) for the planning/design stages."""
    guidance = ""
    if skills:
        from .skill_system import guidance_text
        guidance = guidance_text(SKILL_STAGES, SKILL_BUDGET, max_slides=max_slides or ABSOLUTE_MAX_SLIDES)
        if guidance:
            guidance = "\nSKILL GUIDANCE (design rules distilled from the integrated skills)\n" + guidance + "\n"
    return (SYSTEM_PROMPT.replace("__ICONS__", ", ".join(ICON_NAMES))
            .replace("__IMAGES__", IMAGE_RULES if images else "")
            .replace("__SKILLS__", _slide_count_rules(max_slides) + guidance))


def build_user_prompt(text: str, slides: int, language: str) -> str:
    text = text.strip()
    is_topic = len(text) < 300 and "\n" not in text
    head = (
        f"Create a complete, informative presentation about the following topic. "
        f"Invent concrete, accurate and useful content for every slide.\n\nTopic: {text}"
        if is_topic else text
    )
    slides = max(1, min(int(slides), ABSOLUTE_MAX_SLIDES))
    return (
        f"{head}\n\n[Requirements: EXACTLY {slides} slides in total, the cover and the closing slide "
        f"included (never more than {slides}). Write everything in {language_name(language)}.]"
    )


def _load_json(text: str, fix_json: Callable[[str], str] | None) -> Any:
    text = (text or "").strip()
    m = re.search(r"```(?:json)?\s*(.*?)```", text, flags=re.S)
    if m:
        text = m.group(1).strip()
    else:
        a, b = text.find("{"), text.rfind("}")
        if a != -1:
            text = text[a:b + 1] if b > a else text[a:]
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        pass
    fixed = fix_json(text) if fix_json else text
    try:
        return json.loads(fixed)
    except json.JSONDecodeError:
        try:
            return ast.literal_eval(fixed)
        except (ValueError, SyntaxError) as e:
            raise ValueError("Plan JSON could not be parsed") from e


def parse_plan(text: str, fix_json: Callable[[str], str] | None = None, max_slides: int | None = None) -> dict:
    """Parse a model answer into a deck dict. Raises ValueError if unusable.

    ``max_slides`` trims an over-long answer (cover and closing are kept); the hard cap of 15 always applies.
    """
    data = _load_json(text, fix_json)
    if not isinstance(data, dict):
        raise ValueError("Plan is not an object")
    slides = [s for s in (data.get("slides") or []) if isinstance(s, dict)]
    if not slides:
        raise ValueError("Plan has no slides")
    title = str(data.get("title") or "").strip()
    if not title or title.lower() == "untitled":
        title = str(slides[0].get("title") or "").strip() or "Presentation"
    deck = {"title": title, "subtitle": str(data.get("subtitle") or "").strip(), "slides": slides}
    if isinstance(data.get("brief"), dict):
        deck["brief"] = {str(k): str(v)[:300] for k, v in data["brief"].items() if isinstance(v, (str, int, float))}
    return enforce_slide_cap(deck, min(max_slides or ABSOLUTE_MAX_SLIDES, ABSOLUTE_MAX_SLIDES))
