"""Skill integration system for the PPT Agent.

* **Discovery**  - every ``SKILL.md`` under ``backend/skills`` (nested, any depth) plus any
  directories listed in ``PPT_SKILLS_EXTRA`` is registered. Missing / empty / malformed /
  duplicated files are handled without raising.
* **Loading**    - front-matter metadata + markdown sections; relative file references
  (``references/foo.md``) resolve inside the owning skill directory only. Parsed content is
  cached and invalidated when a file's mtime/size changes.
* **Orchestration** - ``skill_map.json`` routes skill sections to pipeline *stages*
  (request analysis ... QA/repair). ``guidance_for(stages, budget)`` builds a compact, budgeted
  text per request; the full documents are never pasted into a prompt.
* **Safety**     - nothing from a skill archive is executed. Tool-invocation text (CLI commands,
  npm, scripts) is stripped from the injected guidance because it cannot run on Termux.

Statuses: ``active`` (guidance injected) | ``fallback`` (injected only if its primary yields
nothing for a stage) | ``reference_only`` (registered, deliberately not injected, reason given) |
``auto`` (unmapped skill routed by heading keywords) | ``unmapped`` | ``invalid``.
"""
from __future__ import annotations

import hashlib
import json
import logging
import os
import re
import threading
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

logger = logging.getLogger("ppt-agent")

SKILLS_DIR = Path(__file__).resolve().parent.parent / "skills"
MAP_PATH = SKILLS_DIR / "skill_map.json"

STAGES = ("request_analysis", "audience_analysis", "planning", "visual_direction",
          "composition", "content", "data_viz", "build", "qa_repair")
_SKIP_DIRS = {"node_modules", ".git", "__pycache__", "venv", ".venv"}
_MAX_SKILL_BYTES = 400_000          # a single SKILL.md bigger than this is read but flagged
_RESCAN_SECONDS = 5.0
# Paragraphs that only make sense for the skill's own tool chain are dropped from prompts.
_TOOL_TOKENS = ("present.py", "npm run", "scripts/", "python3 ", "pip install", "soffice", "pptxgenjs",
                "`--", "marketplace", "luna", "slide review mcp", "outline.json", "design_brief", "workspace",
                "attribution.csv", "header_variant", "role_layout_variant", "style_seed", "deck_style",
                "asset_plan", "receipt", "contact sheet", "render cache", "subagent")
_PRESENTATION_WORDS = re.compile(r"presentation|slide|deck|powerpoint|pptx|typograph|layout|chart", re.I)
_HEURISTIC = {                      # heading keyword -> stage (for skills missing from skill_map.json)
    "visual_direction": ("color", "palette", "style", "aesthetic", "visual"),
    "composition": ("layout", "composition", "grid", "alignment", "hierarchy"),
    "content": ("writing", "copy", "content"),
    "data_viz": ("chart", "figure", "graph", "visualization", "data"),
    "qa_repair": ("qa", "quality", "review", "checklist", "accessib", "contrast", "critique"),
    "planning": ("plan", "structure", "outline", "narrative"),
    "build": ("typography", "font", "spacing"),
}


# ---------------------------------------------------------------------------
# Data classes
# ---------------------------------------------------------------------------

@dataclass
class Section:
    heading: str
    level: int
    text: str                       # own body text, without child sections


@dataclass
class SkillRecord:
    id: str
    name: str
    description: str
    path: Path                      # absolute SKILL.md path
    root: Path                      # skill directory (owner of relative references)
    pack: str                       # top-level folder under the skills dir
    status: str = "unmapped"
    reason: str = ""
    sha256: str = ""
    size: int = 0
    metadata: dict = field(default_factory=dict)
    warnings: list[str] = field(default_factory=list)
    variant_of: str = ""
    stages: list[str] = field(default_factory=list)

    def as_dict(self) -> dict:
        return {"id": self.id, "name": self.name, "status": self.status, "reason": self.reason,
                "pack": self.pack, "path": str(self.path), "sha256": self.sha256[:12],
                "stages": self.stages, "warnings": self.warnings, "variant_of": self.variant_of}


@dataclass
class Guidance:
    text: str = ""
    used: list[tuple[str, str, str]] = field(default_factory=list)     # (skill id, file, heading)
    truncated: list[str] = field(default_factory=list)
    stages: tuple[str, ...] = ()

    @property
    def skill_ids(self) -> list[str]:
        seen: list[str] = []
        for sid, _f, _h in self.used:
            if sid not in seen:
                seen.append(sid)
        return seen


# ---------------------------------------------------------------------------
# Parsing helpers
# ---------------------------------------------------------------------------

def parse_frontmatter(text: str) -> tuple[dict, str, list[str]]:
    """Return (metadata, body, warnings). Never raises."""
    warns: list[str] = []
    text = text.lstrip("\ufeff")
    m = re.match(r"^---\s*\n(.*?)\n---\s*(?:\n|$)", text, flags=re.S)
    if not m:
        return {}, text, warns
    raw, body = m.group(1), text[m.end():]
    meta: dict = {}
    try:
        import yaml
        loaded = yaml.safe_load(raw)
        if isinstance(loaded, dict):
            meta = {str(k): v for k, v in loaded.items()}
        else:
            warns.append("front-matter is not a mapping")
    except Exception:       # malformed YAML -> tolerant line parser
        warns.append("front-matter is not valid YAML; parsed leniently")
        for line in raw.splitlines():
            k, sep, v = line.partition(":")
            if sep and k.strip() and not line.startswith((" ", "\t")):
                meta[k.strip()] = v.strip().strip("\"'")
    return meta, body, warns


_HEADING = re.compile(r"^(#{1,6})\s+(.*?)\s*#*\s*$")


def split_sections(body: str) -> list[Section]:
    """Split markdown into sections (heading + own text). Code fences are respected."""
    sections: list[Section] = [Section("", 0, "")]
    in_fence = False
    buf: list[str] = []
    for line in body.splitlines():
        if line.strip().startswith("```"):
            in_fence = not in_fence
        m = None if in_fence else _HEADING.match(line)
        if m:
            sections[-1].text = "\n".join(buf).strip()
            buf = []
            sections.append(Section(m.group(2).strip(), len(m.group(1)), ""))
        else:
            buf.append(line)
    sections[-1].text = "\n".join(buf).strip()
    return sections


def _section_with_children(sections: list[Section], idx: int) -> str:
    base = sections[idx]
    parts = [base.text]
    for s in sections[idx + 1:]:
        if s.level <= base.level:
            break
        parts.append(f"{s.heading}: {s.text}" if s.text else s.heading)
    return "\n\n".join(p for p in parts if p)


def _clean_paragraphs(text: str) -> list[str]:
    text = re.sub(r"```.*?```", "", text, flags=re.S)           # fenced code = commands/examples
    paras = [p.strip() for p in re.split(r"\n\s*\n", text)]
    out = []
    for p in paras:
        if not p or p.startswith("|") or p.startswith("<"):
            continue
        out.append(re.sub(r"\*\*(.+?)\*\*", r"\1", p.replace("`", "")))
    return out


_LIST_ITEM = re.compile(r"^\s*(?:[-*\u2022]|\d+[.)])\s+")


def _flatten(paragraph: str) -> list[str]:
    """Turn one markdown paragraph into prompt lines: list items stay separate, wrapped text is joined."""
    items: list[str] = []
    for line in paragraph.splitlines():
        line = line.strip()
        if not line:
            continue
        if _LIST_ITEM.match(line) or not items:
            items.append(_LIST_ITEM.sub("", line))
        else:
            items[-1] += " " + line
    return [re.sub(r"\s+", " ", i).strip() for i in items if i.strip()]


def _tool_free(items: list[str]) -> list[str]:
    """Drop lines that only make sense for the skill's own tool chain (cannot run on Termux)."""
    return [i for i in items if not any(t in i.lower() for t in _TOOL_TOKENS)]


def _cut(text: str, limit: int) -> tuple[str, bool]:
    if len(text) <= limit:
        return text, False
    cut = text[:limit]
    end = max(cut.rfind(". "), cut.rfind("\n"))
    return (cut[:end + 1] if end > limit * 0.5 else cut).rstrip(), True


# ---------------------------------------------------------------------------
# Registry
# ---------------------------------------------------------------------------

class SkillRegistry:
    def __init__(self, skills_dir: Path | None = None, map_path: Path | None = None,
                 extra_dirs: list[Path] | None = None):
        self.skills_dir = Path(skills_dir) if skills_dir else SKILLS_DIR
        self.map_path = Path(map_path) if map_path else (self.skills_dir / "skill_map.json")
        env_extra = [Path(p) for p in os.environ.get("PPT_SKILLS_EXTRA", "").split(os.pathsep) if p.strip()]
        self.extra_dirs = list(extra_dirs or []) + env_extra
        self._lock = threading.RLock()
        self._records: dict[str, SkillRecord] = {}
        self._sections: dict[Path, tuple[tuple[int, int], list[Section]]] = {}
        self._map: dict = {}
        self._signature: tuple = ()
        self._last_scan = 0.0
        self._guidance_cache: dict[tuple, Guidance] = {}
        self.refresh(force=True)

    # -- discovery -----------------------------------------------------
    def _find_files(self) -> list[Path]:
        found: list[Path] = []
        for base in [self.skills_dir, *self.extra_dirs]:
            if not base.is_dir():
                continue
            for dirpath, dirnames, filenames in os.walk(base):
                dirnames[:] = sorted(d for d in dirnames if d not in _SKIP_DIRS)
                for fn in sorted(filenames):
                    if fn.lower() == "skill.md":
                        found.append(Path(dirpath) / fn)
        return found

    def _scan_signature(self, files: list[Path]) -> tuple:
        sig = []
        for f in files:
            try:
                st = f.stat()
                sig.append((str(f), st.st_mtime_ns, st.st_size))
            except OSError:
                sig.append((str(f), 0, -1))
        try:
            st = self.map_path.stat()
            sig.append((str(self.map_path), st.st_mtime_ns, st.st_size))
        except OSError:
            sig.append((str(self.map_path), 0, -1))
        return tuple(sig)

    def refresh(self, force: bool = False) -> bool:
        """Re-scan if files changed (cheap stat check, at most every few seconds)."""
        with self._lock:
            now = time.monotonic()
            if not force and now - self._last_scan < _RESCAN_SECONDS:
                return False
            self._last_scan = now
            files = self._find_files()
            sig = self._scan_signature(files)
            if not force and sig == self._signature:
                return False
            self._signature = sig
            self._load_map()
            self._build_records(files)
            self._guidance_cache.clear()
            return True

    def invalidate(self) -> None:
        with self._lock:
            self._sections.clear()
            self._guidance_cache.clear()
            self._last_scan = 0.0
            self.refresh(force=True)

    def _load_map(self) -> None:
        try:
            self._map = json.loads(self.map_path.read_text(encoding="utf-8"))
            if not isinstance(self._map, dict):
                raise ValueError("skill_map.json must be an object")
        except (OSError, ValueError) as e:
            logger.warning("skill_map.json unusable (%s); skills fall back to heuristic routing", e)
            self._map = {}

    def _pack_of(self, path: Path) -> str:
        for base in [self.skills_dir, *self.extra_dirs]:
            try:
                rel = path.relative_to(base)
                return rel.parts[0] if len(rel.parts) > 1 else base.name
            except ValueError:
                continue
        return path.parent.name

    def _build_records(self, files: list[Path]) -> None:
        records: dict[str, SkillRecord] = {}
        skill_map = (self._map.get("skills") or {}) if isinstance(self._map, dict) else {}
        for f in files:
            warns: list[str] = []
            try:
                raw = f.read_bytes()
            except OSError as e:
                logger.warning("cannot read %s: %s", f, e)
                continue
            pack = self._pack_of(f)
            try:
                text = raw.decode("utf-8")
            except UnicodeDecodeError:
                text = raw.decode("utf-8", errors="replace")
                warns.append("not valid UTF-8; decoded with replacement")
            if len(raw) > _MAX_SKILL_BYTES:
                warns.append(f"very large ({len(raw)} bytes); only mapped sections are ever injected")
            meta, body, w = parse_frontmatter(text)
            warns += w
            name = str(meta.get("name") or "").strip() or f.parent.name
            if not meta.get("name"):
                warns.append("no 'name' in front-matter; using the folder name")
            desc = " ".join(str(meta.get("description") or "").split())
            rec = SkillRecord(id=name, name=name, description=desc, path=f, root=f.parent, pack=pack,
                              sha256=hashlib.sha256(raw).hexdigest(), size=len(raw),
                              metadata=meta, warnings=warns)
            if not body.strip():
                rec.status, rec.reason = "invalid", "empty SKILL.md"
            # duplicate names: a qualified id "name@pack" is used when the map lists it or the
            # plain name is already taken; the first/primary archive keeps the plain name.
            qualified = f"{name}@{pack}"
            if qualified in skill_map or rec.id in records:
                if rec.id in records or qualified in skill_map:
                    if rec.id in records:
                        rec.warnings.append(f"duplicate skill name '{name}'; registered as '{qualified}'")
                    rec.id = qualified
            records[rec.id] = rec
        for rec in records.values():
            self._apply_map(rec, skill_map)
        self._records = records

    def _apply_map(self, rec: SkillRecord, skill_map: dict) -> None:
        if rec.status == "invalid":
            return
        entry = skill_map.get(rec.id)
        if isinstance(entry, dict):
            rec.status = str(entry.get("status") or "active")
            rec.reason = str(entry.get("reason") or entry.get("role") or "")
            rec.variant_of = str(entry.get("variant_of") or "")
            rec.stages = [s for s in (entry.get("stages") or {}) if s in STAGES]
            return
        # unmapped skill: heuristic routing only for presentation/design-like skills
        if _PRESENTATION_WORDS.search(rec.description + " " + rec.name):
            stages = self._heuristic_stages(rec)
            if stages:
                rec.status, rec.stages = "auto", sorted(stages)
                rec.reason = "not in skill_map.json; routed by heading keywords"
                return
        rec.status = "unmapped"
        rec.reason = "registered, but not in skill_map.json and not presentation-related; no guidance injected"

    # -- section loading ----------------------------------------------
    def _sections_of(self, path: Path) -> list[Section]:
        try:
            st = path.stat()
        except OSError:
            return []
        key = (st.st_mtime_ns, st.st_size)
        cached = self._sections.get(path)
        if cached and cached[0] == key:
            return cached[1]
        try:
            text = path.read_text(encoding="utf-8", errors="replace")
        except OSError:
            return []
        _meta, body, _w = parse_frontmatter(text)
        secs = split_sections(body)
        self._sections[path] = (key, secs)
        return secs

    def resolve_file(self, rec: SkillRecord, rel: str) -> Path | None:
        """Resolve a skill-relative path; refuses anything escaping the skill directory."""
        try:
            target = (rec.root / rel).resolve()
            target.relative_to(rec.root.resolve())
        except (ValueError, OSError):
            return None
        return target if target.is_file() else None

    def _heuristic_stages(self, rec: SkillRecord) -> dict[str, list[dict]]:
        out: dict[str, list[dict]] = {}
        for sec in self._sections_of(rec.path):
            low = sec.heading.lower()
            if not sec.heading or not sec.text:
                continue
            for stage, keys in _HEURISTIC.items():
                if any(k in low for k in keys):
                    out.setdefault(stage, []).append({"file": "SKILL.md", "heading": sec.heading})
                    break
        return out

    def _selectors(self, rec: SkillRecord, stage: str) -> list[dict]:
        entry = (((self._map.get("skills") or {}).get(rec.id)) or {}) if isinstance(self._map, dict) else {}
        if isinstance(entry, dict) and entry.get("stages"):
            return list(entry["stages"].get(stage) or [])
        if rec.status == "auto":
            return self._heuristic_stages(rec).get(stage, [])
        return []

    # -- public API ----------------------------------------------------
    def records(self) -> list[SkillRecord]:
        self.refresh()
        return sorted(self._records.values(), key=lambda r: (r.pack, r.id))

    def get(self, skill_id: str) -> SkillRecord | None:
        self.refresh()
        return self._records.get(skill_id)

    def conflicts(self) -> list[dict]:
        return list(self._map.get("conflicts") or []) if isinstance(self._map, dict) else []

    def thresholds(self) -> dict:
        t = (self._map.get("qa_thresholds") or {}) if isinstance(self._map, dict) else {}
        return {"title_pt": 28, "body_pt": 16, "caption_pt": 9, **{k: v for k, v in t.items() if isinstance(v, (int, float))}}

    def _extract(self, rec: SkillRecord, sel: dict) -> tuple[list[str], str]:
        """Return (prompt lines, matched heading) for one selector: code/tool text and excluded lines removed."""
        rel = str(sel.get("file") or "SKILL.md")
        path = rec.path if rel == "SKILL.md" else self.resolve_file(rec, rel)
        if path is None:
            return [], ""
        heading = str(sel.get("heading") or "").lower()
        secs = self._sections_of(path)
        for i, s in enumerate(secs):
            if s.heading and heading and heading in s.heading.lower():
                paras = _clean_paragraphs(_section_with_children(secs, i))
                limit = int(sel.get("max_paragraphs") or 0)
                paras = paras[:limit] if limit else paras
                excl = tuple(str(e).lower() for e in (sel.get("exclude") or ()))
                items = [it for p in paras for it in _tool_free(_flatten(p))
                         if not (excl and any(e in it.lower() for e in excl))]
                return items, s.heading
        return [], ""

    def guidance_for(self, stages: str | list[str] | tuple[str, ...], budget: int = 3000,
                     header: str = "") -> Guidance:
        """Budgeted guidance text for one or more pipeline stages."""
        stage_list = tuple([stages] if isinstance(stages, str) else stages)
        self.refresh()
        ck = (stage_list, budget, header, self._signature)
        with self._lock:
            if ck in self._guidance_cache:
                return self._guidance_cache[ck]
        g = Guidance(stages=stage_list)
        order = list((self._map.get("skills") or {}).keys()) if isinstance(self._map, dict) else []
        rank = {k: i for i, k in enumerate(order)}
        recs = sorted(self.records(), key=lambda r: rank.get(r.id, len(rank)))
        primaries = [r for r in recs if r.status in ("active", "auto")]
        fallbacks = [r for r in recs if r.status == "fallback"]
        stage_lines: dict[str, list[str]] = {}
        for stage in stage_list:
            if stage not in STAGES:
                continue
            lines: list[str] = []
            seen_text: set[str] = set()

            def collect(group: list[SkillRecord]) -> int:
                n = 0
                for rec in group:
                    for sel in self._selectors(rec, stage):
                        paras, heading = self._extract(rec, sel)
                        items = [i for i in paras if i not in seen_text]
                        if not items:
                            continue
                        seen_text.update(items)
                        lines.extend("- " + i for i in items)
                        g.used.append((rec.id, str(sel.get("file") or "SKILL.md"), heading))
                        n += 1
                return n

            if not collect(primaries):
                for fb in fallbacks:
                    collect([fb])
            if lines:
                stage_lines[stage] = lines
        # water-filling: small stages keep everything, large ones share what is left
        sizes = {st: sum(len(x) + 1 for x in ln) for st, ln in stage_lines.items()}
        left, remaining = budget, sorted(sizes, key=sizes.get)
        alloc: dict[str, int] = {}
        for i, st in enumerate(remaining):
            share = left // (len(remaining) - i)
            alloc[st] = min(sizes[st], max(share, 300))
            left -= alloc[st]
        chunks: list[str] = []
        for stage in stage_list:
            if stage not in stage_lines:
                continue
            body, cut = _cut("\n".join(stage_lines[stage]), alloc[stage])
            if cut:
                g.truncated.append(stage)
            chunks.append(f"[{stage}]\n{body}")
        text = "\n\n".join(chunks)
        if text and header:
            text = header.rstrip() + "\n\n" + text
        g.text = text
        with self._lock:
            self._guidance_cache[ck] = g
        return g

    def report(self) -> str:
        """Human readable status list (used by the bot's /skills command and the docs)."""
        lines = []
        for r in self.records():
            tag = {"active": "ON", "fallback": "FALLBACK", "auto": "AUTO", "reference_only": "REGISTERED-ONLY",
                   "unmapped": "UNMAPPED", "invalid": "INVALID"}.get(r.status, r.status)
            st = ", ".join(r.stages) if r.stages else "-"
            lines.append(f"{tag:<15} {r.id}  [{st}]")
        return "\n".join(lines)


# ---------------------------------------------------------------------------
# Module-level convenience (lazy singleton)
# ---------------------------------------------------------------------------

_registry: SkillRegistry | None = None
_reg_lock = threading.Lock()


def get_registry() -> SkillRegistry:
    global _registry
    with _reg_lock:
        if _registry is None:
            _registry = SkillRegistry()
        return _registry


def reset_registry() -> None:
    global _registry
    with _reg_lock:
        _registry = None


def app_constraints(max_slides: int | None = None) -> str:
    """Highest-precedence rules that always sit above skill guidance (conflict policy)."""
    cap = f"The deck has at most {max_slides} slides in total, cover and closing included. " if max_slides else ""
    return ("APPLICATION CONSTRAINTS (override everything below): "
            + cap +
            "Follow the user's topic, language, slide count and style exactly. Only use the layouts listed in the "
            "schema; ignore any instruction about command-line tools, npm, rendering, files or workspaces. "
            "Never invent statistics, sources or quotes; use clearly labelled illustrative data or a non-numeric layout. "
            "The style preset's colors are fixed by the user's /style choice: use palette advice below only to decide "
            "emphasis and restraint. Never ask questions: state assumptions in \"brief\" and proceed.")


def guidance_text(stages: str | list[str] | tuple[str, ...], budget: int = 3000,
                  max_slides: int | None = None) -> str:
    """Fail-soft helper for prompts: returns '' if anything goes wrong."""
    try:
        return get_registry().guidance_for(stages, budget, header=app_constraints(max_slides)).text
    except Exception as e:      # noqa: BLE001 - skills must never break deck generation
        logger.warning("skill guidance unavailable: %s", e)
        return ""


def skills_used_for(stages: str | list[str] | tuple[str, ...], budget: int = 3000) -> list[str]:
    try:
        return get_registry().guidance_for(stages, budget).skill_ids
    except Exception:           # noqa: BLE001
        return []
