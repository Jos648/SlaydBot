import json
import os
import sys
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from pptx import Presentation  # noqa: E402

from agent.deck_team import create_presentation_team  # noqa: E402
from utils.pptx_builder import build_pptx  # noqa: E402
from utils.pptx_qa import check_plan, check_pptx  # noqa: E402

GOOD = {"title": "Azərbaycan iqtisadiyyatı", "subtitle": "Qısa icmal", "slides": [
    {"layout": "cover", "title": "Azərbaycan iqtisadiyyatı"},
    {"layout": "chart", "title": "Əhalinin illər üzrə artımı", "chart": {
        "type": "line", "categories": ["2000", "2010", "2020"],
        "series": [{"name": "Milyon nəfər", "values": [8.1, 9.0, 10.1]}],
        "unit": "", "takeaway": "Əhali iki onillikdə 2 milyon artıb."}},
    {"layout": "table", "title": "Əsas sektorlar", "table": {
        "columns": ["Sektor", "Rol"], "rows": [["Neft", "İxracın əsası"], ["Kənd təsərrüfatı", "Məşğulluq"]]}},
    {"layout": "pie_unknown", "title": "x"},
    {"layout": "closing", "title": "Sağ olun", "bullets": ["Suallar?"]},
]}


class Charts(unittest.TestCase):
    def test_chart_and_table_are_native(self):
        prs = Presentation(__import__("io").BytesIO(build_pptx(GOOD, style="light-clean")))
        kinds = {s.name for sl in prs.slides for s in sl.shapes}
        self.assertIn("chart", kinds)
        self.assertIn("table", kinds)

    def test_bad_chart_degrades_not_crashes(self):
        bad = {"title": "t", "slides": [{"layout": "cover", "title": "t"},
               {"layout": "chart", "title": "x", "chart": {"categories": ["a"], "series": []},
                "bullets": ["a", "b"]}]}
        build_pptx(bad)

    def test_pie_and_bar(self):
        for kind in ("pie", "bar", "hbar"):
            d = {"title": "t", "slides": [{"layout": "chart", "title": "x", "chart": {
                "type": kind, "categories": ["a", "b", "c"], "series": [{"name": "s", "values": [1, 2, 3]}]}}]}
            build_pptx(d)


class QA(unittest.TestCase):
    def test_plan_issues(self):
        bad = {"slides": [{"layout": "cards", "title": "a b c d e f g h i j"},
                          {"layout": "cards", "title": "same", "items": []}]}
        msgs = " | ".join(map(str, check_plan(bad)))
        self.assertIn("cover", msgs)
        self.assertIn("repeats", msgs)
        self.assertIn("cards needs", msgs)

    def test_clean_deck_has_no_overflow(self):
        d = {"title": "t", "slides": [{"layout": "cover", "title": "t"},
             {"layout": "quote", "quote": "Q", "author": "A"}]}
        self.assertEqual([i for i in check_pptx(build_pptx(d)) if "overflow" in i.message], [])

    def test_real_overflow_is_detected(self):
        import io
        from pptx.util import Inches, Pt
        prs = Presentation()
        sl = prs.slides.add_slide(prs.slide_layouts[6])
        tb = sl.shapes.add_textbox(Inches(1), Inches(1), Inches(2), Inches(0.5))
        tb.name = "too-small"
        tb.text_frame.word_wrap = True
        run = tb.text_frame.paragraphs[0].add_run()
        run.text = "çox uzun mətn " * 30
        run.font.size = Pt(24)
        buf = io.BytesIO()
        prs.save(buf)
        self.assertTrue(any("too-small" in i.message and "overflow" in i.message
                            for i in check_pptx(buf.getvalue())))


class Team(unittest.TestCase):
    def test_pipeline_with_review_fix(self):
        calls = []
        broken = json.loads(json.dumps(GOOD))
        broken["slides"][3] = {"layout": "table", "title": "dup layout 1", "table": {"columns": ["a", "b"], "rows": [["1", "2"]]}}

        def fake(system, user, model, **kw):
            calls.append(model)
            if "Prepare research notes" in user:
                return "- fakt 1\n- fakt 2"
            if "ISSUES" in user:
                return json.dumps(GOOD)
            return json.dumps(broken)

        steps = []
        res = create_presentation_team("Azərbaycan iqtisadiyyatı", style="light-clean", slides=5,
                                       progress=steps.append, chat=fake)
        self.assertEqual(steps[:2], ["research", "outline"])
        self.assertIn("review", steps)
        self.assertGreaterEqual(res.slide_count, 4)
        self.assertGreater(len(set(calls)), 1)      # different employees -> different models


if __name__ == "__main__":
    unittest.main()
