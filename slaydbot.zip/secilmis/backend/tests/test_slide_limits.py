"""15-slide hard limit: input validation, planner, team repair loop, builder, final file, Telegram settings."""
import io
import json
import os
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from pptx import Presentation  # noqa: E402

from agent.deck_planner import build_system_prompt, build_user_prompt, parse_plan  # noqa: E402
from agent.deck_service import DeckError, create_presentation  # noqa: E402
from agent.deck_team import create_presentation_team  # noqa: E402
from utils.pptx_builder import build_pptx  # noqa: E402
from utils.pptx_qa import check_plan, check_pptx, count_slides  # noqa: E402
from utils.slide_limits import (ABSOLUTE_MAX_SLIDES, SlideCountError, enforce_slide_cap,  # noqa: E402
                                parse_slide_count, was_capped)

LAYOUT_CYCLE = ["cards", "steps", "compare", "stats", "bullets", "quote", "table", "chart", "agenda", "section"]


def _slide(i: int, layout: str) -> dict:
    s = {"layout": layout, "title": f"Slide {i} title", "notes": "n"}
    if layout in ("cards", "steps", "agenda"):
        s["items"] = [{"heading": f"H{k}", "text": f"text number {k} here"} for k in range(3)]
    elif layout == "compare":
        s["left"] = {"heading": "A", "points": ["a1", "a2"]}
        s["right"] = {"heading": "B", "points": ["b1", "b2"]}
    elif layout == "stats":
        s["stats"] = [{"value": "2x", "label": "growth", "text": "t"}, {"value": "5", "label": "teams", "text": "t"}]
    elif layout == "quote":
        s.update(quote="Q", author="A")
    elif layout == "table":
        s["table"] = {"columns": ["a", "b"], "rows": [["1", "2"], ["3", "4"]]}
    elif layout == "chart":
        s["chart"] = {"type": "bar", "categories": ["a", "b", "c"], "series": [{"name": "s", "values": [1, 2, 3]}]}
    else:
        s["bullets"] = ["one", "two", "three"]
    return s


def make_plan(total: int, with_cover_closing: bool = True) -> dict:
    slides = []
    for i in range(total):
        if with_cover_closing and i == 0:
            slides.append({"layout": "cover", "title": "Deck"})
        elif with_cover_closing and i == total - 1:
            slides.append({"layout": "closing", "title": "Thanks", "bullets": ["bye"]})
        else:
            slides.append(_slide(i, LAYOUT_CYCLE[i % len(LAYOUT_CYCLE)]))
    return {"title": "Deck", "subtitle": "sub", "brief": {"audience": "students", "tone": "clear"}, "slides": slides}


class FakeResp:
    def __init__(self, text):
        self.text = text


class FakeClient:
    """LLM client that ALWAYS answers with 20 slides, whatever was asked."""
    model = "fake"

    def __init__(self, n=20):
        self.n = n
        self.prompts = []

    def chat_completion(self, system="", messages=None, **kw):
        self.prompts.append(system)
        return FakeResp(json.dumps(make_plan(self.n)))


class SlideCountValidation(unittest.TestCase):
    def test_valid_values(self):
        for v in (1, 5, 10, 15, "7", " 12 "):
            self.assertEqual(parse_slide_count(v), int(str(v).strip()))

    def test_16_is_capped_not_accepted(self):
        self.assertEqual(parse_slide_count(16), 15)
        self.assertTrue(was_capped(16))
        self.assertEqual(parse_slide_count("100"), 15)

    def test_invalid_rejected(self):
        for v in (0, -1, "abc", "", None, 2.5, True):
            with self.assertRaises(SlideCountError):
                parse_slide_count(v)

    def test_service_rejects_zero_and_caps_16(self):
        with self.assertRaises(DeckError):
            create_presentation("topic", slides=0, client=FakeClient())
        r = create_presentation("topic", slides=16, client=FakeClient(), style="light-clean")
        self.assertEqual(r.slide_count, 15)


class EnforceCap(unittest.TestCase):
    def test_every_limit_keeps_cover_and_closing(self):
        deck = make_plan(20)
        before = json.dumps(deck, sort_keys=True)
        for n in range(1, 16):
            out = enforce_slide_cap(deck, n)["slides"]
            self.assertLessEqual(len(out), n)
            self.assertEqual(len(out), n)
            if n >= 2:
                self.assertEqual(out[0]["layout"], "cover")
                self.assertEqual(out[-1]["layout"], "closing")
        self.assertEqual(json.dumps(deck, sort_keys=True), before, "input must not be mutated")

    def test_parse_plan_trims_and_hard_cap(self):
        text = json.dumps(make_plan(30))
        self.assertEqual(len(parse_plan(text, max_slides=6)["slides"]), 6)
        self.assertEqual(len(parse_plan(text)["slides"]), ABSOLUTE_MAX_SLIDES)

    def test_prompt_states_exact_count(self):
        for n in (1, 2, 5, 15):
            self.assertIn("EXACTLY", build_user_prompt("topic", n, "en"))
            self.assertIn(f"SLIDE COUNT: {n}", build_system_prompt(max_slides=n, skills=False))

    def test_check_plan_flags_too_many(self):
        msgs = " ".join(map(str, check_plan(make_plan(9), max_slides=5)))
        self.assertIn("at most 5", msgs)


class BuilderAndFile(unittest.TestCase):
    def test_title_and_closing_are_not_added_on_top(self):
        for n in (1, 2, 5, 10, 15):
            plan = make_plan(n, with_cover_closing=n >= 2)
            data = build_pptx(plan, style="light-clean")
            self.assertEqual(count_slides(data), n, f"requested {n}")

    def test_builder_hard_cap_without_limit_argument(self):
        data = build_pptx(make_plan(40), style="light-clean")
        self.assertEqual(count_slides(data), 15)

    def test_builder_explicit_limit(self):
        self.assertEqual(count_slides(build_pptx(make_plan(12), max_slides=4)), 4)

    def test_check_pptx_flags_limit_and_blank(self):
        data = build_pptx(make_plan(8), style="light-clean")
        errs = [i.message for i in check_pptx(data, max_slides=5) if i.severity == "error"]
        self.assertTrue(any("limit is 5" in m for m in errs))
        prs = Presentation(io.BytesIO(data))
        prs.slides.add_slide(prs.slide_layouts[6])
        buf = io.BytesIO()
        prs.save(buf)
        self.assertTrue(any("blank" in i.message for i in check_pptx(buf.getvalue())))


class Pipelines(unittest.TestCase):
    def test_classic_pipeline_final_file_count(self):
        for n in (1, 5, 10, 15):
            r = create_presentation("a topic", slides=n, client=FakeClient(20), style="light-clean")
            self.assertEqual(count_slides(r.pptx), n)
            self.assertEqual(r.slide_count, n)
            self.assertLessEqual(len(r.outline.slides), n)

    def test_classic_pipeline_carries_brief_and_skills(self):
        client = FakeClient(8)
        r = create_presentation("a topic", slides=8, client=client, style="light-clean")
        self.assertEqual(r.brief.get("audience"), "students")
        self.assertIn("presentation-skill", r.skills_used)
        self.assertIn("SKILL GUIDANCE", client.prompts[0])
        self.assertIn("SLIDE COUNT: 8", client.prompts[0])

    def test_team_repair_round_cannot_add_slides(self):
        seen = {"review": 0, "reviewer_prompt": ""}

        def chat(system, user, model, **kw):
            if "Prepare research notes" in user:
                return "notes"
            if "ISSUES:" in user:                        # reviewer: tries to return 20 slides
                seen["review"] += 1
                seen["reviewer_prompt"] = user
                return json.dumps(make_plan(20))
            bad = make_plan(5)                           # designer: obeys the count but has an error
            bad["slides"][1] = {"layout": "cards", "title": "Broken", "items": []}
            return json.dumps(bad)

        r = create_presentation_team("short topic", slides=5, style="light-clean", chat=chat)
        self.assertGreaterEqual(seen["review"], 1, "the repair loop must have run")
        self.assertIn("at most 5", seen["reviewer_prompt"])
        self.assertIn("[qa_repair]", seen["reviewer_prompt"])        # QA skill guidance reaches the reviewer
        self.assertEqual(count_slides(r.pptx), 5)
        self.assertEqual(r.slide_count, 5)

    def test_team_designer_overlong_answer_is_trimmed(self):
        def chat(system, user, model, **kw):
            return "notes" if "Prepare research notes" in user else json.dumps(make_plan(25))
        for n in (3, 15):
            r = create_presentation_team("short topic", slides=n, style="light-clean", chat=chat)
            self.assertEqual(count_slides(r.pptx), n)


class TelegramSettings(unittest.TestCase):
    def test_store_clamps_and_choices(self):
        import telegram_bot as tb
        self.assertTrue(all(1 <= n <= 15 for n in tb.SLIDE_CHOICES))
        self.assertEqual(tb._safe_slides(40), 15)
        self.assertEqual(tb._safe_slides("junk"), 8)
        with tempfile.TemporaryDirectory() as d:
            path = Path(d) / "s.json"
            path.write_text(json.dumps({"7": {"slides": 20}}), encoding="utf-8")
            store = tb.SettingsStore(path)
            self.assertEqual(store.get(7)["slides"], 15)
            self.assertEqual(store.set(7, slides=3)["slides"], 3)


if __name__ == "__main__":
    unittest.main()
