import io
import json
import os
import sys
import threading
import unittest
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlparse

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from PIL import Image, ImageDraw  # noqa: E402
from pptx import Presentation  # noqa: E402
from pptx.enum.shapes import MSO_SHAPE_TYPE  # noqa: E402

from agent.deck_planner import build_system_prompt  # noqa: E402
from agent.deck_service import create_presentation  # noqa: E402
from agent.llm_client import LLMClient, LLMResponse  # noqa: E402
from utils import image_search  # noqa: E402
from utils.aspect_ratio import SUPPORTED  # noqa: E402
from utils.pptx_builder import build_pptx  # noqa: E402


def make_jpeg(w=1880, h=1250, color=(40, 120, 200)):
    im = Image.new("RGB", (w, h), color)
    d = ImageDraw.Draw(im)
    d.ellipse((w * 0.3, h * 0.2, w * 0.7, h * 0.8), fill=(250, 200, 60))
    out = io.BytesIO()
    im.save(out, "JPEG")
    return out.getvalue()


class FakePexels(BaseHTTPRequestHandler):
    mode = "ok"
    seen = []

    def log_message(self, *a):
        pass

    def do_GET(self):
        u = urlparse(self.path)
        if u.path.startswith("/img/"):
            body = b"not an image" if FakePexels.mode == "badimg" else make_jpeg()
            self.send_response(200)
            self.send_header("Content-Type", "image/jpeg")
            self.end_headers()
            self.wfile.write(body)
            return
        FakePexels.seen.append((parse_qs(u.query).get("query", [""])[0], self.headers.get("Authorization")))
        if FakePexels.mode == "401":
            self.send_response(401)
            self.end_headers()
            return
        if FakePexels.mode == "429":
            self.send_response(429)
            self.end_headers()
            return
        if FakePexels.mode == "badjson":
            body = b"<html>oops</html>"
        elif FakePexels.mode == "empty":
            body = json.dumps({"photos": []}).encode()
        else:
            port = self.server.server_address[1]
            body = json.dumps({"photos": [
                {"width": 800, "height": 1200, "photographer": "Portrait Guy",
                 "src": {"large2x": f"http://127.0.0.1:{port}/img/p.jpg"}},
                {"width": 1880, "height": 1250, "photographer": "Ayşə Məmmədova",
                 "src": {"large2x": f"http://127.0.0.1:{port}/img/l.jpg"}},
                {"width": 1000, "height": 700, "photographer": "Other",
                 "src": {"large2x": "https://evil.example.com/x.jpg"}},
            ]}).encode()
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.end_headers()
        self.wfile.write(body)


class Stub(LLMClient):
    model = "stub"

    def __init__(self, text):
        self.text, self.system = text, None

    def chat_completion(self, system, messages, max_tokens=8192, temperature=0, timeout=60.0, stream=False):
        self.system = system
        return LLMResponse(self.text)

    def stream_completion(self, *a, **k):
        yield self.text


PLAN = {"title": "Təhsil", "subtitle": "Alt", "slides": [
    {"layout": "cover", "title": "Təhsil", "image_query": "students in classroom"},
    {"layout": "cards", "title": "Kartlar", "items": [{"heading": "A", "text": "a"}, {"heading": "B", "text": "b"}]},
    {"layout": "image", "title": "Şəkilli", "bullets": ["bir", "iki", "üç"], "image_query": "teacher with students"},
    {"layout": "section", "title": "Bölmə", "bullets": ["alt"], "image_query": "library books"},
    {"layout": "image", "title": "Şəkilli 2", "bullets": ["dörd", "beş"], "image_query": "university campus"},
    {"layout": "closing", "title": "Sağ olun", "bullets": ["bitdi"]}]}


class ImageTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.srv = ThreadingHTTPServer(("127.0.0.1", 0), FakePexels)
        threading.Thread(target=cls.srv.serve_forever, daemon=True).start()
        cls.port = cls.srv.server_address[1]

    @classmethod
    def tearDownClass(cls):
        cls.srv.shutdown()

    def setUp(self):
        self._env = dict(os.environ)
        os.environ["PEXELS_API_KEY"] = "test-key"
        os.environ["PEXELS_BASE_URL"] = f"http://127.0.0.1:{self.port}/v1"
        FakePexels.mode = "ok"
        FakePexels.seen = []

    def tearDown(self):
        os.environ.clear()
        os.environ.update(self._env)

    def test_fetch_picks_landscape_from_trusted_host_and_sends_key(self):
        r = image_search.fetch_photo("students in classroom")
        self.assertIsNotNone(r)
        self.assertEqual(r["credit"], "Ayşə Məmmədova / Pexels")
        im = Image.open(io.BytesIO(r["bytes"]))
        self.assertLessEqual(im.width, 1600)
        self.assertEqual(FakePexels.seen[0], ("students in classroom", "test-key"))

    def test_untrusted_host_is_refused(self):
        self.assertFalse(image_search._host_ok("https://evil.example.com/x.jpg"))
        self.assertFalse(image_search._host_ok("http://images.pexels.com/x.jpg"))   # not https
        self.assertTrue(image_search._host_ok("https://images.pexels.com/x.jpg"))

    def test_failures_return_none_never_raise(self):
        for mode in ("401", "429", "badjson", "empty", "badimg"):
            FakePexels.mode = mode
            self.assertIsNone(image_search.fetch_photo("a b"), mode)

    def test_no_key_means_no_network(self):
        del os.environ["PEXELS_API_KEY"]
        self.assertIsNone(image_search.fetch_photo("anything"))
        self.assertEqual(FakePexels.seen, [])
        self.assertEqual(image_search.attach_images(json.loads(json.dumps(PLAN))), 0)

    def test_long_query_retries_with_shorter_one(self):
        FakePexels.mode = "empty"
        image_search.fetch_photo("old city narrow street azerbaijan")
        self.assertEqual([q for q, _ in FakePexels.seen], ["old city narrow street azerbaijan", "old city"])

    def test_attach_and_build_all_ratios(self):
        for ratio in sorted(SUPPORTED):
            deck = json.loads(json.dumps(PLAN))
            self.assertEqual(image_search.attach_images(deck), 4)
            prs = Presentation(io.BytesIO(build_pptx(deck, "corporate-navy", ratio)))
            pics = [(n, sh) for n, s in enumerate(prs.slides, 1) for sh in s.shapes
                    if sh.shape_type == MSO_SHAPE_TYPE.PICTURE]
            self.assertEqual(sorted({n for n, _ in pics}), [1, 3, 4, 5], ratio)
            W, H = prs.slide_width, prs.slide_height
            for n, s in enumerate(prs.slides, 1):
                for sh in s.shapes:
                    self.assertGreaterEqual(sh.left, -2000, (ratio, n, sh.name))
                    self.assertLessEqual(sh.left + sh.width, W + 2000, (ratio, n, sh.name))
                    self.assertLessEqual(sh.top + sh.height, H + 2000, (ratio, n, sh.name))

    def test_photo_is_cropped_not_stretched(self):
        deck = json.loads(json.dumps(PLAN))
        image_search.attach_images(deck)
        prs = Presentation(io.BytesIO(build_pptx(deck)))
        pic = [sh for sh in prs.slides[0].shapes if sh.shape_type == MSO_SHAPE_TYPE.PICTURE][0]
        self.assertGreater(pic.crop_left + pic.crop_right + pic.crop_top + pic.crop_bottom, 0)

    def test_image_layout_without_photo_degrades(self):
        deck = json.loads(json.dumps(PLAN))          # never attached -> no photos
        prs = Presentation(io.BytesIO(build_pptx(deck)))
        self.assertEqual(len(prs.slides), 6)
        for s in prs.slides:
            self.assertFalse(any(sh.shape_type == MSO_SHAPE_TYPE.PICTURE for sh in s.shapes))
        texts = " ".join(sh.text_frame.text for sh in prs.slides[2].shapes if sh.has_text_frame)
        self.assertIn("bir", texts)                   # bullets still shown

    def test_service_end_to_end_and_prompt_switch(self):
        c = Stub(json.dumps(PLAN, ensure_ascii=False))
        stages = []
        r = create_presentation("Təhsil", client=c, slides=6, progress=stages.append)
        self.assertEqual(r.images, 4)
        self.assertEqual(stages, ["outline", "images", "build"])
        self.assertIn("image_query", c.system)
        pics = sum(1 for s in Presentation(io.BytesIO(r.pptx)).slides for sh in s.shapes
                   if sh.shape_type == MSO_SHAPE_TYPE.PICTURE)
        self.assertEqual(pics, 4)
        del os.environ["PEXELS_API_KEY"]
        c2 = Stub(json.dumps(PLAN, ensure_ascii=False))
        r2 = create_presentation("Təhsil", client=c2, slides=6)
        self.assertEqual(r2.images, 0)
        self.assertNotIn("image_query", c2.system)    # LLM isn't asked for photos without a key
        self.assertNotIn("PHOTOS", build_system_prompt(False))


if __name__ == "__main__":
    unittest.main()
