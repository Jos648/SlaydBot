"""Skill discovery / loading / stage mapping / orchestration, plus regression checks for the existing project."""
import io
import json
import os
import sys
import tempfile
import time
import unittest
from pathlib import Path

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from pptx import Presentation  # noqa: E402

from agent.deck_planner import build_system_prompt  # noqa: E402
from agent.skill_system import (STAGES, SkillRegistry, app_constraints, guidance_text,  # noqa: E402
                                parse_frontmatter, split_sections)
from utils.pptx_builder import build_pptx  # noqa: E402
from utils.pptx_qa import check_pptx  # noqa: E402

BACKEND = Path(__file__).resolve().parent.parent


def write(path: Path, text: str) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8")
    return path


SKILL_A = """---
name: alpha-design
description: Presentation slide layout and typography rules
---
# Alpha

## Layout
Keep one idea per slide. Use a strict grid.

Run `npm run build` and then python3 scripts/render.py to check.

```bash
npm run doctor
```

- Avoid more than five bullets.
- Never web hero CSS hover effects.

## Typography
Titles are large. Body is readable.
"""
SKILL_B = """---
name: beta-data
description: Chart and data visualization for slide decks
---
## Data rules
Bar charts start at zero.
"""


def make_tree(root: Path, mapping: dict | None = None) -> Path:
    write(root / "packA" / "SKILL.md", SKILL_A)
    write(root / "packB" / "deep" / "nested" / "skills" / "beta" / "SKILL.md", SKILL_B)
    if mapping is not None:
        write(root / "skill_map.json", json.dumps(mapping))
    return root


MAPPING = {"skills": {
    "alpha-design": {"status": "active", "stages": {
        "composition": [{"file": "SKILL.md", "heading": "Layout", "exclude": ["hover"]}],
        "build": [{"file": "SKILL.md", "heading": "Typography"}]}},
    "beta-data": {"status": "active", "stages": {
        "data_viz": [{"file": "SKILL.md", "heading": "Data rules"}],
        "composition": [{"file": "SKILL.md", "heading": "Data rules"}]}},
}}


class Discovery(unittest.TestCase):
    def test_nested_skills_are_found(self):
        with tempfile.TemporaryDirectory() as d:
            reg = SkillRegistry(make_tree(Path(d), MAPPING))
            self.assertEqual({r.id for r in reg.records()}, {"alpha-design", "beta-data"})
            self.assertEqual(reg.get("alpha-design").description, "Presentation slide layout and typography rules")

    def test_front_matter_variants(self):
        meta, body, w = parse_frontmatter("---\nname: x\ndescription: \"quoted: with colon\"\n---\nbody")
        self.assertEqual((meta["name"], meta["description"], body, w), ("x", "quoted: with colon", "body", []))
        meta, _b, w = parse_frontmatter("---\nname: ok\nbad: [unclosed\n---\ntext")
        self.assertEqual(meta.get("name"), "ok")
        self.assertTrue(w)
        self.assertEqual(parse_frontmatter("no front matter")[0], {})

    def test_missing_malformed_empty_duplicate(self):
        with tempfile.TemporaryDirectory() as d:
            root = Path(d)
            write(root / "nofront" / "SKILL.md", "# Only a heading\n\n## Layout\ntext")
            write(root / "empty" / "SKILL.md", "")
            write(root / "dup1" / "SKILL.md", "---\nname: same\n---\nfirst body")
            write(root / "dup2" / "SKILL.md", "---\nname: same\n---\nsecond body")
            write(root / "binary" / "SKILL.md", "---\nname: bin\n---\n")
            (root / "bytes" ).mkdir()
            (root / "bytes" / "SKILL.md").write_bytes(b"---\nname: latin\n---\nbody \xff\xfe ok")
            reg = SkillRegistry(root)
            ids = {r.id: r for r in reg.records()}
            self.assertIn("nofront", ids)                       # name falls back to the folder
            self.assertTrue(ids["nofront"].warnings)
            self.assertEqual(ids["empty"].status, "invalid")
            self.assertEqual(ids["bin"].status, "invalid")
            self.assertIn("same", ids)
            self.assertIn("same@dup2", ids)                     # duplicate gets a qualified id
            self.assertIn("latin", ids)                         # undecodable bytes do not crash
            self.assertEqual(reg.guidance_for("composition").text, "")   # nothing routed, no exception

    def test_missing_dir_and_broken_map(self):
        self.assertEqual(SkillRegistry(Path("/nonexistent/skills")).records(), [])
        with tempfile.TemporaryDirectory() as d:
            root = make_tree(Path(d))
            write(root / "skill_map.json", "{ not json")
            reg = SkillRegistry(root)                          # heuristic routing instead of crashing
            self.assertEqual(reg.get("alpha-design").status, "auto")
            self.assertIn("composition", reg.get("alpha-design").stages)

    def test_unmapped_non_presentation_skill_is_not_injected(self):
        with tempfile.TemporaryDirectory() as d:
            write(Path(d) / "x" / "SKILL.md", "---\nname: db-tuning\ndescription: SQL index tuning\n---\n## Layout\nsql")
            reg = SkillRegistry(Path(d))
            self.assertEqual(reg.get("db-tuning").status, "unmapped")
            self.assertEqual(reg.guidance_for(list(STAGES)).text, "")

    def test_relative_references_cannot_escape(self):
        with tempfile.TemporaryDirectory() as d:
            root = make_tree(Path(d), MAPPING)
            write(root / "packA" / "references" / "r.md", "# R\n")
            write(root / "secret.txt", "secret")
            reg = SkillRegistry(root)
            rec = reg.get("alpha-design")
            self.assertIsNotNone(reg.resolve_file(rec, "references/r.md"))
            self.assertIsNone(reg.resolve_file(rec, "../secret.txt"))
            self.assertIsNone(reg.resolve_file(rec, "../../secret.txt"))

    def test_extra_dirs_env(self):
        with tempfile.TemporaryDirectory() as d, tempfile.TemporaryDirectory() as extra:
            write(Path(extra) / "mine" / "SKILL.md", "---\nname: mine\ndescription: slide deck colour palette\n---\n## Colour palette\nUse few colours.")
            os.environ["PPT_SKILLS_EXTRA"] = extra
            try:
                reg = SkillRegistry(Path(d))
            finally:
                del os.environ["PPT_SKILLS_EXTRA"]
            self.assertEqual(reg.get("mine").status, "auto")


class Orchestration(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = make_tree(Path(self.tmp.name), MAPPING)
        self.reg = SkillRegistry(self.root)

    def tearDown(self):
        self.tmp.cleanup()

    def test_instructions_from_multiple_skills_are_combined(self):
        g = self.reg.guidance_for("composition")
        self.assertIn("one idea per slide", g.text)
        self.assertIn("Bar charts start at zero", g.text)
        self.assertEqual(set(g.skill_ids), {"alpha-design", "beta-data"})

    def test_stage_mapping_is_respected(self):
        self.assertIn("Titles are large", self.reg.guidance_for("build").text)
        self.assertNotIn("one idea per slide", self.reg.guidance_for("build").text)
        self.assertEqual(self.reg.guidance_for("qa_repair").text, "")

    def test_tool_text_code_and_excluded_lines_are_stripped(self):
        text = self.reg.guidance_for("composition").text
        for bad in ("npm run", "python3 scripts", "doctor", "hover"):
            self.assertNotIn(bad, text)
        self.assertIn("Avoid more than five bullets", text)

    def test_budget_truncation_is_reported(self):
        g = self.reg.guidance_for(["composition", "build", "data_viz"], budget=330)
        self.assertLessEqual(len(g.text), 330 * 3)
        big = self.root / "packA" / "SKILL.md"
        write(big, SKILL_A.replace("Keep one idea per slide.", "Keep one idea per slide. " + "Filler sentence here. " * 80))
        self.reg.invalidate()
        g2 = self.reg.guidance_for("composition", budget=300)
        self.assertIn("composition", g2.truncated)

    def test_cache_invalidates_when_a_skill_changes(self):
        self.assertNotIn("NEWRULE", self.reg.guidance_for("build").text)
        time.sleep(0.01)
        write(self.root / "packA" / "SKILL.md", SKILL_A + "\n## Typography\nNEWRULE applies.\n")
        write(self.root / "packA" / "SKILL.md", SKILL_A.replace("Body is readable.", "Body is readable. NEWRULE applies."))
        self.reg.refresh(force=True)
        self.assertIn("NEWRULE", self.reg.guidance_for("build").text)

    def test_fallback_skill_only_used_when_primary_is_silent(self):
        m = json.loads(json.dumps(MAPPING))
        m["skills"]["beta-data"] = {"status": "fallback", "stages": {"build": [{"file": "SKILL.md", "heading": "Data rules"}],
                                                                       "data_viz": [{"file": "SKILL.md", "heading": "Data rules"}]}}
        write(self.root / "skill_map.json", json.dumps(m))
        reg = SkillRegistry(self.root)
        self.assertNotIn("Bar charts", reg.guidance_for("build").text)       # primary has text for build
        self.assertIn("Bar charts", reg.guidance_for("data_viz").text)       # primary silent -> fallback speaks

    def test_reference_only_skill_is_never_injected(self):
        m = json.loads(json.dumps(MAPPING))
        m["skills"]["beta-data"] = {"status": "reference_only", "reason": "web only"}
        write(self.root / "skill_map.json", json.dumps(m))
        reg = SkillRegistry(self.root)
        self.assertEqual(reg.get("beta-data").status, "reference_only")
        self.assertNotIn("Bar charts", reg.guidance_for(list(STAGES), budget=9000).text)

    def test_constraints_header(self):
        self.assertIn("at most 7 slides", app_constraints(7))
        self.assertTrue(guidance_text("planning", 1000, max_slides=7).startswith("APPLICATION CONSTRAINTS"))


class ShippedSkills(unittest.TestCase):
    """The real skills bundled with the project."""

    @classmethod
    def setUpClass(cls):
        cls.reg = SkillRegistry()
        cls.ids = {r.id: r for r in cls.reg.records()}

    def test_all_supplied_skills_are_registered(self):
        expected = {"presentation-skill", "presentation-skill@presentation-skill-ppt-legacy", "frontend-design",
                    "gsap-core", "gsap-frameworks", "gsap-performance", "gsap-plugins", "gsap-react",
                    "gsap-scrolltrigger", "gsap-timeline", "gsap-utils"}
        self.assertTrue(expected <= set(self.ids), expected - set(self.ids))
        self.assertTrue(all(r.status != "invalid" for r in self.ids.values()))

    def test_statuses_are_honest(self):
        self.assertEqual(self.ids["presentation-skill"].status, "active")
        self.assertEqual(self.ids["frontend-design"].status, "active")
        self.assertEqual(self.ids["presentation-skill@presentation-skill-ppt-legacy"].status, "fallback")
        for sid, rec in self.ids.items():
            if sid.startswith("gsap-"):
                self.assertEqual(rec.status, "reference_only")
                self.assertTrue(rec.reason)

    def test_skill_files_are_unmodified_originals(self):
        manifest = json.loads((BACKEND / "skills" / "MANIFEST.json").read_text(encoding="utf-8"))
        import hashlib
        for entry in manifest["files"]:
            if entry["path"].endswith("SKILL.md"):
                data = (BACKEND / "skills" / entry["path"]).read_bytes()
                self.assertEqual(hashlib.sha256(data).hexdigest(), entry["sha256"], entry["path"])

    def test_every_stage_has_guidance(self):
        for stage in STAGES:
            g = self.reg.guidance_for(stage, 4000)
            self.assertTrue(g.text.strip(), f"no guidance reaches stage {stage}")
            self.assertTrue(g.skill_ids)
            self.assertTrue(set(g.skill_ids) <= {"presentation-skill", "frontend-design",
                                                 "presentation-skill@presentation-skill-ppt-legacy"})

    def test_no_tool_commands_reach_prompts(self):
        text = self.reg.guidance_for(list(STAGES), 20000).text
        for bad in ("npm run", "present.py", "python3 scripts", "```"):
            self.assertNotIn(bad, text)

    def test_map_only_names_known_stages_and_skills(self):
        m = json.loads((BACKEND / "skills" / "skill_map.json").read_text(encoding="utf-8"))
        for sid, entry in m["skills"].items():
            self.assertIn(sid, self.ids, f"{sid} is in skill_map.json but not discovered")
            for stage in entry.get("stages", {}):
                self.assertIn(stage, STAGES)
        self.assertEqual(set(m["stages"]), set(STAGES))
        self.assertTrue(m["conflicts"])

    def test_planner_prompt_gets_skill_guidance_within_budget(self):
        prompt = build_system_prompt(max_slides=6)
        self.assertIn("SKILL GUIDANCE", prompt)
        self.assertIn("APPLICATION CONSTRAINTS", prompt)
        self.assertLess(len(prompt), 20000)
        self.assertNotIn("SKILL GUIDANCE", build_system_prompt(max_slides=6, skills=False))


class RegressionExistingBehaviour(unittest.TestCase):
    def test_provider_configuration_template_is_preserved(self):
        env = (BACKEND / ".env.example").read_text(encoding="utf-8")
        for key in ("LLM_PROVIDER=", "GEMINI_API_KEY=", "GEMINI_MODEL=", "ANTHROPIC_API_KEY=", "MODEL_ID=",
                    "OPENAI_API_KEY", "OPENAI_MODEL", "PEXELS_API_KEY=", "TELEGRAM_BOT_TOKEN=", "TELEGRAM_ALLOWED_IDS=",
                    "DECK_TEAM", "COMPANY_MODEL_TIER_FAST", "BOT_DEFAULT_SLIDES"):
            self.assertIn(key, env)
        from company.roles import tier_model
        os.environ["COMPANY_MODEL_TIER_FAST"] = "custom-model"
        try:
            self.assertEqual(tier_model("fast"), "custom-model")
        finally:
            del os.environ["COMPANY_MODEL_TIER_FAST"]

    def test_existing_modules_import(self):
        import agent.deck_service as ds
        import agent.deck_team  # noqa: F401
        import telegram_bot  # noqa: F401
        for name in ("create_presentation", "DeckError", "DeckResult", "available_styles", "safe_filename",
                     "MIN_SLIDES", "MAX_SLIDES", "MAX_INPUT_CHARS"):
            self.assertTrue(hasattr(ds, name), name)
        self.assertEqual(ds.MAX_SLIDES, 15)
        self.assertEqual(ds.MIN_SLIDES, 1)

    def test_representative_layouts_build_clean(self):
        from tests.test_slide_limits import make_plan
        plan = make_plan(12)
        next(sl for sl in plan["slides"] if sl.get("layout") == "chart")["chart"]["illustrative"] = True
        data = build_pptx(plan, style="light-clean")
        prs = Presentation(io.BytesIO(data))
        self.assertEqual(len(prs.slides), 12)
        issues = check_pptx(data, max_slides=12)
        self.assertEqual([i for i in issues if i.severity == "error"], [], issues)
        text = " ".join(sh.text_frame.text for sl in prs.slides for sh in sl.shapes if sh.has_text_frame)
        self.assertIn("Illustrative data", text)

    def test_all_aspect_ratios_build(self):
        from tests.test_slide_limits import make_plan
        from utils.aspect_ratio import SUPPORTED
        for ratio in SUPPORTED:
            self.assertEqual(len(Presentation(io.BytesIO(build_pptx(make_plan(6), aspect_ratio=ratio))).slides), 6)


if __name__ == "__main__":
    unittest.main()
