import os
import sys
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from pptx import Presentation  # noqa: E402

from utils.pptx_icons import ICON_NAMES, draw_icon  # noqa: E402


class Icons(unittest.TestCase):
    def test_every_icon_draws_inside_its_box(self):
        prs = Presentation()
        slide = prs.slides.add_slide(prs.slide_layouts[6])
        for i, name in enumerate(ICON_NAMES):
            self.assertTrue(draw_icon(slide, name, 1, 1, 0.7, (37, 99, 235), (220, 230, 250), name=f"i{i}"), name)
        self.assertEqual(len(slide.shapes), len(ICON_NAMES))

    def test_float_colours_from_the_builder(self):
        prs = Presentation()
        slide = prs.slides.add_slide(prs.slide_layouts[6])
        self.assertTrue(draw_icon(slide, "star", 0, 0, 0.7, (37.2, 99.6, 235.0), (220.4, 230.5, 250.9)))

    def test_alias_and_unknown(self):
        prs = Presentation()
        slide = prs.slides.add_slide(prs.slide_layouts[6])
        self.assertTrue(draw_icon(slide, "Growth", 0, 0, 0.7, (0, 0, 0), (200, 200, 200)))
        self.assertFalse(draw_icon(slide, "no-such-icon", 0, 0, 0.7, (0, 0, 0), (200, 200, 200)))
        self.assertFalse(draw_icon(slide, "", 0, 0, 0.7, (0, 0, 0), (200, 200, 200)))


if __name__ == "__main__":
    unittest.main()
