"""
PPT Agent — Telegram bot
========================

Mövzu (və ya mətn / .txt / .md / .pdf fayl) göndərin → bot PowerPoint (.pptx)
hazırlayıb Telegram-dan geri göndərir.

* Yalnız standart Python kitabxanası + python-pptx/pyyaml/python-dotenv işlədir
  (Termux-da pydantic/Rust/Playwright tələb olunmur).
* Long-polling: telefonda açıq portlar, domen, webhook lazım deyil.
* LLM: Gemini (pulsuz), OpenAI/GPT və ya Claude — ``.env`` faylından.

İşə salmaq:   cd backend && python telegram_bot.py
Yoxlama:      cd backend && python telegram_bot.py --check
"""

from __future__ import annotations

import io
import json
import logging
import mimetypes
import os
import sys
import threading
import urllib.error
import urllib.request
import uuid
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from typing import Callable

from dotenv import load_dotenv

from agent.deck_service import (
    MAX_INPUT_CHARS, DeckError, DeckResult, available_styles, create_presentation,
)
from agent.llm_client import LLMError, LLMHTTPError
from utils.aspect_ratio import SUPPORTED as RATIOS
from utils.slide_limits import ABSOLUTE_MAX_SLIDES, DEFAULT_SLIDES, SlideCountError, parse_slide_count, was_capped

logger = logging.getLogger("ppt-bot")

DATA_DIR = Path(__file__).parent / "data"
SETTINGS_PATH = DATA_DIR / "bot_settings.json"
LANG_BUTTONS = [("az", "Azərbaycan"), ("en", "English"), ("ru", "Русский"), ("tr", "Türkçe"),
                ("zh", "中文"), ("de", "Deutsch"), ("fr", "Français"), ("es", "Español")]
SLIDE_CHOICES = [1, 3, 5, 6, 8, 10, 12, 15]   # buttons; any number 1-15 also works: /slides 7
MAX_FILE_BYTES = 2 * 1024 * 1024

HELP_TEXT = (
    "Salam! Mən PowerPoint təqdimatı hazırlayan botam.\n\n"
    "Sadəcə mövzunu yazın, məsələn:\n"
    "  Süni intellekt təhsildə\n"
    "və ya hazır mətn / .txt / .md / .pdf fayl göndərin — .pptx faylını geri göndərəcəyəm.\n\n"
    "Komandalar:\n"
    "/ppt <mövzu> — təqdimat hazırla\n"
    "/style — dizayn mövzusu\n"
    "/lang — dil\n"
    "/slides — slayd sayı (1-15; düymə və ya /slides 7)\n"
    "/skills — aktiv dizayn bacarıqları\n"
    "/ratio — slayd ölçüsü (16:9, 4:3 ...)\n"
    "/settings — cari seçimlər\n"
    "/id — Telegram ID-niz\n"
    "/help — bu mesaj"
)


# ---------------------------------------------------------------------------
# Telegram Bot API (stdlib only)
# ---------------------------------------------------------------------------

class TelegramError(RuntimeError):
    def __init__(self, code: int | None, description: str):
        self.code = code
        self.description = description
        super().__init__(f"Telegram error {code}: {description}")


def _multipart(fields: dict[str, str], files: dict[str, tuple[str, bytes, str]]) -> tuple[bytes, str]:
    boundary = "----pptagent" + uuid.uuid4().hex
    buf = io.BytesIO()

    def w(s: str) -> None:
        buf.write(s.encode("utf-8"))

    for name, value in fields.items():
        w(f"--{boundary}\r\nContent-Disposition: form-data; name=\"{name}\"\r\n\r\n{value}\r\n")
    for name, (filename, content, ctype) in files.items():
        safe = filename.replace('"', "").replace("\r", "").replace("\n", "")
        w(f"--{boundary}\r\nContent-Disposition: form-data; name=\"{name}\"; filename=\"{safe}\"\r\n"
          f"Content-Type: {ctype}\r\n\r\n")
        buf.write(content)
        w("\r\n")
    w(f"--{boundary}--\r\n")
    return buf.getvalue(), f"multipart/form-data; boundary={boundary}"


class TelegramAPI:
    def __init__(self, token: str, base_url: str | None = None):
        self.token = token
        self.base = (base_url or os.environ.get("TELEGRAM_API_BASE") or "https://api.telegram.org").rstrip("/")

    def _url(self, method: str) -> str:
        return f"{self.base}/bot{self.token}/{method}"

    def _send(self, req: urllib.request.Request, timeout: float) -> dict:
        try:
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                body = json.loads(resp.read().decode("utf-8"))
        except urllib.error.HTTPError as e:
            try:
                body = json.loads(e.read().decode("utf-8"))
            except Exception:
                raise TelegramError(e.code, e.reason) from None
        except (urllib.error.URLError, TimeoutError, OSError) as e:
            # str(e) never contains the URL, so the bot token cannot leak here.
            raise TelegramError(None, f"network: {getattr(e, 'reason', e)}") from None
        if not body.get("ok"):
            raise TelegramError(body.get("error_code"), str(body.get("description")))
        return body["result"]

    def call(self, method: str, params: dict | None = None, timeout: float = 40) -> dict | list | bool:
        req = urllib.request.Request(
            self._url(method), data=json.dumps(params or {}).encode("utf-8"),
            headers={"Content-Type": "application/json"}, method="POST")
        return self._send(req, timeout)

    def send_document(self, chat_id: int, filename: str, content: bytes, caption: str = "",
                      timeout: float = 120) -> dict:
        ctype = mimetypes.guess_type(filename)[0] or "application/octet-stream"
        if filename.endswith(".pptx"):
            ctype = "application/vnd.openxmlformats-officedocument.presentationml.presentation"
        body, content_type = _multipart(
            {"chat_id": str(chat_id), "caption": caption[:1000]},
            {"document": (filename, content, ctype)},
        )
        req = urllib.request.Request(self._url("sendDocument"), data=body,
                                     headers={"Content-Type": content_type}, method="POST")
        return self._send(req, timeout)

    def download_file(self, file_path: str, timeout: float = 60) -> bytes:
        url = f"{self.base}/file/bot{self.token}/{file_path}"
        try:
            with urllib.request.urlopen(url, timeout=timeout) as resp:
                return resp.read(MAX_FILE_BYTES + 1)
        except (urllib.error.URLError, TimeoutError, OSError) as e:
            raise TelegramError(None, f"download failed: {getattr(e, 'reason', e)}") from None


def _safe_slides(value) -> int:
    """Stored/env slide count -> valid 1..15 (falls back to the default on garbage)."""
    try:
        return parse_slide_count(value)
    except SlideCountError:
        return DEFAULT_SLIDES


# ---------------------------------------------------------------------------
# Per-chat settings
# ---------------------------------------------------------------------------

class SettingsStore:
    def __init__(self, path: Path = SETTINGS_PATH):
        self.path = path
        self._lock = threading.Lock()
        self._data: dict[str, dict] = {}
        try:
            self._data = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            self._data = {}

    @staticmethod
    def defaults() -> dict:
        ratio = os.environ.get("BOT_DEFAULT_RATIO", "16:9")
        return {
            "style": os.environ.get("BOT_DEFAULT_STYLE", "corporate-navy"),
            "language": os.environ.get("BOT_DEFAULT_LANGUAGE", "az"),
            "slides": _safe_slides(os.environ.get("BOT_DEFAULT_SLIDES", "")),
            "ratio": ratio if ratio in RATIOS else "16:9",
        }

    def get(self, chat_id: int) -> dict:
        with self._lock:
            cfg = self.defaults()
            cfg.update(self._data.get(str(chat_id), {}))
            cfg["slides"] = _safe_slides(cfg.get("slides"))     # old/edited files can never exceed 15
            return cfg

    def set(self, chat_id: int, **values) -> dict:
        with self._lock:
            cur = self._data.setdefault(str(chat_id), {})
            cur.update(values)
            self._persist()
        return self.get(chat_id)

    def _persist(self) -> None:
        try:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            tmp = self.path.with_suffix(".tmp")
            tmp.write_text(json.dumps(self._data, ensure_ascii=False, indent=1), encoding="utf-8")
            os.replace(tmp, self.path)
        except OSError as e:
            logger.warning("Could not persist settings: %s", e)


# ---------------------------------------------------------------------------
# Bot
# ---------------------------------------------------------------------------

def _friendly_llm_error(e: Exception) -> str:
    if isinstance(e, LLMHTTPError):
        if e.status == 429:
            return ("API limiti dolub (pulsuz Gemini planında dəqiqəlik/gündəlik limit var). "
                    "1-2 dəqiqə sonra yenidən cəhd edin.")
        if e.status in (401, 403) or "API key" in e.body or "API_KEY" in e.body:
            return "API açarı yanlışdır və ya icazəsi yoxdur. .env faylındakı açarı yoxlayın."
        if e.status == 404:
            return "Model tapılmadı. .env-də GEMINI_MODEL / OPENAI_MODEL / MODEL_ID dəyərini yoxlayın."
        return f"LLM xətası: {e}"
    if isinstance(e, LLMError):
        return f"LLM xətası: {e}"
    return "Gözlənilməz xəta baş verdi. Bir az sonra yenidən cəhd edin."


class PPTBot:
    def __init__(
        self,
        api: TelegramAPI,
        store: SettingsStore | None = None,
        generate: Callable[..., DeckResult] = create_presentation,
        allowed_ids: set[int] | None = None,
        workers: int = 2,
    ):
        self.api = api
        self.store = store or SettingsStore()
        self.generate = generate
        self.allowed_ids = allowed_ids or set()
        self.pool = ThreadPoolExecutor(max_workers=workers, thread_name_prefix="bot-job")
        self._busy: set[int] = set()
        self._busy_lock = threading.Lock()
        self._stop = threading.Event()
        self.username = ""

    # -- helpers ------------------------------------------------------------
    def say(self, chat_id: int, text: str, keyboard: list[list[dict]] | None = None) -> dict:
        params: dict = {"chat_id": chat_id, "text": text[:4000]}
        if keyboard:
            params["reply_markup"] = {"inline_keyboard": keyboard}
        return self.api.call("sendMessage", params)

    def _edit(self, chat_id: int, message_id: int, text: str) -> None:
        try:
            self.api.call("editMessageText", {"chat_id": chat_id, "message_id": message_id, "text": text[:4000]})
        except TelegramError as e:
            logger.debug("edit failed: %s", e)

    @staticmethod
    def _kb(items: list[tuple[str, str]], per_row: int) -> list[list[dict]]:
        rows, row = [], []
        for label, data in items:
            row.append({"text": label, "callback_data": data})
            if len(row) == per_row:
                rows.append(row)
                row = []
        if row:
            rows.append(row)
        return rows

    def _allowed(self, user_id: int | None) -> bool:
        return not self.allowed_ids or (user_id in self.allowed_ids)

    # -- update dispatch ----------------------------------------------------
    def handle_update(self, update: dict) -> None:
        if "callback_query" in update:
            return self._handle_callback(update["callback_query"])
        msg = update.get("message")
        if msg:
            self._handle_message(msg)

    def _handle_callback(self, cq: dict) -> None:
        user_id = (cq.get("from") or {}).get("id")
        msg = cq.get("message") or {}
        chat_id = (msg.get("chat") or {}).get("id")
        data = cq.get("data") or ""
        try:
            self.api.call("answerCallbackQuery", {"callback_query_id": cq.get("id")})
        except TelegramError:
            pass
        if chat_id is None or not self._allowed(user_id):
            return
        kind, _, value = data.partition(":")
        if kind == "s" and value in available_styles():
            self.store.set(chat_id, style=value)
            self._edit(chat_id, msg.get("message_id"), f"✅ Dizayn: {value}")
        elif kind == "l" and value in dict(LANG_BUTTONS):
            self.store.set(chat_id, language=value)
            self._edit(chat_id, msg.get("message_id"), f"✅ Dil: {dict(LANG_BUTTONS)[value]}")
        elif kind == "n" and value.isdigit() and 1 <= int(value) <= ABSOLUTE_MAX_SLIDES:
            self.store.set(chat_id, slides=int(value))
            self._edit(chat_id, msg.get("message_id"), f"✅ Slayd sayı: {value}")
        elif kind == "r" and value in RATIOS:
            self.store.set(chat_id, ratio=value)
            self._edit(chat_id, msg.get("message_id"), f"✅ Ölçü: {value}")

    def _handle_message(self, msg: dict) -> None:
        chat = msg.get("chat") or {}
        chat_id = chat.get("id")
        user_id = (msg.get("from") or {}).get("id")
        if chat_id is None:
            return
        text = (msg.get("text") or "").strip()
        private = chat.get("type") == "private"

        # /id must work for everyone — it is how you find the ID for the allow-list.
        if text.split("@")[0].split(" ")[0].lower() == "/id":
            self.say(chat_id, f"Sizin Telegram ID: {user_id}")
            return
        if not self._allowed(user_id):
            self.say(chat_id, f"Bu bota giriş icazəniz yoxdur. (ID: {user_id})")
            return

        if msg.get("document"):
            return self._handle_document(chat_id, msg)
        if not text:
            return

        if text.startswith("/"):
            head, _, args = text.partition(" ")
            cmd = head.split("@")[0].lower()
            return self._handle_command(chat_id, cmd, args.strip())
        if private:
            self._start_job(chat_id, text)

    def _handle_command(self, chat_id: int, cmd: str, args: str) -> None:
        cfg = self.store.get(chat_id)
        if cmd in ("/start", "/help"):
            self.say(chat_id, HELP_TEXT)
        elif cmd == "/ppt":
            if args:
                self._start_job(chat_id, args)
            else:
                self.say(chat_id, "Mövzunu əmrdən sonra yazın, məsələn:\n/ppt Qlobal istiləşmə")
        elif cmd == "/style":
            items = [(s, f"s:{s}") for s in available_styles()]
            self.say(chat_id, f"Dizayn seçin (indi: {cfg['style']}):", self._kb(items, 2))
        elif cmd == "/lang":
            self.say(chat_id, "Təqdimat dili:", self._kb([(n, f"l:{c}") for c, n in LANG_BUTTONS], 2))
        elif cmd == "/slides":
            if args:
                try:
                    n = parse_slide_count(args)
                except SlideCountError:
                    self.say(chat_id, f"Slayd sayı 1 ilə {ABSOLUTE_MAX_SLIDES} arasında olmalıdır, məsələn: /slides 7")
                    return
                self.store.set(chat_id, slides=n)
                note = f" (maksimum {ABSOLUTE_MAX_SLIDES}, ona görə {n} qoyuldu)" if was_capped(args) else ""
                self.say(chat_id, f"✅ Slayd sayı: {n}{note}")
            else:
                self.say(chat_id, f"Slayd sayı (indi: {cfg['slides']}, maksimum {ABSOLUTE_MAX_SLIDES}; "
                                  f"başqa rəqəm üçün /slides 7):",
                         self._kb([(str(n), f"n:{n}") for n in SLIDE_CHOICES], 4))
        elif cmd == "/skills":
            from agent.skill_system import get_registry
            reg = get_registry()
            self.say(chat_id, "Bacarıqlar (ON = təlimatlar promptlara daxil edilir, REGISTERED-ONLY = qeydiyyatdadır, "
                              "lakin PPTX üçün tətbiq olunmur):\n" + reg.report())
        elif cmd == "/ratio":
            self.say(chat_id, f"Slayd ölçüsü (indi: {cfg['ratio']}):",
                     self._kb([(r, f"r:{r}") for r in sorted(RATIOS)], 4))
        elif cmd == "/settings":
            self.say(chat_id, f"Seçimlər:\n• Dizayn: {cfg['style']}\n• Dil: {cfg['language']}\n"
                              f"• Slayd sayı: {cfg['slides']}\n• Ölçü: {cfg['ratio']}")
        else:
            self.say(chat_id, "Naməlum komanda. /help yazın.")

    def _handle_document(self, chat_id: int, msg: dict) -> None:
        doc = msg["document"]
        name = (doc.get("file_name") or "").lower()
        if not name.endswith((".txt", ".md", ".markdown", ".pdf")):
            self.say(chat_id, "Yalnız .txt, .md və .pdf fayllar dəstəklənir.")
            return
        if (doc.get("file_size") or 0) > MAX_FILE_BYTES:
            self.say(chat_id, "Fayl çox böyükdür (maksimum 2 MB).")
            return
        try:
            info = self.api.call("getFile", {"file_id": doc["file_id"]})
            raw = self.api.download_file(info["file_path"])
        except TelegramError as e:
            logger.warning("file download failed: %s", e)
            self.say(chat_id, "Faylı yükləmək alınmadı.")
            return
        if len(raw) > MAX_FILE_BYTES:
            self.say(chat_id, "Fayl çox böyükdür (maksimum 2 MB).")
            return
        if name.endswith(".pdf"):
            try:
                from pypdf import PdfReader
                reader = PdfReader(io.BytesIO(raw))
                text = "\n".join((p.extract_text() or "") for p in reader.pages[:40])
            except ImportError:
                self.say(chat_id, "PDF üçün 'pip install pypdf' lazımdır.")
                return
            except Exception:
                self.say(chat_id, "PDF oxunmadı.")
                return
        else:
            text = raw.decode("utf-8", errors="replace")
        text = text.strip()
        if not text:
            self.say(chat_id, "Faylda mətn tapılmadı.")
            return
        caption = (msg.get("caption") or "").strip()
        if caption:
            text = f"{caption}\n\n{text}"
        self._start_job(chat_id, text[:MAX_INPUT_CHARS])

    # -- generation job -----------------------------------------------------
    def _start_job(self, chat_id: int, text: str) -> None:
        if len(text.strip()) < 3:
            self.say(chat_id, "Mövzu çox qısadır. Bir az ətraflı yazın.")
            return
        with self._busy_lock:
            if chat_id in self._busy:
                self.say(chat_id, "⏳ Əvvəlki təqdimat hələ hazırlanır, bir az gözləyin.")
                return
            self._busy.add(chat_id)
        cfg = self.store.get(chat_id)
        self.pool.submit(self._run_job, chat_id, text, cfg)

    def _run_job(self, chat_id: int, text: str, cfg: dict) -> None:
        status_id = None
        try:
            status = self.say(chat_id, "⏳ Plan hazırlanır...")
            status_id = status.get("message_id")
            try:
                self.api.call("sendChatAction", {"chat_id": chat_id, "action": "upload_document"})
            except TelegramError:
                pass

            def progress(stage: str) -> None:
                if status_id and stage == "research":
                    self._edit(chat_id, status_id, "🔎 Tədqiqatçı məlumat toplayır...")
                elif status_id and stage == "review":
                    self._edit(chat_id, status_id, "🧐 Yoxlayıcı planı düzəldir...")
                elif status_id and stage == "images":
                    self._edit(chat_id, status_id, "🖼 Mövzuya uyğun şəkillər axtarılır...")
                elif status_id and stage == "build":
                    self._edit(chat_id, status_id, "🎨 Slaydlar qurulur...")

            result = self.generate(
                text, style=cfg["style"], language=cfg["language"], slides=cfg["slides"],
                aspect_ratio=cfg["ratio"], progress=progress,
            )
            self.api.send_document(
                chat_id, result.filename, result.pptx,
                caption=f"✅ {result.title}\n{result.slide_count} slayd • {cfg['style']} • {cfg['ratio']}",
            )
            if status_id:
                try:
                    self.api.call("deleteMessage", {"chat_id": chat_id, "message_id": status_id})
                except TelegramError:
                    pass
        except DeckError as e:
            self._fail(chat_id, status_id, f"❌ {e}")
        except TelegramError as e:
            logger.error("Telegram send failed: %s", e)
            self._fail(chat_id, status_id, "❌ Faylı göndərmək alınmadı.")
        except Exception as e:  # noqa: BLE001 - last line of defence for a worker thread
            logger.exception("generation failed")
            self._fail(chat_id, status_id, "❌ " + _friendly_llm_error(e))
        finally:
            with self._busy_lock:
                self._busy.discard(chat_id)

    def _fail(self, chat_id: int, status_id: int | None, text: str) -> None:
        try:
            if status_id:
                self._edit(chat_id, status_id, text)
            else:
                self.say(chat_id, text)
        except TelegramError:
            pass

    # -- main loop ----------------------------------------------------------
    def stop(self) -> None:
        self._stop.set()

    def run(self, poll_timeout: int = 25) -> None:
        me = self.api.call("getMe")
        self.username = me.get("username", "")
        logger.info("Bot started: @%s", self.username)
        if not self.allowed_ids:
            logger.warning("TELEGRAM_ALLOWED_IDS boşdur — bota hamı yaza bilər və API limitinizi işlədə bilər!")
        try:
            self.api.call("deleteWebhook", {"drop_pending_updates": False})
        except TelegramError as e:
            logger.warning("deleteWebhook failed: %s", e)

        offset: int | None = None
        backoff = 1.0
        while not self._stop.is_set():
            try:
                params = {"timeout": poll_timeout, "allowed_updates": ["message", "callback_query"]}
                if offset is not None:
                    params["offset"] = offset
                updates = self.api.call("getUpdates", params, timeout=poll_timeout + 15)
                backoff = 1.0
            except TelegramError as e:
                if e.code == 409:
                    logger.error("Başqa bir bot nüsxəsi eyni tokenlə işləyir. 10 san gözlənilir...")
                    self._stop.wait(10)
                elif e.code in (401, 404):
                    logger.critical("Token yanlışdır: %s", e)
                    return
                else:
                    logger.warning("getUpdates failed: %s (retry in %.0fs)", e, backoff)
                    self._stop.wait(backoff)
                    backoff = min(backoff * 2, 30)
                continue
            for upd in updates:
                offset = upd["update_id"] + 1
                try:
                    self.handle_update(upd)
                except Exception:  # noqa: BLE001
                    logger.exception("update handling failed")
        self.pool.shutdown(wait=False, cancel_futures=True)


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def _parse_allowed(raw: str) -> set[int]:
    out: set[int] = set()
    for part in raw.replace(";", ",").split(","):
        part = part.strip()
        if part.lstrip("-").isdigit():
            out.add(int(part))
    return out


def check_setup() -> int:
    """Verify the Telegram token and the LLM provider without starting the bot."""
    token = os.environ.get("TELEGRAM_BOT_TOKEN", "").strip()
    ok = True
    if not token:
        print("✗ TELEGRAM_BOT_TOKEN .env-də yoxdur")
        ok = False
    else:
        try:
            me = TelegramAPI(token).call("getMe", timeout=15)
            print(f"✓ Telegram: @{me.get('username')}")
        except TelegramError as e:
            print(f"✗ Telegram: {e}")
            ok = False
    try:
        from agent.llm_client import create_llm_client
        client = create_llm_client()
        resp = client.chat_completion("Reply with the single word OK.",
                                      [{"role": "user", "content": "ping"}], max_tokens=64, timeout=30)
        print(f"✓ LLM ({type(client).__name__}, model={client.model}): {resp.text.strip()[:40]!r}")
    except Exception as e:  # noqa: BLE001
        print(f"✗ LLM: {_friendly_llm_error(e)} [{type(e).__name__}: {e}]")
        ok = False
    return 0 if ok else 1


def main(argv: list[str] | None = None) -> int:
    argv = sys.argv[1:] if argv is None else argv
    load_dotenv(Path(__file__).parent / ".env")
    load_dotenv()
    logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
                        datefmt="%H:%M:%S")
    if "--check" in argv:
        return check_setup()
    token = os.environ.get("TELEGRAM_BOT_TOKEN", "").strip()
    if not token:
        print("TELEGRAM_BOT_TOKEN təyin edilməyib. backend/.env faylına əlavə edin "
              "(@BotFather-dən alın).", file=sys.stderr)
        return 2
    allowed = _parse_allowed(os.environ.get("TELEGRAM_ALLOWED_IDS", ""))
    bot = PPTBot(TelegramAPI(token), allowed_ids=allowed,
                 workers=int(os.environ.get("BOT_WORKERS", "2") or 2))
    try:
        bot.run()
    except KeyboardInterrupt:
        bot.stop()
        print("\nBot dayandırıldı.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
