# PPT Agent — Termux (Android) üçün Telegram bot

Mövzu yazırsınız → bot `.pptx` hazırlayıb Telegram-da göndərir. Brauzer, Playwright və FastAPI lazım deyil.

## 1. Qurulum
```bash
pkg update -y && pkg install -y unzip
cd ~/ppt-agent && unzip -o /sdcard/Download/ppt-agent-final.zip
bash scripts/termux_setup.sh
```
Skript paketləri qurur, `.env` yaradır (açarları soruşur) və yoxlama aparır.

## 2. Lazım olan açarlar
- **LLM açarı** (biri kifayətdir): Gemini (pulsuz: https://aistudio.google.com/apikey), OpenAI və ya Anthropic.
- **Telegram token**: @BotFather → `/newbot`.
- **Pexels açarı** (könüllü, şəkillər üçün, pulsuz): https://www.pexels.com/api/

Açarlar yalnız `backend/.env` faylında olmalıdır. Onları çatda və ya ekran görüntüsündə göndərməyin.

## 3. İşə salma
```bash
bash ~/ppt-agent/scripts/run_bot.sh
```
Termux pəncərəsini bağlamayın, yoxsa bot dayanır. Dayandırmaq üçün `Ctrl+C`.
Açarların işlədiyini yoxlamaq üçün: `cd ~/ppt-agent/backend && python telegram_bot.py --check`

## 4. Botda
- Mövzu yazın (məsələn: `Süni intellekt təhsildə`) və ya `.txt`, `.md`, `.pdf` fayl göndərin.
- `/style` dizayn, `/lang` dil, `/slides` slayd sayı, `/ratio` ölçü, `/settings` cari ayarlar.
- `/id` sizin Telegram nömrənizi göstərir. Onu `.env`-də `TELEGRAM_ALLOWED_IDS=` sətrinə yazın ki, botdan yalnız siz istifadə edəsiniz.

## 5. Şəkillər (könüllü)
Slaydlara mövzuya uyğun foto qoymaq üçün pulsuz Pexels açarı lazımdır. `.env` faylına əlavə edin:

```
PEXELS_API_KEY=sizin_açar
```

Açar yoxdursa, bot şəkilsiz işləyir. Fotolar Pexels-dən gəlir, slaydın küncündə müəllifin adı yazılır.

## Problemlər
- `429` xətası: LLM provayderinin pulsuz limiti dolub, bir az gözləyin.
- `401` / `404` xətası: `.env`-dəki açarı və ya model adını yoxlayın.
- Şəkil gəlmirsə: `PEXELS_API_KEY` düzgün yazılıb? Bot yenidən başladılıb?
- Bot cavab vermirsə: Termux-da bot işləyirmi? `TELEGRAM_ALLOWED_IDS` sizin nömrənizi saxlayırmı?

## 6. Dizayn bacarıqları (skills) və slayd limiti
- Slayd sayı **1-15** arasındadır (15 = mütləq maksimum, titul və yekun slayd daxil). Düymələrlə: `/slides`, istənilən rəqəmlə: `/slides 7`. 15-dən böyük yazsanız 15 qoyulur.
- `/skills` — hansı bacarıqların aktiv olduğunu göstərir. `ON` = promptlara daxil edilir; `REGISTERED-ONLY` = qeydiyyatdadır, amma PPTX üçün tətbiq olunmur (GSAP veb animasiya bacarıqları).
- Bacarıq faylları `backend/skills/` qovluğundadır. Yeni bacarıq əlavə etmək üçün `SKILL.md` olan qovluğu ora atın (və ya `.env`-də `PPT_SKILLS_EXTRA=/yol/qovluq`). Marşrut: `backend/skills/skill_map.json`.
- Testlər: `cd ~/ppt-agent/backend && python -m unittest discover -s tests -p "test_*.py"`
- Ətraflı: `docs/SKILL_INTEGRATION.md`

